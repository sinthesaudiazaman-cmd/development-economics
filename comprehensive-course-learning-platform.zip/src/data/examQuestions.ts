export interface SubQuestion {
  part: string;
  marks: number;
  question: string;
  answer: string;
}

export interface ExamQuestion {
  id: string;
  chapterId: number;
  totalMarks: number;
  difficulty: "easy" | "medium" | "hard";
  scenario?: string;
  question: string;
  subQuestions?: SubQuestion[];
  answer?: string;
}

export const examQuestions: ExamQuestion[] = [
  // =======================================
  // CHAPTER 1: Introducing Development Economics
  // =======================================

  // EASY
  {
    id: "ch1-e1",
    chapterId: 1,
    totalMarks: 2,
    difficulty: "easy",
    question: "Define economic development. How is it different from economic growth?",
    answer: `**Economic development** is a multidimensional process that involves the sustained improvement in the material well-being of a society. It goes far beyond a simple increase in output or income — it encompasses structural transformation of the economy, improvement in living standards, reduction in poverty and inequality, and the expansion of economic opportunities for all citizens.

According to **Amartya Sen**, economic development is fundamentally about expanding the real freedoms that people enjoy, including political liberties, social opportunities, and economic facilities. **Michael Todaro** defines it through three core values: sustenance (meeting basic needs), self-esteem (dignity and self-respect), and freedom from servitude (ability to choose).

**Economic growth**, on the other hand, refers to a quantitative increase in real GDP or output of an economy over a specific period. It is measured by the percentage change in real GDP or real GDP per capita.

**Key Differences:**

| Aspect | Economic Growth | Economic Development |
|--------|----------------|---------------------|
| Nature | Quantitative (more output) | Qualitative (better life) |
| Measurement | GDP growth rate | HDI, poverty rates, Gini coefficient |
| Scope | Uni-dimensional | Multi-dimensional |
| Focus | Increase in production capacity | Structural change, poverty reduction, human well-being |
| Time frame | Can be short-term | Necessarily long-term |
| Sufficiency | Necessary but not sufficient | The ultimate goal |

**Example:** Nigeria has experienced significant GDP growth due to oil exports, but much of the population remains in poverty. Growth has not translated into development because of inequality, corruption, and weak institutions. In contrast, **Kerala (India)** achieved high human development (literacy, life expectancy) despite modest per capita income, showing that development can occur even without spectacular growth.

In essence, **growth is about having more, while development is about being more and doing more**. A country can have high growth without development (resource-rich but unequal countries), and in some cases, significant development without extraordinary growth (countries that invest in health, education, and social protection).`,
  },
  {
    id: "ch1-e2",
    chapterId: 1,
    totalMarks: 2,
    difficulty: "easy",
    question: "What are Todaro's three core values of development? Briefly explain each.",
    answer: `According to **Michael P. Todaro**, all societies aspire to three fundamental values which represent the objectives of development. These three core values serve as the conceptual foundation for understanding what development truly means:

**1. Sustenance — The Ability to Meet Basic Needs:**
Sustenance refers to the basic requirements of life: food, shelter, clothing, health, and protection. Every person must have access to these fundamental necessities to sustain life. Without meeting these basic needs, no real development can be said to have occurred. A society where millions go hungry, lack access to clean water, or have no shelter cannot claim to be developed regardless of its GDP figures.

In the context of Bangladesh, programs like the **Vulnerable Group Development (VGD)** and **Vulnerable Group Feeding (VGF)** directly address sustenance by providing food and livelihood support to the most deprived populations, particularly women in rural areas.

**2. Self-Esteem — A Sense of Worth and Self-Respect:**
Development must give people a sense of dignity, self-worth, and respect. No society can be considered fully developed if its people are treated as tools for the benefit of others. Self-esteem is about having a sense of identity and being valued as a human being. When countries achieve economic prosperity and international recognition, their citizens often gain a greater sense of self-esteem and pride.

For example, Bangladesh's remarkable achievements in garment exports, microcredit, and social development indicators have enhanced the nation's international standing and the self-esteem of its citizens.

**3. Freedom from Servitude — The Ability to Choose:**
Freedom here means liberation from material conditions of life (poverty) and from social servitude to nature, ignorance, other people, misery, and institutions. People must have the freedom to make genuine choices about their lives — where to live, what work to do, what to believe, and how to participate in the political process.

This value echoes **Amartya Sen's** capabilities approach, where development means expanding the substantive freedoms that people enjoy. A person trapped in bonded labor, denied education, or excluded from political participation cannot be said to be living in a developed society, regardless of the country's economic statistics.

**These three values together form a holistic view of development** — one that goes beyond GDP per capita to encompass the full range of human aspirations. Development policy should target all three simultaneously, not just economic growth.`,
  },
  {
    id: "ch1-e3",
    chapterId: 1,
    totalMarks: 3,
    difficulty: "easy",
    question: "List and briefly explain any three components of economic growth.",
    answer: `Economic growth — the sustained increase in real GDP over time — depends on several interconnected components. Three of the most important are:

**1. Capital Accumulation (Physical and Human):**
Capital accumulation refers to investment in physical capital (machinery, factories, infrastructure, roads, bridges, power plants) and human capital (education, health, skills training). When an economy accumulates more capital, it increases its productive capacity — workers have more and better tools to work with, which raises output per worker.

The **Harrod-Domar model** formalizes this by stating that growth rate (g) = savings rate (s) ÷ capital-output ratio (k). If a country saves and invests 20% of its GDP with a capital-output ratio of 4, it achieves 5% growth. This explains why countries with higher savings and investment rates (like China at 40%+ of GDP) tend to grow faster.

However, capital accumulation alone faces **diminishing returns** — each additional unit of capital produces less additional output when other factors remain unchanged (as demonstrated by the Solow model). Bangladesh's development of roads, bridges (Padma Bridge), and power plants are examples of physical capital accumulation driving growth.

**2. Technological Progress:**
Technology refers to the methods and techniques used to combine inputs into outputs. Technological progress allows an economy to produce more output from the same amount of inputs — it increases **Total Factor Productivity (TFP)**. This is widely considered the most important driver of long-run per capita growth.

Robert Solow's famous finding that **87.5% of US economic growth** was attributable to technological progress (the "Solow residual") rather than capital or labor accumulation underscored the centrality of technology. Technological progress can come through invention (creating new knowledge), innovation (applying knowledge commercially), or diffusion (adopting existing technologies from elsewhere).

For developing countries like Bangladesh, **technology transfer** from advanced economies through FDI, trade, and licensing can be more impactful than indigenous invention. The adoption of mobile banking (bKash), high-yielding rice varieties, and garment manufacturing technologies are examples.

**3. Human Capital Development:**
Human capital refers to the stock of knowledge, skills, competencies, and health attributes embodied in people that enable them to be productive. Investment in education, health, and training improves the quality of the labor force, leading to higher productivity and economic growth.

**Gary Becker's** human capital theory showed that education is an investment — it increases a worker's productivity and earnings, just as physical capital does. The social returns to education (lower crime, better health, democratic participation) often exceed private returns.

The **East Asian Tigers** (South Korea, Taiwan, Singapore) demonstrated the power of human capital investment — they invested heavily in universal education before industrialization, creating the skilled workforce needed for manufacturing and later for technology-intensive industries. Bangladesh's investment in girls' education through stipend programs has similarly contributed to improved social and economic outcomes.

**These three components are deeply interconnected:** technology requires human capital to develop and adopt it, capital accumulation provides the tools workers need, and human capital improves the efficiency with which both physical capital and technology are used.`,
  },

  // MEDIUM
  {
    id: "ch1-m1",
    chapterId: 1,
    totalMarks: 5,
    difficulty: "medium",
    scenario: "A government official claims: \"Our country's GDP has grown by 7% this year, so our people must be better off than last year.\"",
    question: "Critically evaluate this claim using the concepts of economic growth and economic development.",
    answer: `**The government official's claim that 7% GDP growth automatically means people are better off is an oversimplification that confuses economic growth with economic development.** While GDP growth is a positive indicator, it is neither a sufficient nor necessarily accurate measure of whether people's lives have genuinely improved. Let us critically evaluate this claim:

**1. GDP Growth Does Not Guarantee Improved Living Standards:**

GDP growth measures the increase in total output of goods and services. However, this tells us nothing about **who benefits from this growth**. If the 7% growth is concentrated in sectors like mining, finance, or luxury real estate that primarily benefit the wealthy elite, the majority of the population may see little or no improvement.

Consider **Nigeria**, which experienced significant GDP growth due to oil production but where over 40% of the population still lives below the poverty line. The growth was captured by a small elite, oil companies, and government officials, while the average citizen's standard of living barely changed or even deteriorated.

**2. Population Growth May Offset GDP Growth:**

If the population is growing at 3%, then real per capita income growth is only about 4% — significantly less impressive. In many developing countries, rapid population growth dilutes the benefits of GDP growth. Even this per capita figure is an average that masks enormous disparities between rich and poor.

**3. The Distribution Problem — Inequality:**

Even if per capita income rises, this improvement may be extremely unevenly distributed. The **Gini coefficient** measures this inequality. A country could have 7% GDP growth while inequality worsens — meaning the rich get richer while the poor stagnate or even become poorer.

For instance, Bangladesh's GDP has grown consistently at 6-7% in recent years, but its **Gini coefficient has risen from 0.33 to 0.48**, indicating that the benefits of growth have not been equally shared. Low-income households in rural Rangpur or Mymensingh may see little benefit from growth concentrated in Dhaka's garment sector and real estate.

**4. GDP Ignores Non-Market Activities:**

GDP excludes unpaid household work, subsistence farming, and informal sector activities. In developing countries, these can constitute 30-70% of actual economic activity. A rural woman who grows food for her family, cares for children, and fetches water contributes enormously to well-being but generates zero GDP. Economic growth that displaces these activities may actually reduce well-being for some.

**5. GDP Does Not Capture Quality of Life:**

Being better off means more than having higher income. It includes:
- **Health:** Are people living longer and healthier lives? Life expectancy may not improve despite GDP growth if health services remain inaccessible or environmental pollution worsens.
- **Education:** Are people more educated and skilled? Growth in the extractive sector may not require or stimulate educational improvement.
- **Environmental quality:** GDP counts pollution-causing industrial output as positive. Environmental degradation can worsen precisely because of GDP growth — deforestation, air pollution, water contamination.
- **Political freedoms and security:** People may be materially richer but live under political repression or in conflict zones.

**6. The Sustainability Question:**

Growth based on resource extraction, environmental destruction, or unsustainable debt is not genuine improvement. If a country depletes its forests, pollutes its rivers, and accumulates external debt to achieve 7% growth, future generations will be worse off. **Green GDP** — which accounts for environmental costs — often tells a very different story.

**7. What Should Be Measured Instead:**

A comprehensive assessment of whether people are "better off" requires examining:
- **Human Development Index (HDI):** Life expectancy, education, and income combined
- **Multidimensional Poverty Index (MPI):** Deprivation across health, education, and living standards
- **Gini Coefficient:** Income distribution and inequality
- **Employment data:** Whether growth creates decent jobs
- **Environmental indicators:** Air and water quality, forest cover, carbon emissions

**Conclusion:**

While 7% GDP growth is certainly a positive development, the official's claim that people "must be better off" does not logically follow. **Amartya Sen** rightly argued that development should be measured by the expansion of human capabilities and freedoms, not merely by output growth. The critical question is not "how much did the economy grow?" but "who benefited, how were the benefits distributed, was the growth sustainable, and did human well-being actually improve across multiple dimensions?" Only by examining these broader indicators can we truly assess whether people are better off.`,
  },
  {
    id: "ch1-m2",
    chapterId: 1,
    totalMarks: 5,
    difficulty: "medium",
    question: "Trace the historical evolution of development economics from the post-war period to the present. Identify the major paradigm shifts and their implications for developing countries.",
    answer: `Development economics as a distinct field emerged in the aftermath of World War II and has undergone several major paradigm shifts, each with profound implications for policy in developing countries.

**Phase 1: Structuralist Period (1940s–1960s) — State-Led Industrialization**

After WWII, the decolonization of Asia, Africa, and Latin America created a new field focused on transforming these economies. The dominant paradigm was **structuralism**, which argued that developing countries faced structural rigidities (market failures, missing markets, coordination problems) requiring active state intervention.

**Key theories and theorists:**
- **Paul Rosenstein-Rodan (1943):** Big Push Theory — argued that a massive, coordinated investment program across sectors was needed to break out of the poverty trap, because individual investments would fail due to insufficient demand.
- **Ragnar Nurkse (1953):** Vicious Circle of Poverty — low income leads to low savings, low investment, low productivity, and back to low income. Only a coordinated "big push" could break this cycle.
- **W. Arthur Lewis (1954):** Dual Economy Model — surplus labor in the traditional (agricultural) sector could be transferred to the modern (industrial) sector at subsistence wages, generating profits for reinvestment and growth.
- **Walt Rostow (1960):** Stages of Growth — all countries pass through five stages from traditional society to mass consumption. The critical "take-off" stage requires investment rising from 5% to 10%+ of national income.
- **Albert Hirschman (1958):** Unbalanced Growth — investment should be concentrated in strategic sectors with strong forward and backward linkages, letting market forces transmit growth impulses.

**Policy implications:** State planning, import-substitution industrialization (ISI), heavy industry investment, foreign aid to fill the "savings gap."

**Impact on developing countries:** India launched Five-Year Plans focusing on heavy industry (steel, machinery). Latin American countries (Brazil, Argentina, Mexico) adopted ISI. Many African post-independence governments established state-owned enterprises and protected domestic industries.

**Phase 2: Neoclassical Counter-Revolution (1970s–1980s) — Market Liberalization**

By the 1970s-80s, ISI had led to inefficiency, rent-seeking, fiscal crises, and the 1980s debt crisis devastated Latin America and Africa. A major paradigm shift occurred toward free-market orthodoxy.

**Key ideas:**
- **Washington Consensus (John Williamson, 1989):** A package of ten policy prescriptions including fiscal discipline, tax reform, trade liberalization, privatization, deregulation, and openness to FDI.
- **Structural Adjustment Programs (SAPs):** IMF and World Bank conditionality requiring developing countries to adopt market-oriented reforms in exchange for loans.
- Economists like **Peter Bauer, Deepak Lal, and Bela Balassa** argued that government intervention caused more problems than it solved — market failures were less harmful than "government failures."

**Policy implications:** Remove trade barriers, privatize state enterprises, reduce government spending, devalue currencies, cut subsidies, attract FDI.

**Impact on developing countries:** Africa experienced the "lost decade" of the 1980s — economic contraction, rising poverty, deteriorating social services. Latin America also suffered. Health and education spending was cut under SAPs, with devastating human consequences. However, some countries that embraced openness (East Asian Tigers) thrived, though they did so with significant state guidance that contradicted pure neoclassical prescriptions.

**Phase 3: Institutional Economics and Human Development (1990s) — Beyond Markets**

The failures of both state-led and pure market approaches led to a more nuanced understanding that **institutions** — the rules, norms, and enforcement mechanisms governing economic activity — are fundamental to development.

**Key developments:**
- **Douglass North (Nobel Prize 1993):** Institutions are the "rules of the game" that determine transaction costs, incentives, and economic performance.
- **Amartya Sen:** Capabilities approach — development means expanding human freedoms, not just increasing GDP. This profoundly influenced the creation of the **Human Development Index (HDI)** by **Mahbub ul Haq** in 1990.
- **Joseph Stiglitz:** Market failures are pervasive in developing countries (information asymmetries, incomplete markets). Markets need institutional support to function.
- **Post-Washington Consensus:** Recognition that institutions, governance, social capital, and equitable growth matter alongside market efficiency.

**Policy implications:** Focus on governance reform, anti-corruption, rule of law, building institutional capacity, investing in health and education, social safety nets.

**Phase 4: Evidence-Based Development (2000s–Present) — Randomized Experiments and SDGs**

**Key developments:**
- **Randomized Controlled Trials (RCTs):** Abhijit Banerjee and Esther Duflo (Nobel Prize 2019) pioneered experimental approaches to test development interventions (e.g., does deworming children improve school attendance? Do conditional cash transfers reduce poverty?).
- **Millennium Development Goals (2000)** and **Sustainable Development Goals (2015):** Comprehensive frameworks with specific targets for poverty, health, education, environment, and inequality.
- **Behavioral economics:** Understanding how cognitive biases affect economic decisions of the poor (e.g., present bias, limited attention).
- **Climate change and sustainability:** Integration of environmental concerns into development thinking.

**Implications for developing countries today:**

The current understanding is that **no single paradigm is sufficient**. Effective development requires:
1. Functioning markets supported by strong institutions
2. Strategic state intervention where market failures are severe
3. Investment in human capabilities (health, education)
4. Evidence-based policy design and evaluation
5. Environmental sustainability
6. Good governance and accountability

Bangladesh's development trajectory illustrates this synthesis — it has combined market-oriented garment exports with active NGO sector (BRAC, Grameen Bank), government social programs, and strategic state support for key industries.

**Conclusion:** The evolution of development economics shows a progressive enrichment of understanding — from simple capital accumulation models to comprehensive frameworks incorporating institutions, human capabilities, behavioral insights, and sustainability. The key lesson is that **development is context-specific** and requires pragmatic combination of markets, state, and civil society rather than adherence to any single ideological prescription.`,
  },

  // HARD
  {
    id: "ch1-h1",
    chapterId: 1,
    totalMarks: 10,
    difficulty: "hard",
    scenario: "Bangladesh's RMG sector has generated substantial export earnings and employment. However, workers may still face low wages, unsafe working conditions, and limited opportunities for upward mobility. If you were asked to judge whether the growth of Bangladesh's RMG sector has translated into \"development,\" choose three indicators that you would use and justify why each is necessary. Based on those indicators, construct a brief argument for why growth may or may not have produced development.",
    question: "Answer the above scenario-based question with detailed analysis.",
    answer: `**Introduction:**

Bangladesh's Ready-Made Garments (RMG) sector is one of the most remarkable stories of industrial growth in the developing world. From virtually nothing in the early 1980s, it has grown to a $42+ billion export industry, making Bangladesh the world's second-largest garment exporter after China. The sector employs over 4 million workers, approximately 60% of whom are women, and accounts for about 84% of the country's total export earnings. The question of whether this impressive growth has translated into genuine "development" requires careful analysis using appropriate indicators.

**Choosing Three Indicators and Justification:**

**Indicator 1: Real Wage Growth and Income Distribution (Per Capita Income and Gini Coefficient)**

*Why this indicator is necessary:*

Economic growth (measured by GDP or export earnings) tells us about the total size of the pie but nothing about how the pie is sliced. The RMG sector generates billions in revenue, but this revenue is distributed among factory owners, managers, workers, the government (taxes), and supply chain participants. To assess whether growth has become development, we must know whether the workers who produce this output — predominantly poor, rural-migrant women — are actually seeing meaningful improvements in their incomes.

The **real wage** (wage adjusted for inflation) of garment workers tells us whether purchasing power has genuinely increased. Simply looking at nominal wages can be misleading if prices rise faster than wages. The **Gini coefficient** further reveals whether the gains from the RMG sector are being shared broadly or concentrated among factory owners and the urban elite.

*Evidence and Analysis:*

Bangladesh's minimum wage for garment workers was raised to Tk 12,500/month in December 2023, up from Tk 8,000 set in 2018. However, this remains one of the lowest garment worker wages globally. In real terms (adjusted for inflation), wage improvements have been modest. Workers in Dhaka's garment factories spend 60-70% of their income on housing and food, leaving little for savings, education, or healthcare.

Meanwhile, Bangladesh's Gini coefficient has risen from 0.33 in 1991 to 0.48 in recent years, indicating that inequality has significantly worsened during the period of rapid garment sector growth. Factory owners and exporters have accumulated substantial wealth, while workers' wages have not kept pace with productivity gains. This suggests that **growth has not been equitably translated into income development for the working class.**

**Indicator 2: Human Development Index (HDI) Components — Specifically Life Expectancy and Education**

*Why this indicator is necessary:*

Development, as defined by Amartya Sen and the UNDP, encompasses the expansion of human capabilities — what people can do and be. Income alone is insufficient. If garment workers earn wages but lack access to healthcare, face occupational hazards, or cannot educate their children, then growth has not translated into meaningful human development. The HDI's health and education dimensions capture these critical aspects.

**Life expectancy** reflects access to healthcare, nutrition, safe working conditions, and environmental quality. **Education** (mean years and expected years of schooling) reflects whether economic opportunities are being used to invest in human capital for the next generation.

*Evidence and Analysis:*

Bangladesh has made remarkable progress in human development indicators during the RMG growth period:
- **Life expectancy** increased from 59 years (1990) to approximately 73 years — a dramatic improvement
- **Primary school enrollment** is nearly universal, and gender parity in education has been achieved
- Bangladesh's HDI improved from 0.388 (1990) to approximately 0.670

However, attributing this entirely to the RMG sector would be misleading. Much of the health improvement comes from NGO-led programs (BRAC's health interventions, Grameen Bank), government vaccination drives, and oral rehydration therapy. The RMG sector's direct contribution to health may actually be negative in some ways — long working hours (often 10-14 hours/day), exposure to textile dust, chemical dyes, and the Rana Plaza collapse (2013) that killed 1,134 workers reveal serious occupational health failures.

On education, the garment sector has mixed effects. Women's employment has increased their decision-making power in households, leading to greater investment in children's education. However, some families send adolescent daughters to garment factories instead of keeping them in school, as the opportunity cost of education rises when factory jobs are available.

**The verdict is mixed:** National-level HDI improvements are real but not primarily driven by RMG working conditions. The RMG sector has contributed indirectly (women's empowerment, household income) but has also created health and education trade-offs for workers.

**Indicator 3: Women's Empowerment and Social Transformation (Gender Inequality Index — GII)**

*Why this indicator is necessary:*

The RMG sector's most distinctive feature is its predominantly female workforce. If development means expanding freedoms and capabilities (Sen), then the impact on women's empowerment is crucial. The Gender Inequality Index (GII) measures gender-based disadvantages in reproductive health, empowerment (political participation and education), and labor market participation. This indicator captures whether economic participation has genuinely transformed women's social status and agency.

*Evidence and Analysis:*

The garment sector has been transformative for women's empowerment in Bangladesh:

**Positive impacts:**
- Over 2.5 million women have gained their first formal employment, moving from rural dependence on male family members to urban economic independence
- Studies show that garment-working women have greater control over household spending decisions, are more likely to delay marriage and childbearing, and invest more in their children's education
- Women's labor force participation has increased, and the stigma against women working outside the home has significantly reduced in Bangladeshi society
- The average age of marriage for garment workers is 2-3 years higher than for non-working rural women, reducing child marriage
- Women's financial independence has increased their bargaining power within households and communities

**However, empowerment remains limited:**
- Women are concentrated in the lowest-paid, least-skilled jobs (sewing operators) while men dominate supervisory and management positions
- Sexual harassment and gender-based violence in factories remain significant problems
- Women workers have limited access to trade unions and collective bargaining
- The "glass ceiling" in the garment industry means women rarely advance to mid-level or senior positions
- Social norms still burden women with household responsibilities after long factory shifts (the "double burden")
- Reproductive health concerns — working conditions during pregnancy, inadequate maternity leave implementation

**Constructing the Argument: Has Growth Produced Development?**

**Argument FOR development having occurred:**

The RMG sector has undeniably contributed to Bangladesh's overall development trajectory. At the macro level, it has generated foreign exchange earnings ($42+ billion), created millions of jobs, and contributed to poverty reduction. The poverty rate fell from 48.9% (2000) to approximately 18.7% (2022). Women's economic participation has catalyzed social transformation — delayed marriage, lower fertility, increased education investment in children.

The indirect effects may be even more important than the direct ones. The garment sector demonstrated that Bangladesh could compete globally in manufacturing, attracted FDI, developed infrastructure, and created a culture of entrepreneurship. Thousands of ancillary businesses (transport, food, housing, accessories) have emerged around the garment industry.

**Argument AGAINST development having fully occurred:**

Despite impressive growth, several indicators suggest that this growth has not fully translated into development:

1. **Wage poverty:** Garment workers remain among the lowest-paid industrial workers globally. The minimum wage of Tk 12,500 ($115/month) barely covers basic needs in Dhaka. This is growth that enriches factory owners and foreign buyers more than workers.

2. **Working conditions:** The Rana Plaza disaster (2013), recurring factory fires, and chronic occupational health issues reveal that growth has come at an unacceptable human cost. Development should not require workers to risk their lives.

3. **Rising inequality:** The Gini coefficient's increase from 0.33 to 0.48 indicates that the benefits of RMG growth have been captured disproportionately by owners, managers, and the urban middle class. Workers' share of value added in the garment supply chain has declined.

4. **Limited upward mobility:** Most garment workers remain in low-skill, low-wage jobs for their entire careers. There are few pathways for skill upgrading, career advancement, or transitioning to higher-value-added occupations. This contradicts the development ideal of expanding capabilities and choices.

5. **Environmental costs:** The textile dyeing industry has severely polluted rivers around Dhaka and Chittagong, affecting water quality, fisheries, and health in surrounding communities. This environmental degradation is not captured in GDP figures.

**Conclusion:**

Bangladesh's RMG sector has produced significant **economic growth** — impressive export figures, employment generation, and contribution to GDP. However, whether this growth constitutes genuine **development** is a more complex question. Using the three indicators:

- **Real wages and distribution** suggest that growth benefits have been unevenly shared (growth > development)
- **HDI components** show improvement at the national level, but direct working conditions in the sector raise concerns (mixed verdict)
- **Women's empowerment** has been a genuine positive outcome, though limited by persistent gender inequalities (growth has contributed to development, with caveats)

The overall verdict is that Bangladesh's RMG growth has **partially** translated into development. It has been a necessary engine of economic transformation, but insufficient policy attention to wages, working conditions, inequality, and environmental protection means that the full developmental potential of this growth has not been realized. Active policies — higher minimum wages, stronger enforcement of labor standards, investment in workers' skills and education, progressive taxation, and environmental regulation — are needed to ensure that future growth more fully translates into genuine development.`,
  },
  {
    id: "ch1-h2",
    chapterId: 1,
    totalMarks: 10,
    difficulty: "hard",
    scenario: "Bangladesh has limited public resources and must choose between subsidizing physical infrastructure, expanding technical education, and supporting research and innovation. Using any two growth theories from the course, rank these three policy options according to which should receive priority. Your answer must show how the theories lead to different policy recommendations.",
    question: "Answer the above scenario-based question with detailed theoretical analysis.",
    answer: `**Introduction:**

This question requires applying growth theories to a real policy dilemma facing Bangladesh — how to allocate scarce public resources among three competing priorities: physical infrastructure, technical education, and research & innovation. Different growth theories provide different answers because they identify different factors as the primary drivers of economic growth. I will analyze this using the **Harrod-Domar/Neoclassical (Solow) Growth Model** and the **Endogenous Growth Theory (Romer/Lucas)** to show how they lead to contrasting policy rankings.

---

**Theory 1: Harrod-Domar Model and Its Policy Implications**

**The Model:**
The Harrod-Domar model states that the rate of economic growth (g) is determined by the savings rate (s) divided by the capital-output ratio (k):

**g = s / k**

For example, if Bangladesh saves 30% of GDP (s = 0.30) and the capital-output ratio is 4 (k = 4), then:
g = 0.30 / 4 = 0.075 = **7.5% growth**

**Core implication:** Growth is fundamentally driven by **capital accumulation**. The more a country saves and invests in physical capital, the faster it grows. The capital-output ratio reflects how efficiently capital is used.

**Policy Ranking Under Harrod-Domar:**

**Priority 1: Physical Infrastructure (Highest Priority)**

Under the Harrod-Domar framework, physical infrastructure investment is the most critical priority because:

- Infrastructure IS capital accumulation — roads, bridges, power plants, ports, railways, and telecommunications directly increase the capital stock (K), which drives output.
- The model assumes that output is proportional to capital. More capital = more output. Therefore, investing in infrastructure directly increases productive capacity.
- Bangladesh currently faces severe infrastructure deficits: unreliable electricity supply (despite recent improvements), congested ports (Chittagong port turnaround time is among the highest in Asia), inadequate road networks outside Dhaka, and limited rail connectivity. These bottlenecks directly constrain economic output.
- Infrastructure investment can also **reduce the capital-output ratio (k)** by making existing capital more productive. A factory with reliable electricity and good road access is more productive than one without — effectively reducing the amount of capital needed to produce each unit of output.
- The **Padma Bridge** is an excellent example — by connecting southwest Bangladesh to Dhaka, it dramatically reduces transport costs and time, increasing the productivity of all economic activity in the region. Studies estimate it will add 1.2% to GDP growth.

**Priority 2: Technical Education (Second Priority)**

While not the primary focus of Harrod-Domar (which emphasizes physical capital), technical education contributes to growth by:
- Improving the quality of labor, which can reduce the capital-output ratio
- Creating skilled workers who can operate and maintain infrastructure investments
- However, in the Harrod-Domar framework, labor is not a binding constraint — capital is. The model assumes surplus labor (consistent with Bangladesh's reality of underemployment).

**Priority 3: Research and Innovation (Lowest Priority)**

Under Harrod-Domar, technological progress is not explicitly modeled. The model assumes a fixed capital-output ratio and does not account for how innovation changes this ratio. Therefore, R&D investment would receive the lowest priority — not because it is unimportant, but because the model does not recognize its growth-enhancing potential.

---

**Theory 2: Endogenous Growth Theory (Romer and Lucas) and Its Policy Implications**

**The Models:**

**Paul Romer's Knowledge/R&D Model (1990):**
- Technological progress is the result of deliberate R&D investment by profit-seeking firms
- Knowledge is **non-rival** (can be shared without diminishing) and **partially excludable** (patents)
- Knowledge generates **increasing returns** — each new idea builds on existing knowledge, creating accelerating innovation
- Growth equation: g = δ × Hₐ × φ, where δ = R&D productivity, Hₐ = human capital in R&D, φ = parameter capturing knowledge spillovers
- **Policy implication:** Invest in R&D and human capital to generate new ideas and technologies

**Robert Lucas's Human Capital Model (1988):**
- Investment in education and skills generates **positive externalities** — educated workers make everyone around them more productive
- Human capital accumulation through education can overcome diminishing returns to physical capital
- Growth rate depends on the rate of human capital accumulation
- **Policy implication:** Invest heavily in education, especially technical and higher education

**Policy Ranking Under Endogenous Growth Theory:**

**Priority 1: Research and Innovation (Highest Priority)**

Under Romer's model, R&D and innovation are the ultimate drivers of sustained economic growth:

- **Ideas are non-rival:** Unlike physical capital, a good idea can be used by everyone simultaneously without being "used up." An innovation in rice cultivation can benefit millions of farmers. A software application can serve unlimited users.
- **Increasing returns to knowledge:** Each new idea makes it easier to generate the next one. Building a stock of scientific knowledge creates a foundation for accelerating innovation.
- **Bangladesh's opportunity:** Bangladesh spends only about 0.3% of GDP on R&D (compared to South Korea's 4.5% and China's 2.4%). Even modest increases in R&D spending could yield disproportionate returns because the country can adapt and apply existing global knowledge.
- **Leapfrogging potential:** Bangladesh doesn't need to reinvent technologies — it can adapt existing innovations. Mobile financial services (bKash) demonstrated how Bangladesh can adopt and innovate upon global technologies.
- **Romer's key insight:** The constraint on growth is not physical capital but IDEAS. A country that runs out of ideas stagnates regardless of how much capital it accumulates.

**Priority 2: Technical Education (Second Priority, but close to first)**

Under Lucas's model, human capital is the engine of growth:

- **Education generates externalities:** An educated engineer doesn't just produce more herself — she teaches others, shares knowledge, raises the productivity of her co-workers. These external effects mean that social returns to education exceed private returns.
- **Human capital is needed for R&D:** You cannot do research without educated researchers. Technical education creates the human capital base that makes innovation possible.
- **Bangladesh's skills gap:** Despite near-universal primary enrollment, quality is low (World Bank's learning poverty data shows 57% of Bangladeshi children cannot read a simple story by age 10). Technical and vocational education enrollment is only about 14% of secondary students.
- **Critical for industrial upgrading:** Bangladesh cannot move beyond low-skill garment manufacturing without a technically educated workforce. Diversifying into electronics, pharmaceuticals, IT, and advanced manufacturing requires engineers, technicians, and skilled workers.

**Priority 3: Physical Infrastructure (Lowest Priority)**

Under endogenous growth theory, physical capital investment has **diminishing returns**:

- The Solow model shows that capital accumulation alone cannot sustain long-run growth because of diminishing marginal returns
- While infrastructure is necessary, it is not sufficient for sustained growth — many countries have built infrastructure without achieving sustained development
- **The "white elephant" problem:** Infrastructure without the human capital and innovation to use it productively can become a waste. A modern laboratory without trained scientists is useless. A highway in a region without economic activity to generate traffic is underutilized.

---

**Comparative Summary:**

| Policy Option | Harrod-Domar Ranking | Endogenous Growth Ranking |
|---|---|---|
| Physical Infrastructure | 1st (Highest) | 3rd (Lowest) |
| Technical Education | 2nd | 2nd |
| Research & Innovation | 3rd (Lowest) | 1st (Highest) |

**Synthesis and Recommendation for Bangladesh:**

Neither theory alone provides the complete answer. Bangladesh should adopt a **pragmatic synthesis:**

1. **Short-term priority: Infrastructure** — Bangladesh's immediate binding constraint is infrastructure deficiency. Unreliable power, congested ports, and poor connectivity impose direct costs on economic activity. Addressing these constraints yields immediate returns (consistent with Harrod-Domar).

2. **Medium-term priority: Technical Education** — Both theories agree this is important. Building human capital takes 10-20 years to yield full returns, so investment must begin now. Expanding polytechnic institutes, improving STEM education quality, and creating university-industry linkages are critical.

3. **Long-term priority: Research and Innovation** — As Bangladesh's economy matures and moves beyond low-skill manufacturing, innovation will become the primary growth driver (consistent with endogenous growth theory). Building R&D capacity now prepares for this transition.

**The critical insight** is that these investments are complementary, not substitutes. Infrastructure provides the platform for productive activity, education creates the workforce that uses that platform, and innovation generates the new products and processes that keep the economy growing in the long run. A balanced approach that sequences investment — infrastructure now, education now and ongoing, innovation building gradually — is optimal.

**Conclusion:**

Different growth theories yield different policy priorities because they identify different binding constraints on growth. The Harrod-Domar model prioritizes capital accumulation (infrastructure) while endogenous growth theory prioritizes knowledge creation (R&D and education). For Bangladesh, the optimal strategy combines immediate infrastructure investment with sustained commitment to technical education and gradually increasing R&D spending — creating the foundations for a transition from a labor-intensive to a knowledge-intensive economy.`,
  },

  // =======================================
  // CHAPTER 2: Measuring Development
  // =======================================
  {
    id: "ch2-e1",
    chapterId: 2,
    totalMarks: 2,
    difficulty: "easy",
    question: "Differentiate between GDP and GNP with a suitable example from Bangladesh.",
    answer: `**Gross Domestic Product (GDP)** and **Gross National Product (GNP)** are both measures of economic output, but they differ in their geographical and ownership scope.

**GDP (Gross Domestic Product)** measures the total monetary value of all final goods and services produced **within a country's borders** during a specific period, regardless of who owns the factors of production. It follows the **territorial principle** — if production happens within Bangladesh's borders, it counts toward Bangladesh's GDP, even if the factory is owned by a foreign company.

**GNP (Gross National Product)** — now commonly called **Gross National Income (GNI)** — measures the total value of all final goods and services produced by a country's **nationals (citizens)**, regardless of where they are located. It follows the **nationality principle**.

**The Relationship:**
**GNP = GDP + Net Factor Income from Abroad (NFIA)**
Where NFIA = Income earned by citizens abroad – Income earned by foreigners domestically

**Example from Bangladesh:**

Consider these two scenarios:

*Scenario 1:* A **South Korean company (Samsung)** operates an electronics assembly plant in Dhaka's Export Processing Zone. The plant produces goods worth Tk 500 crore annually. This production counts toward **Bangladesh's GDP** (because it is produced within Bangladesh's borders) but toward **South Korea's GNP** (because Samsung is a Korean company and the profits are repatriated to Korea).

*Scenario 2:* A **Bangladeshi worker in Saudi Arabia** earns Tk 300,000 per year and sends Tk 250,000 back home as remittances. This worker's income counts toward **Bangladesh's GNP** (because the worker is a Bangladeshi national) but toward **Saudi Arabia's GDP** (because the work is performed within Saudi territory).

**Why this distinction matters for Bangladesh:**

Bangladesh has a particularly large gap between GDP and GNP/GNI because of:

1. **Massive remittance inflows:** Over 10 million Bangladeshi workers abroad send home $20+ billion annually. These earnings are part of Bangladesh's GNP but not its GDP. This means GNP is significantly **higher** than GDP for Bangladesh.

2. **Foreign investment outflows:** Multinational companies operating in Bangladesh (garment buyers, telecom companies like Grameenphone owned by Telenor of Norway) repatriate profits abroad. This reduces GNP relative to GDP.

3. **Net effect:** Because remittances far exceed profit repatriation, Bangladesh's GNP/GNI exceeds its GDP. The World Bank classifies Bangladesh as a **lower-middle-income country** based on GNI per capita (approximately $2,800 in 2023).

**Practical significance:** For a country like Bangladesh with millions of overseas workers, **GNP/GNI is a more meaningful measure** of the income available to its citizens than GDP. It captures the purchasing power flowing into Bangladeshi households from abroad, which supports consumption, savings, investment, education, and healthcare.`,
  },
  {
    id: "ch2-e2",
    chapterId: 2,
    totalMarks: 3,
    difficulty: "easy",
    question: "What is Purchasing Power Parity (PPP)? Why is it important for comparing living standards across countries?",
    answer: `**Purchasing Power Parity (PPP)** is an economic theory and currency conversion method that adjusts exchange rates to equalize the purchasing power of different currencies. It is based on the **Law of One Price**: in the absence of transportation costs and trade barriers, identical goods should cost the same in all countries when expressed in a common currency.

**How PPP Works:**

The PPP exchange rate is the rate at which the currency of one country needs to be converted into the currency of another to buy the same basket of goods and services in both countries.

**Example:** Suppose a standard basket of goods costs **$100 in the United States** and **Tk 4,000 in Bangladesh**. The PPP exchange rate would be:
PPP rate = Tk 4,000 / $100 = **Tk 40 per dollar**

However, the **market exchange rate** might be approximately **Tk 110 per dollar**. This difference exists because non-traded goods and services (housing, haircuts, domestic transport, food from local markets) are much cheaper in Bangladesh than in the US.

**Why PPP is Important for Comparing Living Standards:**

**1. Corrects for Price Level Differences:**
Market exchange rates reflect supply and demand for currencies in financial markets, driven by trade flows, capital movements, and speculation — not by the actual cost of living in a country. A Bangladeshi family earning $2,800 per year at market exchange rates can afford far more goods and services than an American family earning $2,800, because prices in Bangladesh are much lower.

Bangladesh's per capita GNI at market exchange rate is approximately **$2,800**, but at PPP it is approximately **$6,600** — nearly 2.4 times higher. This PPP figure more accurately reflects the actual living standard of Bangladeshis.

**2. International Poverty Measurement:**
The World Bank's international poverty line is set at **$2.15 per day in 2017 PPP terms**. This means a person is considered extremely poor if they cannot afford what $2.15 would buy in the United States. Using PPP ensures this threshold reflects the same real purchasing power in every country, making poverty comparisons meaningful.

Without PPP, setting a poverty line in market-exchange-rate dollars would grossly overestimate poverty in low-price countries and underestimate it in high-price countries.

**3. Reveals True Economic Size:**
At market exchange rates, the US economy appears much larger relative to China and India. But at PPP rates, **China's economy is the world's largest**, and India's is the third largest. This matters for understanding global economic power dynamics, trade relationships, and resource allocation by international organizations.

**4. Policy and Aid Allocation:**
International organizations (World Bank, IMF, UN) use PPP-adjusted income to classify countries (low-income, lower-middle-income, etc.) and to determine eligibility for concessional loans and aid. Bangladesh's graduation from Least Developed Country (LDC) status is evaluated using PPP-adjusted per capita income among other criteria.

**Limitations of PPP:**
Despite its importance, PPP has limitations:
- **Different consumption baskets:** People in Bangladesh and the US consume very different goods. Comparing a basket of rice, lentils, and local vegetables with hamburgers, electricity, and healthcare is inherently problematic.
- **Quality differences:** A dollar's worth of healthcare or education may buy very different quality services in different countries.
- **Data collection challenges:** Price surveys across countries are expensive and methodologically complex. The International Comparison Program (ICP) conducts these surveys only every few years.
- **Non-traded goods dominate the adjustment:** Since PPP primarily corrects for cheaper non-traded services in developing countries, it may overestimate living standards by not accounting for the inferior quality of those services.

**Conclusion:** PPP is an essential tool for meaningful international comparisons of living standards, poverty, and economic size. While imperfect, it provides a far more accurate picture than market exchange rates of what people in different countries can actually afford, making it indispensable for development economics.`,
  },

  // MEDIUM
  {
    id: "ch2-m1",
    chapterId: 2,
    totalMarks: 5,
    difficulty: "medium",
    question: "Critically evaluate GDP as a measure of development. What alternative measures would you recommend and why?",
    answer: `**Gross Domestic Product (GDP)** is the most widely used economic indicator globally, measuring the total monetary value of all final goods and services produced within a country's borders during a given period. While GDP is indispensable for macroeconomic analysis, it has fundamental limitations as a measure of **development** — which encompasses not just economic output but human well-being, equality, sustainability, and freedom.

**Strengths of GDP as a Measure:**

Before critiquing GDP, it is important to acknowledge its merits:
- **Widely available and regularly updated:** GDP data exists for virtually every country and is published quarterly in many nations, enabling timely analysis and comparison.
- **Standardized methodology:** The System of National Accounts (SNA) provides a common framework, making cross-country and time-series comparisons feasible.
- **Captures economic activity:** GDP reflects the productive capacity of an economy and is strongly correlated with many development outcomes.
- **Policy relevance:** Governments and central banks rely on GDP growth rates for fiscal and monetary policy decisions.

**Critical Limitations of GDP as a Development Measure:**

**1. GDP Ignores Income Distribution (Inequality):**

GDP measures total output but says nothing about how income is distributed among the population. A country with a GDP per capita of $10,000 could have most citizens earning $2,000 while a tiny elite earns millions. The **average** obscures the reality.

*Bangladesh example:* Bangladesh's GDP has grown at 6-7% annually, but the **Gini coefficient rose from 0.33 to 0.48**, meaning inequality has worsened significantly. The richest 5% of the population captures a growing share of national income while the bottom 40% sees limited gains. GDP growth gives an overly optimistic picture of how most Bangladeshis are faring.

*Mathematical illustration:* If a village of 10 people has total income of Tk 100,000, per capita income is Tk 10,000. But if one person earns Tk 55,000 and the other nine share Tk 45,000 (Tk 5,000 each), the "average" is meaningless as a description of typical well-being.

**2. GDP Excludes Non-Market Activities:**

GDP only measures market transactions — goods and services that are bought and sold. This excludes:

- **Unpaid household work:** Cooking, cleaning, childcare, and eldercare — predominantly performed by women — have enormous economic value but are invisible in GDP. If a person hires a domestic worker, this adds to GDP; if they do the same work themselves, GDP is unchanged.
- **Subsistence agriculture:** In Bangladesh, millions of rural households grow food for their own consumption. This self-consumed output is often inadequately captured in GDP statistics.
- **Informal economy:** The informal sector in Bangladesh (domestic workers, street vendors, rickshaw pullers, small traders) employs the majority of the urban labor force but is poorly measured.
- **Volunteer work and community service:** Activities by NGOs like BRAC's community health workers may not be fully captured.

Estimates suggest that including unpaid household work could increase measured GDP by **30-50%** in developing countries.

**3. GDP is Environmentally Blind:**

GDP treats environmental destruction as **positive** economic activity:

- When a forest is clear-cut and the timber sold, GDP increases — but the loss of ecosystem services (carbon sequestration, biodiversity, water regulation, flood protection) is not subtracted.
- Pollution from factories adds to GDP (through industrial output), but the health costs of that pollution (respiratory diseases, contaminated water) are counted again when people spend money on healthcare. A single act of pollution thus adds to GDP twice.
- After a natural disaster (cyclone, flood — frequent in Bangladesh), rebuilding activities add to GDP, creating the perverse result that disasters can "boost" GDP.
- Climate change adaptation spending (seawalls, flood shelters) adds to GDP but represents a cost of environmental damage, not genuine progress.

**4. GDP Does Not Measure Quality of Life:**

Higher GDP does not automatically mean people live better lives:

- **Health:** The United States has the highest per capita healthcare spending in the world but ranks poorly among developed nations in life expectancy, infant mortality, and healthcare access. GDP does not reflect whether healthcare is accessible, affordable, or effective.
- **Education:** GDP can grow through expansion of low-quality education (more schools with poorly trained teachers) without improving actual learning outcomes. Bangladesh has achieved near-universal primary enrollment, but the World Bank's data shows 57% of 10-year-olds cannot read a simple story.
- **Leisure and work-life balance:** GDP increases when people work longer hours, but this may reduce well-being. A society where people work 60 hours per week may have higher GDP than one where they work 35 hours, but the latter may have higher quality of life.
- **Political freedom and security:** GDP says nothing about whether citizens enjoy freedom of speech, democratic governance, personal safety, or protection from discrimination.

**5. GDP Does Not Capture Sustainability:**

GDP measures current output without considering whether that level of production can be sustained:
- **Resource depletion:** Mining, overfishing, and deforestation generate current GDP but reduce future productive capacity.
- **Debt-financed growth:** Borrowing to boost current consumption increases GDP now but creates future obligations.
- **Demographic challenges:** An aging population's healthcare costs may consume GDP growth without improving well-being.

**Recommended Alternative Measures:**

**1. Human Development Index (HDI):**
A composite measure of three dimensions: health (life expectancy), education (mean and expected years of schooling), and income (GNI per capita, PPP). The HDI's key advantage is that it shifts focus from economic output to human well-being. Its use of logarithmic transformation for income reflects diminishing returns — an extra dollar matters more to a poor person.

*Advantage:* Captures multidimensional well-being; simple and transparent.
*Limitation:* Only three dimensions; national averages mask internal disparities.

**2. Inequality-Adjusted HDI (IHDI):**
Adjusts the HDI for inequality in each dimension. The greater the inequality within a country, the more the IHDI falls below the HDI. This addresses the distribution blindness of both GDP and standard HDI.

**3. Multidimensional Poverty Index (MPI):**
Measures deprivation across 10 indicators in health, education, and living standards. Unlike GDP or even HDI, the MPI identifies **who is poor** and **how they are poor** (which specific deprivations they face). This makes it invaluable for targeted policy interventions.

*For Bangladesh:* The MPI reveals that while income poverty has fallen, deprivations in nutrition, cooking fuel, and housing quality remain widespread, especially in rural areas and among ethnic minorities.

**4. Green GDP / Genuine Progress Indicator (GPI):**
Adjusts GDP for environmental degradation, resource depletion, income inequality, and non-market benefits (household work, volunteer services). GPI studies for several countries show that while GDP has risen steadily, genuine progress has stagnated or declined since the 1970s.

**5. Dashboard Approach (SDG Indicators):**
Rather than seeking a single composite measure, the Sustainable Development Goals (SDGs) provide 17 goals and 169 targets covering poverty, hunger, health, education, gender equality, clean water, energy, economic growth, inequality, environment, peace, and partnerships. This comprehensive "dashboard" acknowledges that development is too complex for any single indicator.

**Conclusion:**

GDP remains a useful and important economic indicator, but it is fundamentally inadequate as a measure of development. Development encompasses not just economic output but human well-being, equality, sustainability, and freedom. A comprehensive assessment requires a combination of measures — HDI for human capabilities, IHDI and Gini for inequality, MPI for poverty depth, and environmental indicators for sustainability. As **Robert Kennedy** famously said, GDP "measures everything except that which makes life worthwhile." For Bangladesh and other developing countries, tracking progress requires moving beyond GDP to a dashboard of indicators that reflects the multidimensional nature of genuine development.`,
  },

  // HARD
  {
    id: "ch2-h1",
    chapterId: 2,
    totalMarks: 10,
    difficulty: "hard",
    scenario: "Suppose two Bangladeshi districts have the following profiles:\nDistrict A: higher income, lower life expectancy, lower educational attainment.\nDistrict B: lower income, higher life expectancy, higher educational attainment.\nWithout calculating an HDI score, determine which district could plausibly have the higher level of human development. Explain your reasoning using the dimensions of the Human Development Index and identify one limitation of using HDI for this comparison.",
    question: "Answer the above scenario-based question with detailed analytical reasoning.",
    answer: `**Introduction:**

This question asks us to apply the conceptual framework of the Human Development Index (HDI) to compare two Bangladeshi districts with contrasting profiles. District A excels in income but lags in health and education, while District B excels in health and education but lags in income. This comparison reveals fundamental insights about what "development" means and the limitations of composite indices.

**Understanding the HDI Framework:**

The HDI, created by **Mahbub ul Haq** with **Amartya Sen's** intellectual guidance, measures development across three dimensions:

1. **Health (Long and healthy life):** Life expectancy at birth — reflects access to healthcare, nutrition, clean water, sanitation, and overall quality of life
2. **Education (Knowledge):** Combination of mean years of schooling (adults 25+) and expected years of schooling (children entering school age) — reflects access to and quality of education
3. **Standard of Living (A decent standard of living):** GNI per capita in PPP dollars, with **logarithmic transformation** — reflecting the diminishing marginal utility of income

**The critical feature:** The HDI uses the **geometric mean** (not arithmetic mean) of the three dimension indices, and income is transformed using the natural logarithm. Both features have important implications for this comparison.

---

**Analysis: Which District Plausibly Has Higher Human Development?**

**District B (lower income, higher life expectancy, higher educational attainment) plausibly has the higher level of human development.** Here is the detailed reasoning:

**Reason 1: District B outperforms in two out of three HDI dimensions**

The HDI gives equal weight (one-third each) to health, education, and income. District B leads in two dimensions (health and education) while District A leads in only one (income). Even before any quantitative analysis, winning 2-out-of-3 dimensions suggests District B likely has a higher composite score.

This is analogous to an election with three equally weighted criteria — the candidate winning on two criteria typically wins overall unless the margin of loss on those two is tiny while the margin of victory on the third is enormous.

**Reason 2: The logarithmic transformation of income reduces the impact of higher income**

The HDI uses **ln(GNI per capita)** rather than raw GNI per capita. This logarithmic transformation reflects the economic principle of **diminishing marginal utility of income** — each additional unit of income contributes less to well-being than the previous one.

**Mathematical illustration:**

Suppose District A has per capita income of Tk 100,000/year and District B has Tk 60,000/year.

Without log transformation:
- District A's advantage: 100,000 - 60,000 = 40,000 (a 67% advantage)

With log transformation:
- ln(100,000) = 11.51
- ln(60,000) = 11.00
- District A's advantage: 11.51 - 11.00 = 0.51 (only a 4.6% advantage)

The logarithmic transformation dramatically compresses income differences. District A's income advantage, while substantial in absolute terms, translates into a much smaller advantage in the HDI's income dimension. This is because the HDI recognizes that the difference between earning Tk 5,000 and Tk 15,000 (basic needs fulfillment) matters much more for well-being than the difference between Tk 80,000 and Tk 100,000 (comfort vs. slightly more comfort).

**Reason 3: Health and education directly reflect capabilities**

In the **capabilities approach** that underpins the HDI, health and education directly represent human capabilities — what people can do and be:

**District B's higher life expectancy** means:
- Better access to healthcare facilities and qualified medical professionals
- Better nutrition and food security
- Cleaner water and sanitation
- Lower infant and maternal mortality
- Healthier environment
- These represent direct improvements in the most fundamental capability — being alive and healthy

**District B's higher educational attainment** means:
- Greater literacy and numeracy
- Better access to schools and qualified teachers
- Higher skill levels enabling better employment opportunities
- Greater awareness of health, nutrition, rights, and opportunities
- Enhanced ability to participate in civic and political life
- Intergenerational benefits — educated parents invest more in children's education

**District A's higher income** is merely an **instrumental** capability — it matters only insofar as it enables people to achieve other things (better health, education, nutrition, housing). If District A's higher income has NOT translated into better health or education, this suggests:
- Income may be concentrated among a few (inequality)
- Income may be spent on non-developmental consumption
- Institutional failures may prevent income from translating into service delivery
- Environmental degradation or other factors may undermine health despite higher income

**Reason 4: Real-world examples support this interpretation**

Several real-world cases demonstrate that health-education-rich, income-poor regions often have higher human development than the reverse:

- **Kerala vs. Punjab (India):** Kerala has lower per capita income than Punjab but dramatically higher life expectancy (76 vs. 72), literacy (94% vs. 76%), and lower infant mortality. Kerala's HDI is significantly higher, demonstrating that income does not determine development.
- **Cuba vs. oil-rich Middle Eastern countries:** Cuba, despite modest income, achieves life expectancy and literacy rates comparable to the United States. Some oil-rich countries with much higher per capita income have lower HDI scores.
- **Sri Lanka vs. richer South Asian neighbors:** Sri Lanka achieved high human development indicators (life expectancy 76, literacy 92%) despite lower per capita income than some neighbors.
- **Bangladesh's own story:** Bangladesh's HDI exceeds what its income alone would predict, precisely because of remarkable achievements in health (life expectancy 73) and education (near-universal primary enrollment, gender parity).

**Reason 5: The geometric mean penalizes extreme imbalances**

The HDI uses the geometric mean rather than the arithmetic mean to combine the three dimension indices. The geometric mean **penalizes unbalanced development** — it gives a lower score when dimensions are very unequal compared to when they are balanced.

*Example:*
Suppose dimension indices are:
- District A: Health = 0.5, Education = 0.4, Income = 0.8
  - Geometric mean = (0.5 × 0.4 × 0.8)^(1/3) = (0.16)^(1/3) = **0.543**
- District B: Health = 0.7, Education = 0.7, Income = 0.6
  - Geometric mean = (0.7 × 0.7 × 0.6)^(1/3) = (0.294)^(1/3) = **0.665**

District B's balanced profile yields a **significantly higher HDI** despite lower income. District A's good income cannot compensate for poor health and education because of the geometric mean's penalization of imbalance.

---

**One Limitation of Using HDI for This Comparison:**

**Limitation: HDI uses national/district AVERAGES that mask internal inequality and distribution.**

The HDI (and its component indices) uses averages — average life expectancy, average years of schooling, average income. These averages can hide enormous disparities within a district:

*Within District A (higher income):*
- The "higher income" might reflect a few wealthy landowners or factory owners earning very high incomes while the majority earns much less. The average is pulled up by outliers.
- Life expectancy might be low not because healthcare is universally poor but because a particular marginalized group (e.g., char dwellers, ethnic minorities, landless laborers) faces severe health deprivation while the urban elite has excellent healthcare.

*Within District B (lower income):*
- The "lower income" might be more evenly distributed — most people earn a modest but adequate income, resulting in a lower average but more widespread well-being.
- Higher life expectancy might reflect good public health infrastructure (community clinics, vaccination programs) that benefits everyone.

**The Inequality-Adjusted HDI (IHDI)** was created precisely to address this limitation. When adjusted for inequality, many districts and countries see their HDI drop significantly. A district with low inequality would see its IHDI remain close to its HDI, while a district with high inequality (District A's likely profile, given concentrated income) would see a much larger reduction.

**Other notable limitations:**
- HDI uses only **years of schooling**, not **quality** of education. District B might have more years of schooling but poor learning outcomes, or vice versa.
- HDI does not capture **environmental quality**, **safety/security**, **gender equality**, or **political freedom** — all of which affect human development.
- HDI is a static snapshot and does not capture **vulnerability** or **resilience** to shocks (floods, cyclones, economic crises).

---

**Conclusion:**

District B — with lower income but higher life expectancy and higher educational attainment — **plausibly has the higher level of human development**. This conclusion rests on four reinforcing arguments: (1) District B leads in two of three dimensions; (2) the logarithmic transformation of income diminishes District A's income advantage; (3) health and education directly represent capabilities while income is merely instrumental; and (4) the geometric mean used in HDI penalizes District A's unbalanced profile.

This comparison beautifully illustrates the core message of the Human Development Reports: **"People are the real wealth of nations."** Income is a means to development, not an end in itself. When a society invests in the health and education of its people, it creates genuine development that goes beyond what income alone can capture. The key limitation — that averages mask inequality — reminds us that even the HDI, while superior to GDP alone, requires supplementary measures to fully capture the distribution and depth of human development.`,
  },

  // =======================================
  // CHAPTER 6: Poverty (matching exam paper pattern exactly)
  // =======================================
  {
    id: "ch6-e1",
    chapterId: 6,
    totalMarks: 3,
    difficulty: "easy",
    question: "Define absolute poverty and relative poverty. Give one example of each from the Bangladesh context.",
    answer: `**Absolute Poverty** is a condition in which individuals or households fall below a defined minimum income or consumption threshold required to meet basic needs — food, shelter, clothing, and healthcare. This threshold, called the **poverty line**, is fixed in real terms and does not change with the overall income level of society.

In Bangladesh, the **Cost of Basic Needs (CBN)** method defines the poverty line. The **Upper Poverty Line (UPL)** includes the cost of food providing 2,122 kilocalories per person per day plus an allowance for essential non-food expenditure. The **Lower Poverty Line (LPL)** covers only the food component and identifies those in **extreme poverty**.

*Bangladesh example:* A family in rural Rangpur earning Tk 3,500 per month per capita, which is below the official poverty line of approximately Tk 6,000 per month, lives in absolute poverty. They cannot afford adequate nutrition (2,122 kcal/day), basic healthcare, or adequate housing. According to BBS data, approximately 18.7% of Bangladesh's population falls below the upper poverty line (2022).

Internationally, the World Bank defines extreme poverty as living on less than **$2.15 per day** (2017 PPP). By this measure, approximately 5% of Bangladeshis live in extreme absolute poverty.

**Relative Poverty** is defined in relation to the living standards of the majority of a society. A person is relatively poor if their income or resources are significantly below the average or median for their society, even if their basic needs are technically met. Relative poverty reflects **social exclusion** and the inability to participate in the normal activities and customs of society.

Unlike absolute poverty, relative poverty changes as a society becomes richer — the poverty line moves upward with rising average income. In the European Union, relative poverty is defined as living below 60% of median household income.

*Bangladesh example:* Consider a garment worker in Dhaka earning the minimum wage of Tk 12,500 per month. This worker may be above the absolute poverty line (basic needs are marginally met), but she is **relatively poor** compared to the urban middle class earning Tk 50,000-100,000 per month. She cannot afford her children's private school fees, adequate healthcare, safe housing, or recreational activities that middle-class Bangladeshis take for granted. She is socially excluded from many aspects of urban life despite being above the absolute poverty threshold.

**Key Distinction:** Absolute poverty can theoretically be eliminated (by raising everyone above the poverty line), but relative poverty exists as long as inequality exists — even in wealthy societies. A country could have zero absolute poverty but significant relative poverty if income gaps are wide.`,
  },
  {
    id: "ch6-exam1",
    chapterId: 6,
    totalMarks: 10,
    difficulty: "hard",
    scenario: "A survey of five households in Khulna records the following monthly per capita incomes: Tk 4,000, Tk 5,000, Tk 5,800, Tk 7,500 and Tk 10,000. Assume the poverty line is Tk 6,000 per person per month.",
    question: "Based on the above data, answer the following parts:",
    subQuestions: [
      {
        part: "a",
        marks: 3,
        question: "Identify the households classified as poor and calculate the poverty headcount ratio.",
        answer: `**Identifying Poor Households:**

The poverty line is **Tk 6,000 per person per month**. Any household with per capita income below this threshold is classified as poor.

| Household | Monthly Per Capita Income (Tk) | Status |
|-----------|-------------------------------|--------|
| Household 1 | 4,000 | **Poor** (4,000 < 6,000) |
| Household 2 | 5,000 | **Poor** (5,000 < 6,000) |
| Household 3 | 5,800 | **Poor** (5,800 < 6,000) |
| Household 4 | 7,500 | Non-poor (7,500 > 6,000) |
| Household 5 | 10,000 | Non-poor (10,000 > 6,000) |

**Three households** (Households 1, 2, and 3) are classified as poor.

**Calculating the Headcount Ratio (H):**

The headcount ratio is the simplest measure of poverty, calculated as:

**H = q / n**

Where:
- q = number of poor households = **3**
- n = total number of households = **5**

**H = 3/5 = 0.60 = 60%**

**Interpretation:** The poverty headcount ratio of 60% means that **60% of the surveyed households** in this Khulna community live below the poverty line. In other words, three out of every five households cannot afford the minimum basket of goods and services required for a basic standard of living (valued at Tk 6,000 per person per month).

This is a very high poverty rate compared to the national average of approximately 18.7% (2022), suggesting that this particular community in Khulna faces severe deprivation. Khulna division has historically been one of the more economically disadvantaged regions of Bangladesh, and this finding is consistent with broader patterns of spatial inequality in the country.`,
      },
      {
        part: "b",
        marks: 4,
        question: "Explain why the headcount ratio alone may not adequately describe the extent of poverty in this community.",
        answer: `The headcount ratio (H = 60%) tells us that 60% of households are poor, but it suffers from several critical limitations that make it an **inadequate standalone measure** of poverty in this community:

**1. It Ignores the Depth (Intensity) of Poverty:**

The headcount ratio treats all poor households identically, regardless of how far below the poverty line they fall. In our data:

- Household 1 earns **Tk 4,000** — a shortfall of Tk 2,000 below the poverty line (33.3% below)
- Household 2 earns **Tk 5,000** — a shortfall of Tk 1,000 (16.7% below)
- Household 3 earns **Tk 5,800** — a shortfall of only Tk 200 (3.3% below)

Household 1 is in **far deeper poverty** than Household 3 — its income gap is ten times larger. Yet the headcount ratio counts both equally as "one poor household." This is like a doctor counting patients as merely "sick" or "not sick" without distinguishing between a mild cold and a life-threatening disease.

The **Poverty Gap Index** (FGT with α=1) addresses this by measuring the average distance below the poverty line:

PG = (1/5) × [(6,000-4,000)/6,000 + (6,000-5,000)/6,000 + (6,000-5,800)/6,000]
PG = (1/5) × [2,000/6,000 + 1,000/6,000 + 200/6,000]
PG = (1/5) × [0.333 + 0.167 + 0.033]
PG = (1/5) × 0.533
**PG = 0.107 or 10.7%**

This tells us that the average poverty gap is 10.7% of the poverty line — meaning it would take approximately 10.7% of the poverty line multiplied by the total population to theoretically eliminate poverty through perfectly targeted transfers.

**2. It Ignores Inequality Among the Poor:**

The headcount ratio does not distinguish between a community where all poor households are clustered just below the poverty line and one where some are far below while others are near it. In our data, there is significant inequality among the poor:

- Household 1 is **deeply poor** (Tk 4,000)
- Household 3 is **marginally poor** (Tk 5,800, just Tk 200 below the line)

The **Squared Poverty Gap** (FGT with α=2) captures this by giving greater weight to those furthest below the line:

SPG = (1/5) × [(0.333)² + (0.167)² + (0.033)²]
SPG = (1/5) × [0.111 + 0.028 + 0.001]
SPG = (1/5) × 0.140
**SPG = 0.028 or 2.8%**

The squared poverty gap reveals that the severity of poverty is concentrated in the poorest household (Household 1), which contributes 0.111 out of the total 0.140 — nearly 80% of the severity index.

**3. It Creates Perverse Policy Incentives:**

A government trying to reduce the headcount ratio would rationally focus on helping Household 3 (which needs only Tk 200/month to cross the poverty line) rather than Household 1 (which needs Tk 2,000/month). Helping one person cross the line reduces H by the same amount regardless of how poor they were. This creates an incentive to help the "easiest" cases — those closest to the line — while ignoring the most desperately poor.

A policy that transfers Tk 200 to Household 3 reduces H from 60% to 40% (a 20 percentage-point improvement at a cost of Tk 200). But this does nothing for the much more deprived Households 1 and 2.

**4. It Is Blind to Near-Poor Vulnerability:**

Household 4 (Tk 7,500) is classified as non-poor, but it is only Tk 1,500 above the poverty line. A single shock — illness, job loss, a flood, or price increase — could push it below the line. The headcount ratio provides no information about this vulnerability. A comprehensive poverty analysis should identify the **near-poor** who are at risk of falling into poverty.

**5. It Does Not Capture Non-Income Deprivations:**

The headcount ratio is based solely on income (or consumption). But poverty is multidimensional — a household above the income poverty line may still lack access to clean water, adequate sanitation, electricity, education, or healthcare. The **Multidimensional Poverty Index (MPI)** addresses this by measuring deprivation across health, education, and living standards indicators.

**Conclusion:** While the headcount ratio provides a useful starting point — telling us that 60% of households are poor — it must be supplemented with the poverty gap index (depth), squared poverty gap (severity), and multidimensional measures to fully understand poverty in this Khulna community and design effective interventions.`,
      },
      {
        part: "c",
        marks: 3,
        question: "Suggest one additional indicator that could help the local authority identify the needs of poor households more accurately. Explain your choice.",
        answer: `**Recommended Additional Indicator: The Multidimensional Poverty Index (MPI)**

I recommend the **Multidimensional Poverty Index (MPI)**, developed by Sabina Alkire and James Foster (2010) and published by UNDP and OPHI, as the most valuable additional indicator for this Khulna community.

**What the MPI Measures:**

The MPI goes beyond income to measure poverty across **three dimensions** using **ten indicators:**

| Dimension (Weight) | Indicators | Deprivation Cutoff |
|---|---|---|
| **Health** (1/3) | Nutrition (1/6) | Any household member is malnourished (BMI < 18.5 for adults, stunting/wasting for children) |
| | Child Mortality (1/6) | Any child has died in the household in the past 5 years |
| **Education** (1/3) | Years of Schooling (1/6) | No household member has completed 6+ years of schooling |
| | School Attendance (1/6) | Any school-age child is not attending school |
| **Living Standards** (1/3) | Cooking Fuel (1/18) | Household uses dung, wood, or charcoal for cooking |
| | Sanitation (1/18) | No improved sanitation facility or shared facility |
| | Drinking Water (1/18) | No access to safe drinking water within 30 min walk |
| | Electricity (1/18) | No access to electricity |
| | Housing (1/18) | Floor, walls, or roof made of inadequate materials |
| | Assets (1/18) | Household does not own more than one of: radio, TV, telephone, bicycle, motorbike, refrigerator; AND does not own a car or truck |

A person is classified as **MPI-poor** if they are deprived in at least one-third of the weighted indicators.

**Why the MPI Is Particularly Valuable for This Khulna Community:**

**1. It Reveals Hidden Deprivations That Income Misses:**

Consider Household 4 (Tk 7,500, classified as non-poor by income). Despite being above the income poverty line, this household might:
- Live in a house with a tin roof that leaks during monsoon and dirt floors
- Use wood or cow dung for cooking (causing indoor air pollution — a leading cause of respiratory disease)
- Lack access to a sanitary latrine (using open defecation or a shared pit latrine)
- Have children who are malnourished despite adequate income (due to poor dietary knowledge or lack of diverse food markets)

The income-based headcount ratio would miss this household entirely, but the MPI would identify it as multidimensionally poor and flag specific deprivations for intervention.

Conversely, Household 3 (Tk 5,800, classified as income-poor) might live in a decent house with electricity, sanitary latrine, and clean water, and have children attending school — making it not MPI-poor despite being income-poor. This matters for policy: Household 3 may need only a small income supplement, not a comprehensive intervention.

**2. It Tells Policymakers WHICH Deprivations to Address:**

The MPI is **decomposable by indicator** — it reveals the specific nature of poverty. For this Khulna community, the MPI might reveal:
- 80% of poor households lack improved sanitation → priority: latrine construction program
- 60% use dirty cooking fuel → priority: clean cookstove distribution
- 40% have malnourished children → priority: nutrition supplementation program
- 30% have children out of school → priority: school attendance incentives

This specificity is invaluable for local authorities who need to design targeted interventions rather than general income-support programs.

**3. It Can Be Decomposed by Region and Group:**

The MPI can identify which specific areas within Khulna district (rural vs. urban, specific upazilas, char areas vs. mainland) have the highest multidimensional poverty and which groups (female-headed households, ethnic minorities, landless laborers, fishermen) are most deprived. This spatial and group-level decomposition is essential for equitable resource allocation.

**4. It Captures Overlapping Deprivations:**

A household might be simultaneously deprived in nutrition AND sanitation AND education — these overlapping deprivations compound each other (malnourished children learn less, unsanitary conditions worsen health, lack of education perpetuates poverty). The MPI captures these intersections while income measures cannot.

**Conclusion:** The MPI would enable Khulna's local authorities to move beyond simply counting how many households are below an income line to understanding **the nature, depth, and pattern of poverty** in their community. This information is essential for designing effective, targeted interventions that address the specific deprivations people face, rather than assuming that income transfers alone will solve multidimensional poverty.`,
      },
    ],
  },

  // =======================================
  // CHAPTER 7: Inequality (matching exam pattern)
  // =======================================
  {
    id: "ch7-exam1",
    chapterId: 7,
    totalMarks: 10,
    difficulty: "hard",
    scenario: "A report shows that average income in a district of Bangladesh has increased, but many low-income households report little improvement in their living standards.",
    question: "Based on the above scenario, answer the following parts:",
    subQuestions: [
      {
        part: "a",
        marks: 3,
        question: "Why does average income alone fail to show how equally income is distributed?",
        answer: `**Average income (arithmetic mean)** is calculated by dividing total income by total population. While useful as a summary statistic, it fundamentally fails to capture the distribution of income for several important reasons:

**1. The Average is Distorted by Extreme Values (Outliers):**

The arithmetic mean is heavily influenced by extreme values at the top of the distribution. If a few very wealthy households earn disproportionately high incomes, they pull the average upward, creating a misleading impression of typical well-being.

**Numerical illustration:** Consider a simplified district with 5 households:
- Household incomes: Tk 5,000; Tk 6,000; Tk 7,000; Tk 8,000; **Tk 50,000**
- Average income = (5,000 + 6,000 + 7,000 + 8,000 + 50,000) / 5 = Tk 76,000 / 5 = **Tk 15,200**

The average of Tk 15,200 is higher than what 80% of households actually earn. Only one household (the richest) earns above the average. The average gives the false impression that the "typical" household earns Tk 15,200, when in reality, four out of five households earn far less.

Now suppose the richest household's income increases from Tk 50,000 to Tk 100,000:
- New average = (5,000 + 6,000 + 7,000 + 8,000 + 100,000) / 5 = **Tk 25,200**
- The average increased by Tk 10,000 (66% increase), but the bottom four households saw **zero improvement**

This is precisely the scenario described — average income has increased, but low-income households report no improvement because the gains were captured entirely by the wealthy.

**2. Average Income Says Nothing About the Shape of the Distribution:**

Two very different societies can have the same average income:

*Society X (relatively equal):*
Incomes: Tk 8,000; Tk 9,000; Tk 10,000; Tk 11,000; Tk 12,000
Average = Tk 10,000

*Society Y (highly unequal):*
Incomes: Tk 2,000; Tk 3,000; Tk 4,000; Tk 6,000; Tk 35,000
Average = Tk 10,000

Both societies have the same average income of Tk 10,000, but the lived experience of their citizens is vastly different. In Society X, everyone lives reasonably well. In Society Y, 80% of people live in poverty while one household is wealthy. The average cannot distinguish between these fundamentally different situations.

**3. The Median Is More Informative but Still Insufficient:**

The **median** (middle value when incomes are arranged in order) is less affected by outliers and better represents the "typical" household. In our first example:
- Median = Tk 7,000 (much lower than the mean of Tk 15,200)

When the richest household's income doubles, the median remains Tk 7,000 — correctly reflecting that the typical household saw no improvement. However, even the median cannot tell us about the full shape of the distribution — how spread out incomes are, or how different the top and bottom look.

**Conclusion:** Average income is a useful summary statistic but a fundamentally inadequate measure of distributional equity. It masks inequality by hiding the spread, skewness, and concentration of income. To understand how equally income is distributed, we need distributional measures such as income shares, the Lorenz Curve, and the Gini coefficient.`,
      },
      {
        part: "b",
        marks: 3,
        question: "Explain how comparing the income shares of the richest 20% and poorest 20% of households can help measure inequality.",
        answer: `**Income share comparison** (also called the **quintile ratio** or **Palma ratio** approach) is one of the simplest and most intuitive methods for measuring inequality. It involves dividing the population into groups (typically quintiles — five groups of 20% each) ranked by income and comparing the share of total income received by each group.

**How It Works:**

Step 1: Rank all households from poorest to richest.
Step 2: Divide them into quintiles (five equal groups of 20%).
Step 3: Calculate the percentage of total income received by each quintile.
Step 4: Compare the shares of the richest and poorest quintiles.

**Application to the Bangladeshi District:**

Suppose the district has 100 households with total income of Tk 50,00,000 (50 lakh). The income share distribution might look like:

| Quintile | % of Population | % of Total Income | Per Household Average |
|----------|----------------|-------------------|----------------------|
| Poorest 20% | 20% (20 HH) | 5% (Tk 2,50,000) | Tk 12,500 |
| 2nd 20% | 20% (20 HH) | 9% (Tk 4,50,000) | Tk 22,500 |
| 3rd 20% | 20% (20 HH) | 14% (Tk 7,00,000) | Tk 35,000 |
| 4th 20% | 20% (20 HH) | 22% (Tk 11,00,000) | Tk 55,000 |
| Richest 20% | 20% (20 HH) | **50%** (Tk 25,00,000) | **Tk 1,25,000** |

**Key Comparisons:**

**1. The 20:20 Ratio (Quintile Ratio):**
Richest 20% share / Poorest 20% share = 50% / 5% = **10:1**
This means the richest 20% receive **ten times** the income of the poorest 20%. In a perfectly equal society, this ratio would be 1:1 (each 20% receives 20% of income).

**2. The Palma Ratio (richest 10% share / poorest 40% share):**
This is an increasingly popular measure because research shows the "middle" 50% (5th to 9th deciles) receive a remarkably stable share of about 50% of income across countries. What varies is how the remaining 50% is shared between the top 10% and bottom 40%.

**How This Helps Measure Inequality:**

- **Intuitive and easy to communicate:** Telling citizens that "the richest 20% earn 10 times more than the poorest 20%" is much more meaningful and understandable than reporting a Gini coefficient of 0.48.
- **Identifies where inequality occurs:** By examining all five quintiles, we can see whether inequality is driven by extreme wealth at the top, extreme poverty at the bottom, or both.
- **Tracks changes over time:** If the report shows average income has risen but the poorest 20%'s share has declined from 7% to 5%, this clearly demonstrates that growth has been unequalizing.
- **Policy targeting:** If the poorest 20% receive only 5% of income, this identifies the bottom quintile as the target for redistributive policies (cash transfers, subsidized education, healthcare).

**For the scenario in question:** Comparing income shares would directly show that while average income rose (because the total pie grew), the poorest quintile's **share** of that pie may have declined or stagnated. Even if their absolute income rose slightly, their relative position worsened — explaining why they "report little improvement" despite rising averages. The psychological impact of falling behind while others surge ahead is a real dimension of poverty and deprivation.

**Limitation:** Income share comparisons, while intuitive, do not capture the full distribution within quintiles, and the quintile grouping is somewhat arbitrary (why 20% and not 10%?). The **Lorenz Curve** provides a more complete visual picture, and the **Gini coefficient** provides a single summary statistic.`,
      },
      {
        part: "c",
        marks: 4,
        question: "What does the Gini coefficient tell us about income inequality? Explain what a higher Gini coefficient generally indicates.",
        answer: `**The Gini Coefficient** is the most widely used single-number measure of income inequality, developed by Italian statistician **Corrado Gini** in 1912. It summarizes the entire income distribution into a single value between **0 and 1** (or equivalently, 0 to 100).

**What the Gini Coefficient Measures:**

The Gini coefficient measures the extent to which the actual distribution of income deviates from a hypothetical perfectly equal distribution. It is derived from the **Lorenz Curve**.

**Derivation from the Lorenz Curve:**

The **Lorenz Curve** is a graph where:
- The **x-axis** shows the cumulative percentage of the population, ranked from poorest to richest
- The **y-axis** shows the cumulative percentage of total income received
- The **45° diagonal line** represents perfect equality (where x% of the population receives exactly x% of income)

The Lorenz Curve always lies below the equality line (except at the endpoints 0,0 and 100,100). The further it bows below the equality line, the greater the inequality.

**Gini Coefficient = Area A / (Area A + Area B)**

Where:
- **Area A** = the area between the line of perfect equality and the Lorenz Curve
- **Area B** = the area below the Lorenz Curve
- Since the total area under the 45° line = 0.5, we can also write: **Gini = 2A = 1 – 2B**

[Visual description of the graph: Imagine a square with the x-axis labeled "Cumulative % of Population (poorest to richest)" from 0% to 100%, and y-axis labeled "Cumulative % of Income" from 0% to 100%. The 45° diagonal line goes from bottom-left to top-right (line of perfect equality). The Lorenz Curve bows below this line. Area A is between the two lines. Area B is below the Lorenz Curve.]

**Interpretation of Gini Values:**

| Gini Coefficient | Level of Inequality | Real-World Examples |
|---|---|---|
| **0.00** | Perfect equality — everyone has the same income | Theoretical; never observed |
| **0.20–0.30** | Low inequality | Scandinavian countries: Denmark (0.28), Sweden (0.29), Norway (0.27) |
| **0.30–0.40** | Moderate inequality | Germany (0.31), France (0.32), Canada (0.33) |
| **0.40–0.50** | High inequality | USA (0.39), China (0.47), **Bangladesh (0.48)** |
| **0.50–0.60** | Very high inequality | Brazil (0.53), Colombia (0.54) |
| **0.60+** | Extreme inequality | South Africa (0.63) — one of the most unequal countries |
| **1.00** | Perfect inequality — one person has all income | Theoretical; never observed |

**What a Higher Gini Coefficient Indicates:**

A **higher Gini coefficient indicates greater income inequality** — a larger gap between the rich and poor. Specifically:

**1. Greater Concentration of Income:**
A Gini of 0.48 (Bangladesh) means that income is significantly more concentrated among the wealthy compared to a country with a Gini of 0.28 (Denmark). In Bangladesh, the richest 10% capture approximately 35% of national income, while the poorest 10% receive only about 3.5%.

**2. The Lorenz Curve Bows Further from Equality:**
Graphically, a higher Gini means the Lorenz Curve sags further away from the 45° line of equality. If you compare the Lorenz Curves of Bangladesh and Denmark, Bangladesh's curve would bow much further below the equality line, indicating that the bottom segments of the population receive a much smaller share of total income.

**3. Social and Economic Implications:**
A higher Gini is associated with:
- **Greater poverty persistence:** Inequality makes it harder for the poor to escape poverty through growth alone (a larger share of growth accrues to the already wealthy)
- **Lower social mobility:** In more unequal societies, children's future income is more strongly determined by their parents' income
- **Worse health outcomes:** Wilkinson and Pickett's research shows that more unequal societies have higher rates of mental illness, drug abuse, obesity, teenage pregnancy, and lower life expectancy
- **Political instability:** Extreme inequality can fuel social unrest, crime, and political polarization
- **Reduced economic growth:** IMF research shows that high inequality reduces the duration of growth spells — very unequal societies tend to experience shorter periods of sustained growth

**4. Policy Implications:**
A rising Gini (as in Bangladesh, from 0.33 in 1991 to 0.48 recently) signals that economic growth is not being shared equitably. This calls for:
- Progressive taxation (higher tax rates on higher incomes)
- Expanded social safety nets (targeted cash transfers to the poorest)
- Investment in public education and healthcare (equalizing opportunities)
- Minimum wage enforcement
- Land reform and asset redistribution

**Limitations of the Gini Coefficient:**

While the Gini is invaluable, it has limitations:
- **Same Gini, different distributions:** Two countries can have the same Gini but very different inequality patterns (one with a large middle class and extremes at both ends; another with a small elite and a large poor majority)
- **Insensitive to where inequality occurs:** The Gini is equally sensitive to transfers at the top and bottom of the distribution, even though transfers among the poor may be socially more important
- **Cannot decompose by source:** The Gini does not tell us whether inequality comes from wage differences, capital income, land ownership, or other factors
- **Single number loses information:** Any single-number summary of an entire distribution inevitably loses detail

**Conclusion:** The Gini coefficient is an essential tool for measuring and comparing inequality. For the district in this scenario, a high and rising Gini would explain why average income has increased while low-income households see little improvement — the gains from growth are being captured disproportionately by the wealthy, leaving the poor relatively worse off despite overall economic expansion.`,
      },
    ],
  },

  // =======================================
  // CHAPTER 8: Institutions (matching exam pattern)
  // =======================================
  {
    id: "ch8-exam1",
    chapterId: 8,
    totalMarks: 10,
    difficulty: "hard",
    scenario: "In a rural area of Khulna, a small group of influential traders controls access to crop storage, price information and market facilities. Small farmers have little bargaining power, face questionable weighing practices, and find it difficult to challenge unfair deductions. The local administration considers introducing transparent pricing, independent weighing facilities and a farmers' cooperative.",
    question: "Based on the above scenario, answer the following parts:",
    subQuestions: [
      {
        part: "a",
        marks: 4,
        question: "Explain why the existing arrangements may be considered extractive institutions.",
        answer: `The existing arrangements in this Khulna market fit the definition of **extractive institutions** as conceptualized by **Daron Acemoglu and James Robinson** in their seminal work "Why Nations Fail" (2012). Extractive institutions are designed to **extract income and wealth from one subset of society to benefit a different subset** — in this case, extracting value from small farmers to benefit a small group of influential traders.

**1. Concentrated Control Over Essential Economic Resources:**

The traders control three critical market functions:
- **Crop storage:** Small farmers lack storage facilities and must sell immediately after harvest (when prices are lowest) or pay the traders for storage. This gives traders enormous leverage — they can buy cheaply at harvest time, store the crops, and sell at higher prices later. The farmers cannot hold out for better prices because they lack alternative storage options.
- **Price information:** Information is power in any market. When traders monopolize price information, they can pay farmers below-market prices and the farmers have no way to know what their crops are actually worth. This **information asymmetry** is a classic feature of extractive arrangements — it keeps the exploited party ignorant and dependent.
- **Market access:** By controlling market facilities, traders become unavoidable intermediaries. Farmers cannot sell directly to consumers or other buyers; they must go through the traders who extract a large portion of the value.

This triple monopoly over storage, information, and market access creates a **structural power imbalance** that is the hallmark of extractive institutions.

**2. Rent-Seeking Through Unfair Practices:**

The scenario describes two specific extractive practices:

- **Questionable weighing practices:** Traders use rigged or inaccurate scales to systematically underweigh farmers' produce, paying them for less than they actually deliver. If a farmer brings 100 kg of rice but the trader's scale shows 90 kg, the farmer loses 10% of their income on every transaction. Over time, this systematic theft transfers enormous wealth from farmers to traders.

- **Unfair deductions:** Traders impose arbitrary deductions for "quality," "moisture content," "handling fees," or other pretexts. These deductions are non-transparent and non-negotiable, further reducing the price farmers receive. Because farmers have no independent quality assessment, they cannot challenge these deductions.

In institutional economics terms, these practices represent **rent-seeking** — extracting income not through productive activity but through exploitation of a privileged position. The traders do not add value proportional to their extraction; they profit from their monopoly position rather than from efficient service provision.

**3. Absence of Voice and Accountability:**

The scenario notes that farmers "find it difficult to challenge unfair deductions." This indicates:

- **No grievance mechanism:** There is no neutral authority to whom farmers can complain. The traders are both the market operators and the beneficiaries of unfair practices.
- **Power imbalance prevents challenge:** Small, individual farmers cannot confront wealthy, politically connected traders. Challenging the traders might result in exclusion from the market entirely — a devastating consequence for farmers with no alternative outlet.
- **Political capture:** In many rural Bangladeshi markets, influential traders have connections to local political leaders, law enforcement, and administrative officials. This means that even if farmers complain, the system protects the traders rather than the farmers.

This mirrors Acemoglu and Robinson's analysis of how extractive political institutions reinforce extractive economic institutions — those with economic power use it to gain political influence, which they then use to maintain their economic privileges.

**4. Barriers to Entry and Innovation:**

Extractive institutions typically prevent new entrants and innovation:
- Other potential traders or buyers are kept out of the market through the existing group's control of facilities and political connections
- Farmers cannot establish their own cooperatives, storage, or direct marketing channels because the existing traders actively resist competition
- Technology that could help farmers (mobile price apps, digital weighing) is not adopted because it would undermine the traders' information advantage

**5. Historical and Theoretical Context:**

This situation is not unique to Khulna — it reflects patterns observed across developing countries:
- In **Douglass North's** framework, these arrangements represent institutions (informal rules and enforcement) that generate high **transaction costs** for farmers while providing rents to traders
- In **Hernando de Soto's** analysis, farmers may lack formal property rights or contracts that would give them legal standing to challenge unfair practices
- The situation resembles what North, Wallis, and Weingast (2009) call a **"Limited Access Order"** — where economic opportunities are restricted to a small group of elites who use their position to extract rents and prevent competition

**Conclusion:** The existing arrangements are textbook extractive institutions because they: (a) concentrate economic power in a small elite group; (b) extract value from the majority (farmers) through unfair and non-transparent practices; (c) deny voice and accountability to the exploited party; and (d) prevent competition and innovation that might challenge the existing power structure. These institutions perpetuate rural poverty and inequality in Khulna by ensuring that the surplus generated by farmers' labor is captured by traders rather than being reinvested in agricultural productivity and rural development.`,
      },
      {
        part: "b",
        marks: 3,
        question: "Explain how the proposed measures could help establish more inclusive institutions.",
        answer: `The three proposed measures — **transparent pricing, independent weighing facilities, and a farmers' cooperative** — directly address the three pillars of extractive institutional control (information monopoly, unfair measurement, and lack of farmer organization). Together, they would transform the market from an extractive to a more **inclusive institutional** framework.

**1. Transparent Pricing → Breaking the Information Monopoly:**

*How it creates inclusivity:*
- Transparent pricing would mean publicly displaying market prices for different crops, grades, and quantities. Farmers would know what their produce is worth **before** negotiating with traders.
- Price boards, regular market bulletins, or mobile phone-based price information systems (like Bangladesh's agricultural information services) would give farmers access to the same information that traders currently monopolize.
- When farmers know the prevailing market price, they can refuse below-market offers and negotiate from a position of knowledge rather than ignorance.

*Inclusive institutional principle:* **Equal access to information** is a cornerstone of inclusive institutions. Acemoglu and Robinson emphasize that inclusive institutions provide a **level playing field** where all participants have access to the same opportunities and information. Transparent pricing creates this level playing field by eliminating the traders' information advantage.

*Broader impact:* When prices are transparent, competition among buyers intensifies (they can no longer collude to suppress prices), and the market becomes more efficient. Farmers may receive 15-30% higher prices simply from having access to price information, based on evidence from similar interventions in India and Sub-Saharan Africa.

**2. Independent Weighing Facilities → Ensuring Fair Measurement:**

*How it creates inclusivity:*
- Independent, publicly maintained weighing facilities with calibrated, certified scales would eliminate the possibility of rigged measurements.
- When weighing is conducted by an independent party (not the buyer), the incentive and ability to underweigh produce is removed.
- Standardized measurement creates **trust** in market transactions — a fundamental requirement for efficient market functioning and inclusive institutions.

*Inclusive institutional principle:* **Impartial enforcement of rules** is essential for inclusive institutions. Just as an independent judiciary enforces laws impartially, independent weighing enforces measurement standards impartially. Both remove the ability of powerful parties to manipulate outcomes.

*Practical implementation:* The local administration could install certified digital scales at the market, operated by government or cooperative employees. Each transaction would be recorded, creating a transparent audit trail that deters fraud.

**3. Farmers' Cooperative → Collective Voice and Bargaining Power:**

*How it creates inclusivity:*
- A cooperative transforms farmers from isolated, powerless individuals into an organized group with collective bargaining power.
- The cooperative can negotiate bulk prices, arrange direct sales to larger buyers (bypassing local traders), invest in collective storage facilities, and provide members with market information and technical assistance.
- It gives farmers a **political voice** — the cooperative can advocate with local government for better infrastructure, fair market regulation, and access to agricultural inputs.

*Inclusive institutional principle:* Inclusive institutions require **broad participation in economic and political processes.** A cooperative creates pluralistic institutions where farmers actively participate in market governance rather than being passive subjects of trader exploitation. This echoes the principle of democratic economic organization.

*Evidence from Bangladesh:* Agricultural cooperatives in other regions of Bangladesh have demonstrated significant impacts. The Bangladesh Rural Advancement Committee (BRAC) has organized farmers into groups that collectively negotiate with traders, access credit, and share technical knowledge. The Grameen Bank's group lending model similarly demonstrated the power of collective organization for the poor.

**Synergistic Effect:**

These three measures are **complementary and mutually reinforcing:**
- Transparent pricing without independent weighing would be partially effective (traders could still cheat on weight even if prices are known)
- Independent weighing without a cooperative would help individual farmers but they would still lack collective bargaining power
- A cooperative without transparent pricing and fair weighing would organize farmers but they would still face information and measurement disadvantages

Together, they create a **comprehensive institutional transformation:**
- Information flows freely (transparent pricing)
- Rules are enforced impartially (independent weighing)
- Participants have voice and agency (cooperative)

These are precisely the characteristics of **inclusive institutions** as defined by Acemoglu and Robinson — they provide broad access to economic opportunities, enforce rules fairly, and allow pluralistic participation in governance.`,
      },
      {
        part: "c",
        marks: 3,
        question: "Identify one obstacle that could prevent these reforms from benefiting small farmers and suggest how it could be addressed.",
        answer: `**Key Obstacle: Political Resistance and Elite Capture by the Existing Trader Group**

The most significant obstacle is that the **influential traders will actively resist and potentially sabotage these reforms** because the reforms directly threaten their source of income and power. This is a classic problem in institutional reform — those who benefit from extractive institutions have strong incentives and the means to prevent change.

**How This Obstacle Would Manifest:**

**1. Political Interference:**
The influential traders likely have strong connections to local political leaders (Union Parishad chairmen, Upazila officials, and even national politicians). They may use these connections to:
- Block or delay the implementation of transparent pricing and independent weighing facilities
- Ensure that the cooperative faces bureaucratic obstacles (registration delays, inspection harassment)
- Influence the appointment of market officials who are sympathetic to their interests
- Use their political allies to cut funding or support for the reform initiatives

In Bangladesh's political economy, local markets are often controlled by supporters of the ruling party, and market trader associations can wield significant political influence. Challenging their power means challenging the local political establishment.

**2. Economic Sabotage:**
Traders might:
- Refuse to buy from cooperative members, effectively boycotting organized farmers
- Offer temporarily higher prices to non-cooperative farmers to break the cooperative's solidarity
- Spread misinformation about the cooperative (claiming it will fail, that members will lose money)
- Use their control of credit (many farmers owe money to traders) to pressure farmers against joining the cooperative

**3. Elite Capture of the Cooperative Itself:**
Even if a cooperative is established, the traders might infiltrate it by:
- Having their relatives or associates elected to cooperative leadership
- Bribing cooperative officials to maintain favorable terms
- Ensuring that cooperative benefits flow to wealthier, more influential farmers rather than the smallest, most vulnerable ones

This "elite capture" phenomenon has been documented extensively in Bangladesh's development programs — local elites often capture the benefits of programs intended for the poor.

**How to Address This Obstacle:**

**A Comprehensive Strategy Combining Multiple Approaches:**

**1. External Institutional Support and Oversight:**
- Partner with established, credible NGOs (such as BRAC, ASA, or Oxfam Bangladesh) to provide organizational support, training, and external monitoring that the traders cannot easily influence
- Seek support from the Department of Cooperatives and the Department of Agricultural Marketing at the national level, bypassing potentially compromised local officials
- Engage local media and civil society organizations to publicize the reforms and create public pressure for accountability

**2. Legal and Regulatory Framework:**
- Ensure the cooperative is registered under the Cooperative Societies Act, giving it legal standing and protection
- Establish formal market regulations (Weights and Measures Act enforcement) that make unfair weighing practices a punishable offense
- Create a transparent grievance mechanism where farmers can report intimidation or unfair practices, with cases handled by officials above the local level

**3. Economic Independence for Farmers:**
- The cooperative should develop alternative market channels (direct linkages with urban retailers, food processing companies, or government procurement programs) so that farmers are not dependent on local traders
- Establish cooperative-owned storage facilities (even basic warehouse structures) to break the traders' storage monopoly
- Provide cooperative members with access to credit through microfinance institutions, reducing their dependence on trader credit

**4. Capacity Building and Democratic Governance:**
- Train cooperative members in governance, financial management, and their legal rights
- Establish transparent, democratic election procedures for cooperative leadership with term limits
- Implement financial transparency requirements (public audits, regular member meetings with financial reports)
- Reserve leadership positions for the smallest and most vulnerable farmers (women, landless, ethnic minorities) to prevent elite capture

**5. Gradual, Strategic Implementation:**
- Rather than confronting the traders directly, initially position the cooperative as complementary (offering additional services rather than replacing the existing market)
- Build the cooperative's strength gradually — start with collective input purchasing and information sharing before moving to collective marketing
- Demonstrate concrete benefits to members (higher prices, fair weighing) that make membership attractive despite trader opposition

**Conclusion:** The political resistance of entrenched economic elites is the most formidable obstacle to institutional reform in rural Bangladesh. Overcoming it requires a multi-pronged strategy combining external institutional support, legal protection, economic alternatives, capacity building, and strategic implementation. The goal is not to eliminate the traders but to transform the market institutions from extractive to inclusive — creating a fair, competitive market where farmers receive equitable prices and have genuine choices. This is the essence of institutional development: changing the "rules of the game" so that economic opportunities are broadly shared rather than concentrated in the hands of a privileged few.`,
      },
    ],
  },

  // Additional questions for remaining chapters (3,4,5) - key exam-pattern questions

  // CHAPTER 3
  {
    id: "ch3-e1",
    chapterId: 3,
    totalMarks: 3,
    difficulty: "easy",
    question: "State the Harrod-Domar growth equation. If a country saves 24% of its GDP and the capital-output ratio is 4, calculate the growth rate. What savings rate would be needed for 8% growth?",
    answer: `**The Harrod-Domar Growth Equation:**

**g = s / k**

Where:
- **g** = rate of growth of GDP (growth rate)
- **s** = savings rate (proportion of national income that is saved and invested)
- **k** = capital-output ratio (also called ICOR — Incremental Capital-Output Ratio; the amount of capital needed to produce one additional unit of output)

**This equation tells us that economic growth is directly proportional to the savings rate and inversely proportional to the capital-output ratio.** A country that saves more (higher s) or uses capital more efficiently (lower k) will grow faster.

**Calculation 1: Growth Rate**

Given: s = 24% = 0.24, k = 4

g = s / k = 0.24 / 4 = **0.06 = 6%**

**Interpretation:** With a savings rate of 24% and a capital-output ratio of 4, the economy will grow at **6% per year**. This means the country needs to invest Tk 4 of capital for every Tk 1 of additional output. Since it saves and invests 24% of its GDP, it generates 6% growth.

**Calculation 2: Required Savings Rate for 8% Growth**

Given: desired g = 8% = 0.08, k = 4

s = g × k = 0.08 × 4 = **0.32 = 32%**

**Interpretation:** To achieve 8% growth with the same capital-output ratio of 4, the country would need to save and invest **32% of GDP**. This is a very high savings rate — comparable to East Asian economies at the peak of their growth (China has maintained savings rates above 40%).

**The Financing Gap:** If the country currently saves only 24% but needs 32%, there is a **financing gap of 8 percentage points of GDP**. This gap can be filled through:
- **Foreign aid** — grants or concessional loans from donors
- **Foreign Direct Investment (FDI)** — external private investment
- **External borrowing** — commercial loans or bonds
- **Domestic policy reforms** — tax incentives for savings, pension systems, reducing consumption subsidies

This "financing gap" logic was the intellectual foundation for massive foreign aid programs in the 1950s-70s — if developing countries couldn't save enough for their desired growth rate, international transfers could fill the gap.

**Bangladesh Application:** Bangladesh's gross savings rate is approximately 25-30% of GDP, and its growth rate has been 6-7%. Using Harrod-Domar: if s ≈ 0.28 and g ≈ 0.07, then implied k = s/g = 0.28/0.07 = 4. This suggests a capital-output ratio of 4, which is typical for developing countries.

**Critical Caveat:** While the Harrod-Domar model is useful for quick calculations, it has serious limitations: it ignores technological progress, human capital, institutions, and diminishing returns to capital. High savings alone do not guarantee growth — the USSR had very high savings but ultimately stagnated due to inefficient allocation. The quality and efficiency of investment matter as much as the quantity.`,
  },
  {
    id: "ch3-m1",
    chapterId: 3,
    totalMarks: 5,
    difficulty: "medium",
    question: "Compare and contrast the Balanced Growth and Unbalanced Growth strategies. Which is more appropriate for a resource-constrained country like Bangladesh?",
    answer: `**Balanced Growth** and **Unbalanced Growth** are two contrasting strategies for how developing countries should allocate their limited investment resources. Understanding both is essential for designing effective industrialization and development policy.

**Balanced Growth Theory (Nurkse, Rosenstein-Rodan):**

**Core Argument:** Investment should be spread simultaneously across many sectors to create mutual demand and break the vicious circle of poverty.

**The Vicious Circle of Poverty (Nurkse):**
- **Supply side:** Low income → Low savings → Low investment → Low productivity → Low income
- **Demand side:** Low income → Low purchasing power → Low incentive to invest → Low production → Low income

**The Big Push (Rosenstein-Rodan, 1943):** A massive, coordinated investment across multiple sectors simultaneously is needed because:

1. **Complementarity of demand:** If only a shoe factory is built, there may not be enough demand for its output (workers in one factory alone cannot buy all the shoes). But if shoe, textile, food processing, and construction factories are all built simultaneously, the workers in each industry become consumers for the others, creating mutual markets.

2. **Indivisibilities in production:** Modern industries require minimum efficient scales — you cannot build half a steel mill. This means individual investments require large capital outlays.

3. **External economies:** Infrastructure investments (roads, power) benefit all industries; education benefits all sectors. These external economies justify large-scale, coordinated investment.

**Key features:**
- Investment spread across many sectors simultaneously
- Requires massive resources and central coordination
- State planning plays a dominant role
- Aims to overcome the low-level equilibrium trap

**Unbalanced Growth Theory (Hirschman, 1958):**

**Core Argument:** Investment should be concentrated in strategic sectors that create forward and backward linkages, stimulating investment in related sectors through market forces.

**Linkages:**
- **Backward linkages:** Investment in a sector stimulates demand for its inputs. Example: An automobile industry creates demand for steel, rubber, glass, electronics, and textiles.
- **Forward linkages:** Output of a sector becomes an input for another. Example: Steel production enables machinery manufacturing, construction, and shipbuilding.

**Social Overhead Capital (SOC) vs. Directly Productive Activities (DPA):**
- SOC (infrastructure: roads, power, ports) enables production but doesn't directly produce goods
- DPA (manufacturing, agriculture) directly produces goods but requires infrastructure
- Hirschman argued for strategic imbalance between SOC and DPA to create "pressure points" that stimulate further investment

**Key features:**
- Investment concentrated in sectors with strongest linkages
- Relies on market forces and entrepreneurial response to transmit growth
- Requires less state coordination than balanced growth
- More realistic for resource-scarce countries

**Detailed Comparison:**

| Dimension | Balanced Growth | Unbalanced Growth |
|-----------|----------------|-------------------|
| Investment allocation | Spread across all sectors | Concentrated in strategic sectors |
| Resource requirement | Massive (big push) | Moderate (strategic) |
| Role of state | Central planning essential | Strategic guidance; market forces play larger role |
| Market role | Markets created by coordinated investment | Market disequilibria drive further investment |
| Feasibility | Difficult — requires enormous resources | More realistic for resource-poor countries |
| Risk | Resources spread too thin; quality suffers | Selected sectors may fail; neglected sectors suffer |
| Historical examples | Soviet-style planned economies | East Asian industrial policy (Korea, Japan) |
| Theoretical basis | Market failure, coordination failure | Linkage effects, induced investment |
| Criticism | Where does the "big push" come from? | How to identify the "right" sectors? |

**Which is More Appropriate for Bangladesh?**

**Unbalanced Growth is more appropriate for Bangladesh** for several compelling reasons:

**1. Resource Constraints:**
Bangladesh has limited public resources — government revenue is approximately 9% of GDP (one of the lowest in the world). A "Big Push" requiring simultaneous investment across all sectors is simply not financially feasible. The country cannot afford to invest in steel, automobiles, chemicals, pharmaceuticals, electronics, and infrastructure all at once.

**2. Proven Success of Strategic Sectoral Focus:**
Bangladesh's development history validates the unbalanced growth approach:
- The **RMG sector** received focused attention (bonded warehouse facilities, back-to-back LCs, EPZs) and became a $42+ billion export industry. This single sector's success generated enormous backward linkages (textile mills, accessories, packaging) and forward linkages (logistics, banking, insurance).
- **Microfinance** concentrated resources on financial inclusion for the poor and generated massive social and economic multiplier effects.
- **Agriculture** received focused investment (Green Revolution technologies, irrigation) and achieved near self-sufficiency in rice.

**3. Linkage Potential:**
Bangladesh should identify sectors with strong linkages and focus investment there:
- **Pharmaceuticals** (strong backward linkages to chemicals, forward linkages to healthcare)
- **IT/software** (requires human capital investment but has enormous export potential)
- **Agro-processing** (backward linkages to agriculture, forward linkages to retail and export)
- **Light engineering** (serves growing domestic demand and regional markets)

**4. Institutional Capacity:**
The balanced growth approach requires sophisticated central planning capabilities that Bangladesh's public administration lacks. The unbalanced approach, which relies more on market signals and entrepreneurial response, is better suited to Bangladesh's institutional context.

**5. However, Strategic Elements of Balanced Growth Are Needed:**

Pure unbalanced growth has risks — neglecting infrastructure, education, and health creates bottlenecks that eventually constrain growth in leading sectors. Bangladesh must invest in:
- **Infrastructure** (power, ports, roads) — without which no sector can grow efficiently
- **Education** — the foundation for all economic activity
- **Healthcare** — a healthy workforce is a productive workforce

The optimal strategy is a **hybrid approach**: concentrate investment in strategic sectors with strong linkages (unbalanced growth) while ensuring adequate investment in infrastructure, education, and health (elements of balanced growth). This is essentially what successful developing countries (South Korea, China, Vietnam) have done — strategic industrial policy complemented by broad-based human capital investment.

**Conclusion:**
For resource-constrained Bangladesh, unbalanced growth — focusing on strategic sectors with strong linkages — is more appropriate than attempting a simultaneous big push across all sectors. However, this should be complemented by sustained investment in infrastructure and human capital to avoid bottlenecks that limit the growth potential of leading sectors.`,
  },

  // CHAPTER 4
  {
    id: "ch4-e1",
    chapterId: 4,
    totalMarks: 3,
    difficulty: "easy",
    question: "What are the three dimensions and indicators of the Human Development Index? Explain why GNI per capita is used with a logarithmic transformation.",
    answer: `**The Three Dimensions and Indicators of HDI:**

The Human Development Index (HDI), created by **Mahbub ul Haq** with **Amartya Sen's** intellectual contribution, measures human development across three equally weighted dimensions:

**1. Health Dimension — A Long and Healthy Life**
- **Indicator:** Life expectancy at birth
- **Minimum value:** 20 years
- **Maximum value:** 85 years
- **Rationale:** Life expectancy is a comprehensive indicator that reflects nutrition, healthcare access, sanitation, environmental quality, and overall living conditions. A society where people live longer is generally one that provides better conditions for human flourishing.

**2. Education Dimension — Knowledge**
- **Indicator 1:** Mean years of schooling (for adults aged 25 and above) — reflects the educational stock of the adult population
- **Indicator 2:** Expected years of schooling (for children of school-entering age) — reflects the educational opportunity available to the current generation
- The Education Index is the **arithmetic mean** of the normalized values of these two indicators
- **Minimum:** 0 years for both
- **Maximum:** 15 years for mean years, 18 years for expected years
- **Rationale:** Using both actual (mean) and potential (expected) years captures both past achievement and future opportunity in education.

**3. Standard of Living Dimension — A Decent Standard of Living**
- **Indicator:** Gross National Income (GNI) per capita in Purchasing Power Parity (PPP) dollars
- **Minimum value:** $100
- **Maximum value:** $75,000
- **Key feature: Logarithmic transformation is applied**

**Why the Logarithmic Transformation of GNI per Capita:**

The HDI uses **ln(GNI per capita)** instead of raw GNI per capita. This mathematical transformation reflects the fundamental economic principle of **diminishing marginal utility of income** — each additional dollar of income contributes less to human well-being than the previous one.

**Intuitive Explanation:**
- For a poor family earning $500/year, an extra $500 (doubling their income) would be transformative — it could mean the difference between hunger and adequate nutrition, between no healthcare and basic medical care.
- For a wealthy family earning $50,000/year, an extra $500 (a 1% increase) would barely be noticed — perhaps an extra restaurant meal or a slightly better vacation.

**Mathematical Illustration:**

| GNI per capita ($) | ln(GNI) | Increase in ln(GNI) for doubling |
|---|---|---|
| 500 | 6.21 | — |
| 1,000 | 6.91 | +0.69 |
| 2,000 | 7.60 | +0.69 |
| 10,000 | 9.21 | — |
| 20,000 | 9.90 | +0.69 |
| 50,000 | 10.82 | — |
| 100,000 | 11.51 | +0.69 |

The logarithm has the property that **every doubling of income adds the same amount (0.69)** to the log value, regardless of the starting level. This means moving from $500 to $1,000 has the same impact on the HDI's income dimension as moving from $50,000 to $100,000 — both are doublings.

Without the log transformation, the income dimension would be dominated by rich countries, and differences among poor countries would be compressed to near-zero. A country with $50,000 GNI per capita would score 100 times higher than one with $500. With the log transformation, the gap is much more reasonable (10.82 vs. 6.21), reflecting the reality that while the rich country is undoubtedly better off, the difference in **well-being** is far less than the 100:1 income ratio suggests.

**Policy Implication:** The log transformation sends an important message — beyond a certain income level, additional income contributes relatively little to human well-being. Countries should focus on non-income dimensions (health, education) rather than pursuing ever-higher GDP per capita. This is why countries like **Cuba** and **Costa Rica** achieve high HDI scores despite modest incomes — they invest heavily in health and education, which the HDI values alongside income.`,
  },

  // CHAPTER 5
  {
    id: "ch5-e1",
    chapterId: 5,
    totalMarks: 3,
    difficulty: "easy",
    question: "Differentiate between Import-Substitution Industrialization (ISI) and Export Promotion Industrialization (EPI). Which strategy did Bangladesh adopt for its garment sector?",
    answer: `**Import-Substitution Industrialization (ISI)** and **Export Promotion Industrialization (EPI)** are two fundamentally different strategies that developing countries use to industrialize. They differ in their orientation, policy tools, and outcomes.

**Import-Substitution Industrialization (ISI):**
ISI aims to replace imported manufactured goods with domestically produced alternatives. It is an **inward-looking** strategy that focuses on producing for the domestic market.

**Key Policy Tools:**
- High tariffs and import quotas on manufactured goods to protect domestic producers from foreign competition
- Overvalued exchange rates (making imports of capital goods cheaper while protecting domestic consumer goods)
- Government subsidies, cheap credit, and tax breaks for domestic industries
- State-owned enterprises in "strategic" sectors (steel, chemicals, heavy machinery)
- Infant industry protection — temporary protection until domestic industries become competitive

**Historical Examples:**
- India (1950s-1991): "License Raj" — heavy regulation, high tariffs, state-led industrialization
- Brazil, Argentina, Mexico (1950s-1970s): Latin American ISI promoted by ECLAC economists (Raúl Prebisch)
- Many African countries post-independence (1960s-1970s)

**Export Promotion Industrialization (EPI):**
EPI focuses on producing manufactured goods for export to international markets. It is an **outward-looking** strategy that leverages a country's comparative advantage (typically cheap labor) to compete globally.

**Key Policy Tools:**
- Competitive (often undervalued) exchange rates to make exports cheaper
- Low trade barriers to enable access to imported inputs at world prices
- Export Processing Zones (EPZs) with special tax incentives and streamlined regulations
- Export credit and insurance
- Investment in education and skills for export-oriented industries
- Attracting Foreign Direct Investment (FDI) for technology and market access

**Historical Examples:**
- East Asian Tigers (South Korea, Taiwan, Hong Kong, Singapore) — 1960s-1990s
- China — since 1978 economic reforms
- Vietnam — since Doi Moi reforms (1986)
- Bangladesh — garment sector since 1980s

**Key Comparison:**

| Feature | ISI | EPI |
|---------|-----|-----|
| Market orientation | Domestic (inward) | International (outward) |
| Trade policy | Protectionist (high tariffs) | Open (low barriers for exporters) |
| Competition | Limited (protected) | Intense (global) |
| Efficiency | Often low (no competitive pressure) | Higher (must compete globally) |
| Scale | Limited by domestic market size | Access to global market |
| Employment | Often capital-intensive | Can be labor-intensive |
| Foreign exchange | Saves (in theory, often fails) | Earns |
| Innovation | Weak incentive | Competitive pressure drives it |
| Risk | Rent-seeking, inefficiency | Vulnerability to global demand shocks |

**Bangladesh's Garment Sector: An EPI Success Story**

Bangladesh adopted **Export Promotion Industrialization** for its Ready-Made Garment (RMG) sector, which has become the most successful example of EPI in South Asian history:

**How EPI was implemented:**
1. **Bonded warehouse facilities** allowed garment factories to import raw materials (fabrics, accessories) duty-free, provided the finished products were exported — eliminating the ISI-style tariff burden on inputs
2. **Back-to-back Letter of Credit (LC)** system enabled factories without significant capital to import materials on the strength of confirmed export orders from foreign buyers
3. **Export Processing Zones (EPZs)** in Dhaka and Chittagong offered tax holidays, streamlined customs, and reduced bureaucratic interference for export-oriented firms
4. **Competitive exchange rate** made Bangladeshi garments price-competitive globally
5. **Multi-Fibre Arrangement (MFA)** quota access provided guaranteed market access in developed countries

**Results:**
- From virtually zero in 1980 to $42+ billion in exports (2023)
- Second largest garment exporter globally (after China)
- 4+ million jobs created (60% women)
- 84% of total export earnings
- Triggered urbanization, women's empowerment, and economic transformation

**However, elements of ISI also exist in Bangladesh:**
- The **pharmaceutical sector** benefited from ISI-type policies — WTO TRIPS waiver allowed Bangladeshi companies to produce generic medicines without paying patent royalties, building a strong domestic industry
- **Agriculture** is protected through subsidies and import restrictions on rice to ensure food security

**Conclusion:** Bangladesh's garment sector is a textbook case of successful EPI, demonstrating that a least-developed country can leverage its comparative advantage (abundant, low-cost labor) to compete in global markets and generate employment, foreign exchange, and economic transformation.`,
  },
];
