export interface Topic {
  title: string;
  content: string;
}

export interface Question {
  marks: number;
  question: string;
  answer: string;
}

export interface Video {
  title: string;
  youtubeId: string;
  description: string;
}

export interface Material {
  title: string;
  type: "pdf" | "article" | "notes" | "book" | "slides";
  url: string;
  description: string;
}

export interface Chapter {
  id: number;
  section: "A" | "B";
  title: string;
  clos: string;
  topics: Topic[];
  videos: Video[];
  materials: Material[];
  questions: Question[];
}

export const courseInfo = {
  code: "0388 21 DS 2201",
  title: "Development Economics",
  year: "Second",
  term: "Second",
  status: "Core",
  credit: "3.0",
  prerequisite: "None",
  rationale:
    "The course intends to provide the students with the understanding of the concept of economic development, its measurement and a wide array of explanations and mechanisms and factors that condition the development of a country. The course also includes essentials on poverty and inequality. It is expected that with these understanding students will be able to apply the knowledge in designing appropriate intervention strategies while working with the communities and societies.",
};

export const chapters: Chapter[] = [
  {
    id: 1,
    section: "A",
    title: "Introducing Development Economics",
    clos: "1",
    topics: [
      {
        title: "Meaning of Development and Economic Development",
        content: `**Development** is a multidimensional process involving the reorganization and reorientation of entire economic and social systems. It involves radical changes in institutional, social, and administrative structures as well as in popular attitudes and customs.

**Economic Development** refers to the sustained improvement in material well-being of a society. It is measured not merely by an increase in output (GDP) but by the structural transformation of the economy, improvement in living standards, reduction in poverty and inequality, and expansion of economic opportunities for all citizens.

According to **Amartya Sen**, economic development is fundamentally about expanding the real freedoms that people enjoy. This "capabilities approach" goes far beyond income per capita to include health, education, political liberties, and social participation.

**Michael Todaro** defines economic development as an increase in living standards, improvement in self-esteem needs, and freedom from oppression as well as a greater choice. The three core values of development are:

1. **Sustenance** — the ability to meet basic needs (food, shelter, health, protection)
2. **Self-Esteem** — a sense of worth and self-respect
3. **Freedom from Servitude** — the ability to choose, to be emancipated from material conditions of life and from social servitude

Development is therefore not merely an economic phenomenon but a multi-faceted process requiring the reorganization of entire economic, social, and institutional systems.`,
      },
      {
        title: "Historical Background of Development Economics",
        content: `Development economics emerged as a distinct field of study in the aftermath of **World War II** (1940s–1950s), driven by the need to understand and address the economic challenges facing the newly independent nations of Asia, Africa, and Latin America.

### Pre-Classical Period
Early thinkers like **mercantilists** (16th–18th century) focused on accumulation of national wealth through trade surpluses and gold reserves.

### Classical Period (1776–1870)
**Adam Smith's** "The Wealth of Nations" (1776) laid the groundwork for understanding economic growth through division of labor, capital accumulation, and free markets. **David Ricardo** contributed the theory of comparative advantage, while **Thomas Malthus** warned about population growth outstripping food supply.

### Post-War Development Economics (1940s–1960s)
The field truly emerged with pioneers like:
- **Paul Rosenstein-Rodan** — Big Push Theory (1943)
- **Ragnar Nurkse** — Vicious Circle of Poverty (1953)
- **W. Arthur Lewis** — Dual Economy Model (1954)
- **Walt Rostow** — Stages of Growth (1960)
- **Albert Hirschman** — Unbalanced Growth (1958)

### Neoclassical Counter-Revolution (1970s–1980s)
This period saw a shift toward free-market oriented approaches, structural adjustment programs, and the Washington Consensus emphasizing liberalization, privatization, and fiscal discipline.

### Modern Development Economics (1990s–Present)
The field now incorporates institutional economics, behavioral economics, randomized controlled trials (RCTs), and focuses on multidimensional poverty, sustainable development goals (SDGs), and inclusive growth.`,
      },
      {
        title: "Components of Economic Growth",
        content: `Economic growth refers to the increase in the output of goods and services produced by an economy over time. The key components include:

### 1. Capital Accumulation
Investment in physical capital (machinery, infrastructure, factories) and human capital (education, health, skills). Capital accumulation increases the productive capacity of the economy.

### 2. Population and Labor Force Growth
Growth in the labor force can contribute to economic growth if workers are productively employed. However, if population growth outpaces economic growth, it can lead to declining per capita income.

### 3. Technological Progress
Innovation and the adoption of new technologies increase productivity — allowing more output from the same inputs. This is often considered the most important driver of long-run economic growth.

### 4. Natural Resources
The availability of natural resources (land, minerals, energy) provides a base for economic production. However, resource abundance alone does not guarantee development (the "resource curse").

### 5. Institutional Framework
Effective governance, rule of law, property rights, and stable political systems create an environment conducive to investment and growth.

### 6. Human Capital
Education, health, and skills of the workforce determine the productivity of labor. Investment in human capital is crucial for sustained economic growth.

### 7. Structural Transformation
The shift from agriculture-based economies to manufacturing and services typically accompanies economic growth, leading to higher productivity and incomes.`,
      },
      {
        title: "Economic Growth vs Development",
        content: `While often used interchangeably, **economic growth** and **economic development** are distinct concepts:

| Aspect | Economic Growth | Economic Development |
|--------|----------------|---------------------|
| **Definition** | Increase in real GDP or output | Improvement in quality of life and structural change |
| **Measurement** | GDP, GNP growth rates | HDI, poverty rates, inequality measures |
| **Scope** | Quantitative — more output | Qualitative — better life |
| **Focus** | Increase in production | Reduction in poverty, inequality, unemployment |
| **Nature** | Uni-dimensional | Multi-dimensional |
| **Time Frame** | Can be short-term | Long-term process |
| **Applicability** | Relevant for all economies | Particularly relevant for developing countries |

### Key Differences Elaborated

**Economic Growth** is a necessary but not sufficient condition for development. A country may experience high GDP growth while the majority of its population remains in poverty (e.g., Nigeria with oil wealth but widespread poverty).

**Economic Development** encompasses:
- Structural changes in the economy
- Improvement in human well-being
- Reduction in inequality
- Institutional and technological changes
- Environmental sustainability

**Amartya Sen** argued that development should be seen as a process of expanding the substantive freedoms that people enjoy. GDP growth is merely a means to expanding freedoms, not an end in itself.

**Example**: China has experienced remarkable economic growth, but development challenges remain in terms of environmental degradation, income inequality, and political freedoms.`,
      },
    ],
    videos: [
      {
        title: "Introduction to Development Economics",
        youtubeId: "TLqBx_2JwbE",
        description: "A comprehensive introduction to the field of development economics and its core concepts.",
      },
      {
        title: "Economic Growth vs Economic Development",
        youtubeId: "9MgJEEspmKQ",
        description: "Understanding the key differences between economic growth and economic development.",
      },
      {
        title: "What is Development Economics?",
        youtubeId: "PeGE4qmLxZw",
        description: "An overview lecture on the meaning and scope of development economics.",
      },
    ],
    materials: [
      {
        title: "Todaro & Smith - Economic Development (Chapter 1)",
        type: "book",
        url: "https://www.google.com/search?q=Todaro+Smith+Economic+Development+Chapter+1+PDF",
        description: "The foundational textbook chapter introducing development economics concepts.",
      },
      {
        title: "World Bank Development Report",
        type: "article",
        url: "https://www.worldbank.org/en/publication/wdr/wdr-archive",
        description: "Annual reports on various development topics with data and analysis.",
      },
      {
        title: "Introduction to Development Economics - Lecture Notes",
        type: "notes",
        url: "https://www.google.com/search?q=development+economics+introduction+lecture+notes+PDF",
        description: "Comprehensive lecture notes covering the basics of development economics.",
      },
      {
        title: "UNDP Human Development Reports",
        type: "article",
        url: "https://hdr.undp.org/",
        description: "Annual human development reports with global data and analysis.",
      },
    ],
    questions: [
      {
        marks: 2,
        question: "Define economic development. How does it differ from economic growth?",
        answer: "Economic development is a multidimensional process involving sustained improvement in material well-being, structural transformation of the economy, reduction in poverty and inequality, and expansion of economic opportunities. Unlike economic growth (which is merely quantitative increase in GDP/output), development encompasses qualitative improvements including better health, education, and social inclusion. Growth is a necessary but insufficient condition for development.",
      },
      {
        marks: 2,
        question: "What are the three core values of development according to Todaro?",
        answer: "According to Michael Todaro, the three core values of development are: (1) **Sustenance** — the ability to meet basic needs such as food, shelter, health, and protection; (2) **Self-Esteem** — a sense of worth, self-respect, and dignity that societies seek; (3) **Freedom from Servitude** — the ability to choose freely, to be emancipated from material conditions of life and from social servitude to nature, ignorance, and other people.",
      },
      {
        marks: 5,
        question: "Trace the historical evolution of development economics as a field of study. What were the major paradigm shifts?",
        answer: "Development economics evolved through several distinct phases:\n\n**1. Post-War Emergence (1940s-1960s):** The field emerged after WWII with structuralist economists like Rosenstein-Rodan (Big Push), Lewis (Dual Economy), Rostow (Stages of Growth), and Nurkse (Vicious Circle of Poverty). These thinkers emphasized state-led industrialization and capital accumulation.\n\n**2. Neoclassical Counter-Revolution (1970s-1980s):** Dissatisfied with state-led approaches, economists advocated free markets, privatization, and structural adjustment (Washington Consensus). Key figures included Bauer, Lal, and Balassa who argued government intervention caused inefficiency.\n\n**3. New Institutional Economics (1990s):** Recognition that institutions (property rights, governance, rule of law) are fundamental to development. North, Acemoglu, and others showed how institutional quality determines economic outcomes.\n\n**4. Modern Phase (2000s-Present):** Focus on evidence-based policy through RCTs (Banerjee, Duflo), multidimensional poverty measurement, sustainable development goals (SDGs), and the capabilities approach (Sen). The field now integrates behavioral economics, environmental sustainability, and inclusive growth.",
      },
      {
        marks: 5,
        question: "Critically analyze Amartya Sen's capabilities approach to development. How does it differ from traditional income-based approaches?",
        answer: "**Amartya Sen's Capabilities Approach** redefines development as the expansion of substantive freedoms (capabilities) that people enjoy, rather than merely increasing income or GDP.\n\n**Core Arguments:**\n- Development should focus on what people can 'do' and 'be' (functionings) rather than what they 'have'\n- Five instrumental freedoms: political freedoms, economic facilities, social opportunities, transparency guarantees, and protective security\n- Income is merely a means to expanding capabilities, not an end in itself\n\n**Differences from Traditional Approaches:**\n- **Income approach** measures well-being by monetary income; Sen argues this ignores how income converts to well-being (varies by age, health, social context)\n- **Utilitarian approach** focuses on happiness/satisfaction; Sen argues this is subjective and can reflect adaptive preferences of the poor\n- **Basic needs approach** provides a list of necessities; Sen's approach is more flexible and respects individual agency\n\n**Critical Evaluation:**\n- **Strengths:** More comprehensive, captures multidimensional deprivation, has influenced HDI and SDGs\n- **Limitations:** Difficult to operationalize and measure, identifying relevant capabilities is subjective, implementation challenges in policy",
      },
      {
        marks: 10,
        question: "Discuss the meaning, scope, and significance of development economics. How has the understanding of 'development' changed over time? Illustrate with examples from developing countries.",
        answer: "**Introduction:**\nDevelopment economics is the branch of economics that studies the economic transformation of developing countries. It analyzes how countries transition from low-income, agrarian economies to high-income, industrialized ones.\n\n**Meaning and Scope:**\nDevelopment economics encompasses the study of: (a) economic growth and structural transformation, (b) poverty reduction and inequality, (c) human capital development, (d) institutional change, (e) trade and industrialization strategies, (f) environmental sustainability. Its scope extends beyond pure economics to include political, social, and institutional dimensions.\n\n**Evolution of the Concept of Development:**\n\n**1. Growth-Centered View (1950s-1960s):** Development was equated with GDP growth. The Harrod-Domar model and Rostow's stages suggested that sufficient capital accumulation would trigger self-sustaining growth. *Example:* India's Five-Year Plans focused on heavy industrialization and capital accumulation.\n\n**2. Employment and Redistribution (1970s):** The realization that growth alone didn't reduce poverty led to the 'redistribution with growth' approach. The ILO's basic needs strategy emerged. *Example:* Brazil experienced high growth in the 1960s-70s ('Brazilian Miracle') but inequality worsened significantly.\n\n**3. Structural Adjustment Era (1980s):** The debt crisis led to Washington Consensus policies emphasizing liberalization, privatization, and fiscal austerity. *Example:* Many African countries underwent structural adjustment programs with mixed results—some achieving macroeconomic stability but at the cost of social services.\n\n**4. Human Development Paradigm (1990s):** Amartya Sen's capabilities approach shifted focus to education, health, and freedoms. The HDI was introduced in 1990. *Example:* Kerala, India, achieved high human development indicators despite modest income levels, demonstrating that development transcends income.\n\n**5. Institutional and Sustainable Development (2000s-Present):** Recognition that institutions, governance, and environmental sustainability are central. The MDGs (2000) and SDGs (2015) provided comprehensive development frameworks. *Example:* Bangladesh's remarkable progress in garment exports, microfinance (Grameen Bank), and social indicators despite institutional challenges.\n\n**Significance:**\n- Provides theoretical frameworks for policy design in developing countries\n- Helps understand the root causes of underdevelopment\n- Guides international development cooperation and aid effectiveness\n- Addresses contemporary challenges: climate change, globalization, digital divide\n\n**Conclusion:**\nDevelopment economics has evolved from a narrow focus on GDP growth to a comprehensive understanding encompassing human well-being, institutional quality, environmental sustainability, and inclusive participation. The field remains critically important as billions of people still live in poverty and face developmental challenges.",
      },
      {
        marks: 10,
        question: "What are the components of economic growth? Explain each component with examples and discuss why economic growth alone is insufficient for development.",
        answer: "**Introduction:**\nEconomic growth, defined as the sustained increase in real GDP over time, depends on several interconnected components. While growth is essential, it is insufficient for comprehensive development.\n\n**Components of Economic Growth:**\n\n**1. Capital Accumulation:**\nInvestment in physical capital (infrastructure, machinery, factories) increases productive capacity. *Example:* China's massive infrastructure investment (highways, railways, ports) contributed to sustained 10%+ annual growth for decades. However, capital accumulation alone faces diminishing returns (as predicted by the Solow model).\n\n**2. Population and Labor Force Growth:**\nA growing, productively employed labor force contributes to growth. The 'demographic dividend' occurs when the working-age population exceeds dependents. *Example:* East Asian Tigers (South Korea, Taiwan) benefited from demographic transitions in the 1960s-80s. Conversely, rapid population growth in Sub-Saharan Africa has diluted per capita income gains.\n\n**3. Technological Progress:**\nThe most important long-term driver of growth. Innovation increases total factor productivity (TFP). *Example:* The Green Revolution in India (1960s-70s) dramatically increased agricultural output through new seed varieties, irrigation, and fertilizers. More recently, mobile banking (M-Pesa in Kenya) has transformed financial inclusion.\n\n**4. Human Capital:**\nEducation, health, and skills improve labor productivity. *Example:* South Korea invested heavily in education from the 1960s, transforming from an agrarian economy to a knowledge-based one. Countries with high human capital consistently outperform those relying on natural resources alone.\n\n**5. Natural Resources:**\nLand, minerals, and energy provide productive inputs. However, the 'resource curse' shows that abundance can hinder development through Dutch Disease, corruption, and conflict. *Example:* Norway managed its oil wealth effectively through sovereign wealth funds, while Nigeria experienced corruption and underdevelopment despite vast oil reserves.\n\n**6. Institutional Framework:**\nProperty rights, rule of law, regulatory quality, and governance determine the efficiency of resource allocation. *Example:* Botswana's strong institutions helped it use diamond wealth for development, unlike many other resource-rich African nations.\n\n**7. Structural Transformation:**\nThe shift from agriculture to manufacturing and services increases overall productivity. *Example:* Vietnam's transition from agriculture to manufacturing (textiles, electronics) has driven rapid growth since the Doi Moi reforms.\n\n**Why Growth Alone Is Insufficient:**\n\n**a) Distribution Matters:** Growth may benefit only elites. Nigeria's oil-driven growth coexists with 40%+ poverty. The Kuznets hypothesis suggests inequality may first increase with growth.\n\n**b) Quality of Life:** Growth doesn't automatically improve health, education, or environmental quality. China's growth came with severe environmental degradation.\n\n**c) Sustainability:** Resource-depleting or environmentally destructive growth is not sustainable. Climate change threatens to reverse development gains.\n\n**d) Social Dimensions:** Growth ignores gender equality, political freedoms, cultural values, and social cohesion.\n\n**e) Employment:** 'Jobless growth' (growth without employment creation) fails to reduce poverty. India's service-sector-led growth created fewer jobs than manufacturing-led growth in East Asia.\n\n**Conclusion:**\nWhile all components of growth are necessary, development requires that growth be inclusive, sustainable, and accompanied by institutional development, human capital investment, and structural transformation. The goal should be 'development' in its fullest sense — expanding human capabilities and freedoms.",
      },
    ],
  },
  {
    id: 2,
    section: "A",
    title: "Measuring Development",
    clos: "1",
    topics: [
      {
        title: "GDP (Gross Domestic Product)",
        content: `**Gross Domestic Product (GDP)** is the total monetary value of all final goods and services produced within a country's borders during a specific period (usually one year).

### Approaches to Measuring GDP

**1. Production (Output) Approach:**
GDP = Sum of value added at each stage of production
- Avoids double counting by measuring only the value added at each production stage

**2. Income Approach:**
GDP = Wages + Rents + Interest + Profits + Statistical adjustments
- Measures the total income earned by all factors of production

**3. Expenditure Approach:**
GDP = C + I + G + (X - M)
Where:
- C = Consumer spending
- I = Investment spending
- G = Government spending
- X = Exports
- M = Imports

### Types of GDP
- **Nominal GDP**: Measured at current market prices (includes inflation effects)
- **Real GDP**: Adjusted for inflation using a base year's prices (more accurate for comparing across years)
- **GDP at Factor Cost**: GDP minus indirect taxes plus subsidies
- **GDP at Market Price**: GDP including indirect taxes and excluding subsidies

### Limitations of GDP
1. Does not measure income distribution (inequality)
2. Ignores non-market activities (household work, subsistence farming)
3. Does not account for environmental degradation
4. Excludes informal/underground economy
5. Does not capture quality of life, health, or education
6. Ignores leisure time and work-life balance`,
      },
      {
        title: "GNP (Gross National Product)",
        content: `**Gross National Product (GNP)** measures the total value of all final goods and services produced by a country's residents (nationals), regardless of where they are located, during a specific period.

### Formula
**GNP = GDP + Net Factor Income from Abroad (NFIA)**
Where NFIA = Factor income earned by nationals abroad – Factor income earned by foreigners domestically

### Key Differences: GDP vs GNP

| Feature | GDP | GNP |
|---------|-----|-----|
| **Basis** | Territorial (within borders) | Nationality (by citizens) |
| **Foreign Income** | Excluded | Included |
| **Example** | A Bangladeshi factory's output counts in Bangladesh's GDP | A Bangladeshi worker's earnings in Malaysia count in Bangladesh's GNP |

### Importance of GNP
- Better reflects the income available to a country's nationals
- Important for countries with significant remittance flows (e.g., Bangladesh, Philippines)
- GNP is now often referred to as **Gross National Income (GNI)** by the World Bank

### GNI (Gross National Income)
The World Bank now uses GNI instead of GNP. GNI = GDP + net receipts of primary income from abroad. Countries are classified by GNI per capita:
- Low income: ≤ $1,135
- Lower middle income: $1,136–$4,465
- Upper middle income: $4,466–$13,845
- High income: > $13,845`,
      },
      {
        title: "Measuring Income",
        content: `Income measurement in development economics involves several key concepts:

### National Income
The total income earned by all factors of production in a country. Various measures include:

**1. Net National Product (NNP)**
NNP = GNP – Depreciation (Consumption of Fixed Capital)
- Represents the net value of output after accounting for wear and tear of capital

**2. National Income at Factor Cost**
NI = NNP at market prices – Indirect taxes + Subsidies
- Represents the actual income earned by factors of production

**3. Personal Income**
PI = NI – Undistributed corporate profits – Social security contributions + Transfer payments
- Income received by individuals before personal taxes

**4. Disposable Income**
DI = Personal Income – Personal taxes
- Income available for spending or saving

### Challenges in Measuring Income in Developing Countries
1. **Large informal sector** — significant economic activity goes unrecorded
2. **Subsistence production** — self-consumed output is difficult to value
3. **Inadequate statistical infrastructure** — many developing countries lack robust data collection systems
4. **Currency conversion issues** — exchange rate fluctuations distort international comparisons
5. **Non-monetary transactions** — barter and gift economies are common
6. **Underground economy** — illegal or unreported activities`,
      },
      {
        title: "Per Capita Income",
        content: `**Per Capita Income** is the average income per person in a country, calculated by dividing total national income (or GDP/GNP) by the total population.

### Formula
**Per Capita Income = GDP (or GNI) / Total Population**

### Significance
- Simple, widely used indicator for comparing living standards across countries
- Used by international organizations (World Bank, IMF) for country classification
- Basis for determining eligibility for development assistance

### Limitations
1. **Ignores income distribution**: A high average can mask extreme inequality. If Bill Gates walks into a room of 50 people, the average income skyrockets but no one else becomes richer.

2. **Does not reflect purchasing power**: $1,000 buys very different amounts in the US versus Bangladesh.

3. **Ignores non-income dimensions**: Health, education, freedom, and environmental quality are not captured.

4. **Population effects**: A country could increase per capita income by reducing population without actually producing more.

5. **Exchange rate distortions**: Converting to a common currency (usually USD) using market exchange rates can misrepresent actual living standards.

6. **Does not capture informal economy**: Significant economic activity in developing countries is unrecorded.

### Example
Bangladesh's per capita GNI in 2023 was approximately $2,800, classifying it as a lower-middle-income country. However, when adjusted for purchasing power parity (PPP), it rises to about $6,600, reflecting the lower cost of living.`,
      },
      {
        title: "Purchasing Power Parity (PPP)",
        content: `**Purchasing Power Parity (PPP)** is an economic theory and exchange rate adjustment that equalizes the purchasing power of different currencies by accounting for differences in price levels across countries.

### The Law of One Price
PPP is based on the idea that in the absence of transaction costs and trade barriers, identical goods should sell for the same price in different countries when expressed in a common currency.

### PPP Exchange Rate
The PPP exchange rate is the rate at which one country's currency would need to be converted into another to buy the same basket of goods and services in both countries.

**Example**: If a basket of goods costs $100 in the US and ₹3,000 in India, the PPP exchange rate would be 30 ₹/$ (even if the market exchange rate is 83 ₹/$). This means that India's per capita income in PPP terms is much higher than when converted at market exchange rates.

### The Big Mac Index
The Economist's Big Mac Index is a simplified PPP comparison using the price of a Big Mac hamburger across countries. While informal, it illustrates the concept effectively.

### Why PPP Matters for Development

1. **More accurate comparisons**: PPP-adjusted incomes better reflect actual living standards than market exchange rates
2. **International poverty lines**: The World Bank's $2.15/day poverty line is in PPP terms
3. **Size of economies**: China and India's economies are much larger in PPP terms than at market exchange rates
4. **Aid allocation**: International organizations use PPP for resource allocation decisions

### International Comparison Program (ICP)
The World Bank's ICP collects price data from participating countries to calculate PPP exchange rates. This is a massive statistical exercise conducted every few years.

### Limitations of PPP
1. **Basket of goods differs**: Consumption patterns vary across countries
2. **Non-traded goods**: Services and non-traded goods don't equalize across borders
3. **Quality differences**: Same product may differ in quality across countries
4. **Data collection challenges**: Price surveys are expensive and complex
5. **Revision issues**: PPP estimates are revised significantly when new ICP rounds are completed`,
      },
    ],
    videos: [
      {
        title: "GDP, GNP, and National Income Explained",
        youtubeId: "VYMkmcRaILg",
        description: "Clear explanation of GDP, GNP, and national income concepts with examples.",
      },
      {
        title: "Purchasing Power Parity (PPP) Explained",
        youtubeId: "ozhOxiRx3as",
        description: "Understanding PPP and why it matters for international comparisons.",
      },
      {
        title: "Per Capita Income and Its Limitations",
        youtubeId: "G3CDGqFfmjo",
        description: "How per capita income is calculated and its limitations as a development indicator.",
      },
    ],
    materials: [
      {
        title: "World Bank Open Data",
        type: "article",
        url: "https://data.worldbank.org/",
        description: "Access to GDP, GNI, PPP data for all countries worldwide.",
      },
      {
        title: "Todaro & Smith - Measuring Development (Chapter 2)",
        type: "book",
        url: "https://www.google.com/search?q=Todaro+Smith+Economic+Development+measuring+development+PDF",
        description: "Textbook chapter on development measurement methods.",
      },
      {
        title: "The Big Mac Index - The Economist",
        type: "article",
        url: "https://www.economist.com/big-mac-index",
        description: "Interactive tool demonstrating purchasing power parity across countries.",
      },
      {
        title: "International Comparison Program (ICP)",
        type: "notes",
        url: "https://www.worldbank.org/en/programs/icp",
        description: "World Bank's program for PPP estimation and price comparison.",
      },
    ],
    questions: [
      {
        marks: 2,
        question: "Differentiate between GDP and GNP with an example.",
        answer: "**GDP** measures the total value of goods and services produced within a country's borders regardless of who produces them. **GNP** measures the total value produced by a country's nationals regardless of location. *Example:* If a Japanese company operates a factory in Bangladesh, the factory's output is part of Bangladesh's GDP but Japan's GNP. Conversely, remittances sent by Bangladeshi workers abroad contribute to Bangladesh's GNP but not its GDP. GNP = GDP + Net Factor Income from Abroad.",
      },
      {
        marks: 2,
        question: "What is Purchasing Power Parity (PPP)? Why is it important?",
        answer: "PPP is an exchange rate adjustment that equalizes the purchasing power of different currencies by accounting for price level differences across countries. It is important because: (1) it provides more accurate comparisons of living standards than market exchange rates; (2) the World Bank's international poverty line ($2.15/day) is set in PPP terms; (3) it reveals the true size of developing economies — China and India are much larger in PPP terms; (4) it accounts for the fact that non-traded goods and services are cheaper in developing countries.",
      },
      {
        marks: 5,
        question: "Critically evaluate GDP as a measure of development. What are its major limitations?",
        answer: "**GDP's Strengths:** GDP is widely available, regularly updated, and allows standardized comparisons across countries and over time. It captures the productive capacity of an economy.\n\n**Critical Limitations:**\n\n1. **Ignores Distribution:** GDP says nothing about how income is distributed. A country with high GDP may have extreme inequality (e.g., South Africa with Gini coefficient of 0.63).\n\n2. **Excludes Non-Market Activities:** Household work, subsistence farming, and volunteer activities are excluded. In developing countries, these constitute a significant portion of economic activity. Women's unpaid domestic work is systematically undervalued.\n\n3. **Environmental Blindness:** GDP counts environmental destruction as positive output. Deforestation, pollution, and resource depletion increase GDP but reduce long-term welfare. Natural disaster cleanup adds to GDP.\n\n4. **Quality of Life Neglected:** GDP does not capture health outcomes, educational quality, political freedom, or social cohesion. The US has high GDP but relatively poor health outcomes compared to countries with similar income.\n\n5. **Informal Economy:** In developing countries, 30-70% of economic activity may be informal and unrecorded, leading to significant underestimation of actual output.\n\n**Conclusion:** While GDP remains a useful economic indicator, development requires supplementary measures like HDI, Multidimensional Poverty Index, and genuine progress indicators.",
      },
      {
        marks: 5,
        question: "Explain the different methods of measuring GDP. Which method is most suitable for developing countries and why?",
        answer: "**Three Methods of Measuring GDP:**\n\n**1. Production (Output) Approach:** Sums value added at each stage of production across all sectors (agriculture, industry, services). Value Added = Output – Intermediate Consumption. This avoids double counting.\n\n**2. Income Approach:** Sums all factor incomes: wages, rents, interest, and profits, plus statistical adjustments (indirect taxes minus subsidies, depreciation). GDP = Compensation of employees + Gross operating surplus + Mixed income + Taxes on production minus Subsidies.\n\n**3. Expenditure Approach:** Sums all final spending: GDP = C + I + G + (X-M), where C = consumption, I = investment, G = government spending, X = exports, M = imports.\n\n**Most Suitable for Developing Countries:** The **Production Approach** is generally most suitable because:\n- It can capture sector-wise contributions (agriculture, industry, services), which is crucial for understanding structural transformation\n- It is less affected by the large informal economy than the income approach (wages and profits in informal sector are hard to track)\n- Census of production units can be conducted periodically\n- Government spending data (expenditure approach) may be unreliable in weak institutional settings\n\nHowever, all methods face challenges in developing countries due to weak statistical systems, large informal sectors, and subsistence production. Ideally, all three methods should yield the same result, and discrepancies highlight measurement issues.",
      },
      {
        marks: 10,
        question: "Discuss in detail the various measures of development. Critically analyze their strengths and limitations. Why is no single measure sufficient to capture the concept of development?",
        answer: "**Introduction:**\nDevelopment is a multidimensional concept that cannot be captured by any single indicator. Various measures have been developed, each with distinct strengths and limitations.\n\n**1. GDP and Per Capita Income:**\n*Strengths:* Widely available, standardized, allows cross-country comparison, regularly updated. *Limitations:* Ignores distribution, non-market activities, environmental costs, quality of life, and informal economy. Per capita income obscures inequality.\n\n**2. Purchasing Power Parity (PPP) Adjusted Income:**\n*Strengths:* Accounts for price level differences, provides more accurate living standard comparisons. *Limitations:* Complex to calculate, consumption baskets differ across countries, non-traded goods create challenges, revised significantly with each ICP round.\n\n**3. Human Development Index (HDI):**\nComposite of: life expectancy, education (mean and expected years of schooling), and GNI per capita. *Strengths:* Multidimensional, shifts focus beyond income, influences policy priorities. *Limitations:* Only three dimensions, equal weighting is arbitrary, national averages hide subnational disparities, doesn't capture inequality within dimensions.\n\n**4. Inequality-Adjusted HDI (IHDI):**\n*Strengths:* Accounts for inequality in each HDI dimension. *Limitations:* Data-intensive, still limited to three dimensions.\n\n**5. Multidimensional Poverty Index (MPI):**\nMeasures deprivation across health, education, and living standards using 10 indicators. *Strengths:* Identifies who is poor and how, captures overlapping deprivations, useful for targeting. *Limitations:* Indicator selection and cutoff points are debatable, data requirements are significant.\n\n**6. Gini Coefficient and Lorenz Curve:**\n*Strengths:* Quantifies income inequality on a 0-1 scale, visually intuitive (Lorenz Curve). *Limitations:* Same Gini can represent very different distributions, doesn't identify where inequality occurs (top, middle, bottom).\n\n**7. Gender Development Index (GDI) and Gender Inequality Index (GII):**\n*Strengths:* Highlights gender disparities in health, education, and economic participation. *Limitations:* Limited dimensions, doesn't capture violence, unpaid care work, or political representation fully.\n\n**8. Environmental Measures:**\nGreen GDP, Genuine Progress Indicator (GPI), Ecological Footprint. *Strengths:* Account for environmental costs and sustainability. *Limitations:* Valuing environmental services is methodologically challenging.\n\n**Why No Single Measure Suffices:**\n\n1. **Multidimensionality:** Development encompasses economic, social, political, environmental, and cultural dimensions that no single number can capture.\n\n2. **Value Judgments:** Different measures reflect different value priorities — income maximization vs. capability expansion vs. sustainability.\n\n3. **Aggregation Problems:** Combining diverse dimensions into a single index requires weighting decisions that are inherently subjective.\n\n4. **Context Specificity:** Development challenges vary by country — landlocked nations face different issues than island states; oil exporters differ from manufacturing economies.\n\n5. **Dynamic Nature:** Development is a process, not a state. Static indicators may miss trajectories and transitions.\n\n**Conclusion:**\nA comprehensive assessment of development requires a dashboard of indicators covering multiple dimensions. The SDGs with their 17 goals and 169 targets represent an attempt at this comprehensive approach. Policymakers should use multiple measures in combination, understanding the strengths and limitations of each, rather than relying on any single indicator.",
      },
    ],
  },
  {
    id: 3,
    section: "A",
    title: "Growth Theories and Growth Models",
    clos: "2, 3",
    topics: [
      {
        title: "Adam Smith's Theory of Economic Growth",
        content: `**Adam Smith** (1723–1790), often called the father of economics, presented his growth theory in "The Wealth of Nations" (1776).

### Key Elements

**1. Division of Labor**
Smith argued that specialization increases productivity through:
- Increased dexterity of workers
- Time saved from switching between tasks
- Innovation and invention by specialized workers
- The famous **pin factory example**: One worker alone might make 20 pins per day, but 10 workers with specialized tasks could produce 48,000 pins per day.

**2. Capital Accumulation**
Savings lead to investment, which increases the stock of capital. More capital means more division of labor is possible. Smith saw capital accumulation as the key driver of growth.

**3. Free Markets and the "Invisible Hand"**
Individuals pursuing self-interest are guided by market forces to promote social welfare. Government intervention should be minimal — limited to defense, justice, and public works.

**4. Extent of the Market**
Division of labor is limited by the extent of the market. Larger markets allow greater specialization. This provides the rationale for **free trade** — international trade expands market size.

**5. Productive vs. Unproductive Labor**
Smith distinguished between productive labor (manufacturing goods) and unproductive labor (services). While criticized today, this distinction influenced early growth thinking.

### Relevance and Criticism
- Smith's insights on specialization and trade remain foundational
- His emphasis on capital accumulation anticipated later growth models
- Critics note his neglect of technological change, institutional factors, and the role of government in development`,
      },
      {
        title: "Ricardian Theory",
        content: `**David Ricardo** (1772–1823) extended classical growth theory with his contributions on rent, comparative advantage, and the stationary state.

### Theory of Rent and Diminishing Returns
- As population grows, cultivation extends to less fertile land (extensive margin) or intensifies on existing land (intensive margin)
- This leads to **diminishing returns** to labor and capital in agriculture
- Landlords receive increasing rents as food prices rise
- Profits fall, reducing incentives for capital accumulation

### The Stationary State
Ricardo predicted an eventual "stationary state" where:
- Profits fall to zero
- Capital accumulation ceases
- Wages reach subsistence level
- Only landlords benefit from the surplus

### Comparative Advantage
Ricardo's most enduring contribution: countries should specialize in goods where they have the lowest **opportunity cost** of production.

**Example**: If England is more efficient at producing cloth and Portugal at producing wine, both countries benefit by specializing and trading, even if one country is absolutely more efficient in both goods.

### Relevance to Development
- The principle of comparative advantage supports free trade policies
- Diminishing returns concept influenced later growth models (Solow)
- The stationary state prediction was averted by technological progress (which Ricardo underestimated)`,
      },
      {
        title: "Marxian Theory",
        content: `**Karl Marx** (1818–1883) provided a radical critique of capitalism and its dynamics of growth and crisis.

### Historical Materialism
Society evolves through stages determined by the mode of production:
Primitive Communism → Slavery → Feudalism → Capitalism → Socialism → Communism

### Key Concepts

**1. Labor Theory of Value**
The value of a commodity is determined by the socially necessary labor time required to produce it.

**2. Surplus Value**
The difference between the value workers produce and the wages they receive. Capitalists extract surplus value as profit — this is the source of exploitation.
**Surplus Value = Total Value of Output – Wages paid to workers**

**3. Capital Accumulation and Crisis**
- Capitalists reinvest surplus value to accumulate more capital
- This leads to increasing **organic composition of capital** (more machinery, less labor)
- The **tendency of the rate of profit to fall** results from substituting capital for labor
- Periodic crises of overproduction occur as workers cannot afford to buy what they produce

**4. Class Struggle**
Society is divided into two main classes:
- **Bourgeoisie** (capitalists who own means of production)
- **Proletariat** (workers who sell their labor)
Class conflict drives historical change.

**5. Reserve Army of Labor**
Unemployment is structural in capitalism — it keeps wages low and discipline high among workers.

### Relevance to Development
- Marx's analysis of exploitation resonates with dependency theory and global inequality
- His focus on structural transformation and class dynamics remains relevant
- Criticisms: prediction of capitalism's collapse hasn't materialized; communist experiments often led to authoritarianism and economic inefficiency`,
      },
      {
        title: "Schumpeterian Theory",
        content: `**Joseph Schumpeter** (1883–1950) emphasized the role of innovation and entrepreneurship in economic growth.

### Creative Destruction
Schumpeter's central concept: economic progress occurs through **creative destruction** — new innovations make old products, firms, and industries obsolete.

**Examples of Creative Destruction:**
- Automobiles replaced horse-drawn carriages
- Digital cameras destroyed the film photography industry (Kodak)
- Smartphones replaced standalone GPS devices, cameras, and MP3 players
- E-commerce disrupting traditional retail

### The Role of the Entrepreneur
The entrepreneur is the key agent of change who:
- Introduces new products or production methods
- Opens new markets
- Discovers new sources of raw materials
- Creates new organizational forms

Entrepreneurs are not merely managers — they are innovators who disrupt existing economic structures.

### Five Types of Innovation
1. **New products** — introduction of goods consumers are not yet familiar with
2. **New methods of production** — new ways of manufacturing not yet proven in the industry
3. **New markets** — opening a market that has not been entered before
4. **New sources of supply** — finding new sources of raw materials
5. **New organizational structures** — creating monopoly or breaking up existing monopoly

### Business Cycles
Innovation occurs in clusters, creating boom-bust cycles:
- **Boom**: Cluster of innovations stimulates investment and growth
- **Bust**: As innovations are absorbed, growth slows and adjustments occur

### Relevance to Development
- Highlights the critical role of innovation and entrepreneurship
- Explains why some economies (Silicon Valley, Shenzhen) grow rapidly
- Challenges for developing countries: weak innovation ecosystems, brain drain, limited R&D investment
- Policy implication: governments should create enabling environments for entrepreneurs`,
      },
      {
        title: "Keynesian Theory",
        content: `**John Maynard Keynes** (1883–1946) revolutionized economics with "The General Theory of Employment, Interest, and Money" (1936).

### Core Ideas

**1. Effective Demand**
The level of output and employment is determined by aggregate demand, not supply. Insufficient demand leads to unemployment and recession.

**2. The Multiplier Effect**
An initial increase in spending creates a ripple effect through the economy:
**Multiplier = 1 / (1 – MPC)** where MPC = Marginal Propensity to Consume

If MPC = 0.8, multiplier = 5. So $1 million in government spending generates $5 million in total income.

**3. Government Intervention**
During recessions, private investment falls. Government must step in with fiscal policy (spending and taxation) to maintain aggregate demand.

**4. Paradox of Thrift**
If everyone saves more during a recession, total demand falls, output decreases, and total savings actually decline.

**5. Liquidity Preference**
Interest rates are determined by the supply and demand for money, not just by savings and investment.

### Relevance to Development Economics
- Justifies government intervention in developing economies
- The multiplier effect supports public investment in infrastructure
- Challenges Say's Law ("supply creates its own demand")
- Limitations: Keynes focused on short-run stabilization in developed economies; developing countries face structural (not just cyclical) problems
- Keynesian policies may lead to inflation and fiscal deficits in developing countries with limited tax bases`,
      },
      {
        title: "Stages of Growth Theory (Rostow)",
        content: `**W.W. Rostow** (1916–2003) proposed in "The Stages of Economic Growth: A Non-Communist Manifesto" (1960) that all countries pass through five stages of economic development.

### The Five Stages

**1. Traditional Society**
- Subsistence agriculture dominates
- Limited technology and productivity
- Hierarchical social structure
- Pre-Newtonian science and technology
- Output is limited by available technology

**2. Preconditions for Take-off**
- Agricultural revolution increases food supply
- Development of infrastructure (roads, railways)
- Emergence of entrepreneurial class
- Expansion of education
- External influences promote change
- Examples: Western Europe in late 17th–18th centuries

**3. Take-off**
- The critical stage — growth becomes self-sustaining
- Investment rises from 5% to 10%+ of national income
- Leading sectors emerge that drive growth
- Political and institutional frameworks support industrialization
- Duration: approximately 20-30 years
- Examples: Britain (1783–1803), US (1843–1860), India (1952–), China (1952–)

**4. Drive to Maturity**
- Technology spreads across all sectors
- Economy diversifies beyond original leading sectors
- 10-20% of national income is invested
- International trade grows
- Duration: approximately 60 years after take-off

**5. Age of High Mass Consumption**
- Leading sectors shift to consumer durables and services
- Real income rises to the point where many people can afford goods beyond basic needs
- Social welfare policies expand
- Examples: US post-1920s, Western Europe post-1950s

### Criticisms
1. **Linear model**: Assumes all countries follow the same path — ignores unique historical, cultural, and institutional contexts
2. **Eurocentric**: Based on Western European/American experience
3. **Ignores external factors**: Colonialism, dependency, unequal trade relationships
4. **Vague criteria**: The conditions for "take-off" are not precisely defined
5. **Ignores structural barriers**: Does not address inequality, institutional weakness, or resource constraints`,
      },
      {
        title: "Balanced and Unbalanced Growth",
        content: `These contrasting strategies address how developing countries should allocate their limited investment resources.

### Balanced Growth Theory
**Proponents**: Ragnar Nurkse, Paul Rosenstein-Rodan

**Core Argument**: Investment should be spread across all sectors simultaneously to create demand for each other's products and overcome the "vicious circle of poverty."

**Nurkse's Vicious Circle of Poverty**:
- **Supply side**: Low income → Low savings → Low investment → Low productivity → Low income
- **Demand side**: Low income → Low demand → Low incentive to invest → Low production → Low income

**Big Push**: A massive, coordinated investment across sectors is needed to break out of the poverty trap. Individual investments fail because of insufficient demand, but simultaneous investments create mutual markets.

**Example**: If a country only builds a shoe factory, there may not be enough demand. But if it simultaneously invests in food processing, textiles, construction, and shoes, workers in each industry become consumers for the others.

### Unbalanced Growth Theory
**Proponent**: Albert O. Hirschman

**Core Argument**: Investment should be concentrated in strategic sectors that create forward and backward linkages, stimulating investment in other sectors through market forces.

**Linkages**:
- **Backward linkages**: Investment in a sector stimulates demand for inputs (e.g., automobile industry stimulates steel, rubber, glass production)
- **Forward linkages**: Output of a sector becomes input for another (e.g., steel production enables machinery manufacturing)

**Social Overhead Capital (SOC) vs. Directly Productive Activities (DPA)**:
- SOC: Infrastructure (roads, power, water) — enables DPA
- DPA: Manufacturing, agriculture — directly produces goods

### Comparison

| Feature | Balanced Growth | Unbalanced Growth |
|---------|----------------|-------------------|
| Investment | Spread across sectors | Concentrated in strategic sectors |
| Role of State | Central planning required | Market forces play larger role |
| Feasibility | Requires massive resources | More realistic for resource-scarce countries |
| Risk | Spreads resources too thin | May neglect some sectors |`,
      },
      {
        title: "Big Push Theory",
        content: `**Paul Rosenstein-Rodan** (1943) proposed the Big Push Theory, arguing that developing countries need a large, coordinated investment program to break out of the poverty trap.

### Core Arguments

**1. Indivisibilities**
Three types of indivisibilities create the need for a big push:
- **Indivisibility of production**: Modern industries require minimum scale (you can't build half a steel mill)
- **Indivisibility of demand**: Individual investments may fail due to insufficient demand, but coordinated investments create mutual markets
- **Indivisibility of savings**: The minimum investment needed exceeds what small savings can fund

**2. External Economies**
- **Pecuniary externalities**: One firm's investment increases demand for other firms' products
- **Technological externalities**: Infrastructure investments benefit all firms (roads, power, education)

**3. Complementarity of Demand**
Workers in newly established industries spend their wages on products of other industries, creating a virtuous circle of demand.

### The Coordination Problem
Individual firms underinvest because they don't account for the positive effects their investment has on other firms. Only large-scale coordinated investment can overcome this market failure.

### Criticisms
1. Where do the massive resources come from? Developing countries cannot save enough for a big push
2. Assumes perfect information and coordination — unrealistic
3. Government capacity to plan and implement is limited in developing countries
4. Ignores absorptive capacity — too much investment too fast can be wasteful
5. Historical evidence is mixed — some countries developed incrementally (China's gradual reforms)`,
      },
      {
        title: "Harrod-Domar Growth Model",
        content: `The **Harrod-Domar Model** (developed independently by Roy Harrod in 1939 and Evsey Domar in 1946) was one of the earliest formal growth models.

### The Model

**Growth Rate (g) = s / k**

Where:
- **g** = rate of growth of GDP
- **s** = savings rate (proportion of national income saved)
- **k** = capital-output ratio (amount of capital needed to produce one unit of output)

### Key Assumptions
1. Output is proportional to capital stock
2. Savings = Investment (in equilibrium)
3. Capital-output ratio is constant
4. No diminishing returns to capital
5. Labor supply is not a constraint

### Example
If a country saves 20% of GDP (s = 0.20) and the capital-output ratio is 4 (k = 4):
g = 0.20 / 4 = 0.05 = **5% growth rate**

To achieve 7% growth with the same capital-output ratio:
Required savings = 7% × 4 = **28% of GDP**

### The Financing Gap
If domestic savings are insufficient to achieve the desired growth rate, the gap must be filled by:
- **Foreign aid** — the "two-gap model" (savings gap and foreign exchange gap)
- **Foreign direct investment**
- **Borrowing**

This model provided the intellectual foundation for massive aid programs in the 1960s-70s.

### Criticisms
1. **Capital is not the only constraint**: Ignores technology, human capital, institutions
2. **Constant capital-output ratio**: Unrealistic — diminishing returns to capital are real
3. **Savings ≠ Growth**: Countries like the USSR had high savings but inefficient investment
4. **Aid doesn't always lead to growth**: The "financing gap" approach often failed
5. **Knife-edge instability**: The model's balanced growth path is unstable
6. **No technological progress**: Cannot explain sustained long-run growth`,
      },
      {
        title: "Exogenous and Endogenous Growth Theory",
        content: `### Solow-Swan Model (Exogenous Growth)
**Robert Solow** (1956) developed the neoclassical growth model that became the foundation of modern growth theory.

**Key Features:**
- Production function: **Y = A × F(K, L)** where A = technology, K = capital, L = labor
- **Diminishing returns to capital**: Each additional unit of capital produces less additional output
- **Steady state**: The economy converges to a long-run equilibrium where capital per worker and output per worker are constant
- **Technological progress is exogenous**: It is assumed to happen but not explained by the model
- **Convergence**: Poor countries should grow faster than rich ones (conditional convergence)

**Key Predictions:**
1. Capital accumulation alone cannot sustain long-run growth (due to diminishing returns)
2. Only **technological progress** can drive sustained per capita growth
3. Countries with similar parameters should converge in income levels

**Solow Residual**: The portion of growth not explained by capital and labor growth — attributed to technological progress (Total Factor Productivity). Solow found that 87.5% of US growth was due to technological progress, not capital accumulation.

### Endogenous Growth Theory
Developed in the 1980s-90s by **Paul Romer** and **Robert Lucas** to explain what drives technological progress.

**Key Models:**

**1. AK Model (Rebelo, 1991)**
- Y = AK — constant returns to capital (broadly defined to include human capital)
- No diminishing returns → no convergence → perpetual growth possible
- Investment in capital (including human capital) generates sustained growth

**2. Romer's Model (1990)**
- Technological progress is driven by deliberate R&D investment
- Knowledge has **increasing returns** — ideas are non-rival and can be shared
- Larger economies have advantages in innovation (larger market for ideas)
- **Policy implication**: Governments should subsidize R&D, protect intellectual property

**3. Lucas's Human Capital Model (1988)**
- Human capital accumulation through education drives growth
- Human capital has external effects — educated workers make everyone more productive
- **Policy implication**: Invest heavily in education

### Comparison

| Feature | Exogenous Growth | Endogenous Growth |
|---------|-----------------|-------------------|
| Technology | Exogenous (given) | Endogenous (explained) |
| Returns to capital | Diminishing | Constant or increasing |
| Convergence | Predicted | Not necessarily |
| Policy implications | Limited | Strong (R&D, education, institutions) |
| Long-run growth driver | Unexplained technical progress | Innovation, human capital, knowledge |

### Relevance to Development
- Exogenous theory explains convergence but not the persistent income gaps between countries
- Endogenous theory explains why some countries (with more R&D, better education) grow faster
- Both emphasize the importance of investment in human capital and technology for developing countries`,
      },
    ],
    videos: [
      {
        title: "Classical Growth Theories Explained",
        youtubeId: "SbCeTKJ15Yw",
        description: "Overview of Smith, Ricardo, Marx, and classical growth theories.",
      },
      {
        title: "Harrod-Domar Growth Model",
        youtubeId: "FpBg3tFkJIo",
        description: "Detailed explanation of the Harrod-Domar model with numerical examples.",
      },
      {
        title: "Solow Growth Model Explained",
        youtubeId: "eVAS-t83OEs",
        description: "The neoclassical Solow model and its implications for economic growth.",
      },
      {
        title: "Rostow's Stages of Growth",
        youtubeId: "FRqJhSJMhFs",
        description: "Understanding Rostow's five stages of economic growth theory.",
      },
      {
        title: "Endogenous Growth Theory",
        youtubeId: "P5ZJui3aPoQ",
        description: "Romer and Lucas's endogenous growth models explained.",
      },
    ],
    materials: [
      {
        title: "Growth Theories Comparison Notes",
        type: "notes",
        url: "https://www.google.com/search?q=development+economics+growth+theories+comparison+notes+PDF",
        description: "Comprehensive notes comparing all major growth theories.",
      },
      {
        title: "Solow Model - MIT OpenCourseWare",
        type: "slides",
        url: "https://ocw.mit.edu/courses/14-02-principles-of-macroeconomics-spring-2023/",
        description: "MIT lecture slides on the Solow growth model.",
      },
      {
        title: "Todaro & Smith - Growth Theories (Chapters 3-4)",
        type: "book",
        url: "https://www.google.com/search?q=Todaro+Smith+Economic+Development+growth+theories+chapters+PDF",
        description: "Textbook chapters covering classical and modern growth theories.",
      },
    ],
    questions: [
      {
        marks: 2,
        question: "State the Harrod-Domar growth equation and explain its components.",
        answer: "The Harrod-Domar growth equation is: **g = s/k**, where g = rate of GDP growth, s = savings rate (proportion of national income saved), and k = capital-output ratio (units of capital needed to produce one unit of output). The model suggests that economic growth depends directly on the savings rate and inversely on the capital-output ratio. For example, if s = 0.20 and k = 4, then g = 5%.",
      },
      {
        marks: 2,
        question: "What is Schumpeter's concept of creative destruction?",
        answer: "Creative destruction is Schumpeter's concept describing the process by which new innovations make existing products, firms, and industries obsolete. It is the essential dynamic of capitalism — entrepreneurs introduce innovations (new products, methods, markets) that destroy old economic structures while creating new ones. Examples include how automobiles replaced horses, digital photography destroyed film (Kodak), and smartphones replaced standalone cameras and GPS devices. This process drives long-run economic growth.",
      },
      {
        marks: 5,
        question: "Compare and contrast the Balanced Growth and Unbalanced Growth strategies. Which is more appropriate for developing countries?",
        answer: "**Balanced Growth (Nurkse, Rosenstein-Rodan):**\n- Investment should be spread simultaneously across all sectors\n- Creates mutual markets and overcomes the vicious circle of poverty\n- Requires massive coordinated investment (Big Push)\n- Requires strong state planning capacity\n\n**Unbalanced Growth (Hirschman):**\n- Investment should be concentrated in strategic sectors with strong linkages\n- Forward and backward linkages stimulate related industries\n- More realistic given scarce resources\n- Relies on market forces to transmit growth impulses\n\n**For Developing Countries:** Unbalanced growth is generally more appropriate because: (1) developing countries lack the massive resources needed for a Big Push; (2) government planning capacity is often limited; (3) strategic investments in sectors with strong linkages (infrastructure, key industries) can catalyze growth; (4) it allows learning and adjustment. However, a hybrid approach may be best — targeted investment in strategic sectors complemented by basic investment in infrastructure and human capital across the economy.",
      },
      {
        marks: 5,
        question: "Critically evaluate Rostow's Stages of Growth theory. Is it applicable to developing countries today?",
        answer: "**Rostow's Five Stages:** Traditional Society → Preconditions for Take-off → Take-off → Drive to Maturity → Age of High Mass Consumption.\n\n**Strengths:**\n- Provides a clear, comprehensible framework for understanding development\n- Highlights the importance of investment, infrastructure, and institutional change\n- The concept of 'take-off' captures the idea of structural transformation\n\n**Critical Evaluation:**\n1. **Linear determinism:** Assumes all countries follow the same sequence — ignores unique historical, cultural, and geographical contexts\n2. **Eurocentric bias:** Based on Western European and American experience; does not account for colonial legacies that shaped developing countries differently\n3. **Ignores external factors:** Does not address how colonialism, unequal trade, and dependency relationships constrain developing countries\n4. **Vague criteria:** The conditions for 'take-off' (10% investment rate) are arbitrary and not supported by empirical evidence\n5. **Ignores structural barriers:** Does not address inequality, class structures, gender discrimination, or institutional weaknesses\n\n**Applicability Today:** Limited. Modern development is non-linear — countries can leapfrog stages (mobile banking in Kenya skipping traditional banking), face reversals (Venezuela), or develop in unique patterns (China's gradual reform). The model remains useful as a heuristic but not as a policy guide.",
      },
      {
        marks: 10,
        question: "Discuss the major economic growth theories from classical to modern. How do endogenous growth models improve upon the Solow model? Illustrate with examples from developing countries.",
        answer: "**Introduction:**\nEconomic growth theories have evolved from classical models focused on capital accumulation to modern theories emphasizing innovation, human capital, and institutions.\n\n**1. Classical Theories:**\n**Adam Smith** emphasized division of labor, capital accumulation, and free markets. **Ricardo** focused on comparative advantage and diminishing returns. **Marx** analyzed surplus value extraction and capitalism's inherent contradictions. *Example:* Smith's insight on specialization is visible in Bangladesh's garment industry — specialization in ready-made garments has driven export growth.\n\n**2. Keynesian Framework:**\nKeynes emphasized aggregate demand and government intervention. The **Harrod-Domar model** formalized the relationship between savings, capital-output ratio, and growth (g = s/k). This model influenced post-war development planning and foreign aid. *Example:* India's Five-Year Plans used Harrod-Domar to calculate required investment levels.\n\n**3. Neoclassical (Solow) Model:**\n- Production function Y = A·F(K,L) with diminishing returns to capital\n- Predicts convergence to a steady state\n- Long-run growth depends on exogenous technological progress\n- The Solow Residual showed that most US growth was due to technology (TFP), not capital\n\n**Limitations of Solow Model:**\n- Technology is treated as a 'black box' — exogenous and unexplained\n- Predicts convergence that hasn't fully materialized (Africa hasn't caught up with Europe)\n- Cannot explain persistent cross-country income differences\n- Limited policy implications — growth is ultimately driven by technological luck\n\n**4. Endogenous Growth Models:**\n\n**Romer (1990) — Knowledge/R&D Model:**\n- Innovation is a deliberate economic activity driven by profit-seeking firms\n- Knowledge is non-rival (can be shared without diminishing) and partially excludable (patents)\n- Increasing returns to knowledge → no diminishing returns → sustained growth possible\n- **Improvement over Solow:** Explains why technological progress happens and how policy can influence it\n- *Example:* South Korea's deliberate investment in R&D (now 4.5% of GDP) transformed it from an agrarian economy to a technology leader.\n\n**Lucas (1988) — Human Capital Model:**\n- Investment in education and skills generates positive externalities\n- Educated workers make everyone around them more productive\n- Human capital accumulation can overcome diminishing returns\n- **Improvement over Solow:** Explains why countries investing more in education grow faster\n- *Example:* East Asian Tigers invested heavily in universal education before industrialization, creating the human capital base for rapid growth.\n\n**AK Model:**\n- Capital (broadly defined to include human capital) has constant returns\n- Growth rate depends on savings rate — no convergence predicted\n- Explains persistent income gaps between countries\n\n**How Endogenous Models Improve Upon Solow:**\n\n| Dimension | Solow Model | Endogenous Models |\n|-----------|-------------|-------------------|\n| Technology | Exogenous | Explained by R&D, innovation |\n| Returns to capital | Diminishing | Constant or increasing |\n| Convergence | Predicted | Not necessarily |\n| Policy role | Limited | Strong (education, R&D, institutions) |\n| Human capital | Not modeled | Central role |\n| Sustained growth | Only from tech. progress | Multiple sources |\n\n**Implications for Developing Countries:**\n1. **Invest in education** — human capital is a key growth driver (Lucas). Vietnam's success in manufacturing partly stems from high literacy rates.\n2. **Build innovation capacity** — even modest R&D can generate significant returns. India's IT sector grew through deliberate development of engineering education.\n3. **Technology transfer** — developing countries can adopt existing technologies rather than inventing new ones. China's technology absorption strategy accelerated its catch-up.\n4. **Institutional quality matters** — endogenous growth models highlight how institutions shape incentives for innovation and investment.\n5. **Avoid the convergence trap** — without deliberate policy, convergence is not automatic. Sub-Saharan Africa shows that without appropriate policies, income gaps can persist or widen.\n\n**Conclusion:**\nEndogenous growth models represent a significant advance over the Solow model by explaining the sources of technological progress and providing actionable policy implications. For developing countries, these models emphasize the importance of education, innovation capacity, and institutional quality — not just capital accumulation — for sustained economic growth.",
      },
    ],
  },
  {
    id: 4,
    section: "A",
    title: "Human Development",
    clos: "3",
    topics: [
      {
        title: "Meaning of Human Development",
        content: `**Human Development** is the process of enlarging people's choices and capabilities. The concept was pioneered by **Mahbub ul Haq** and **Amartya Sen** and became the foundation of the UNDP's Human Development Reports.

### Definition
According to the UNDP: "Human development is about expanding the richness of human life, rather than simply the richness of the economy in which human beings live."

### Core Dimensions
The three essential dimensions of human development are:
1. **Long and healthy life** — measured by life expectancy at birth
2. **Knowledge** — measured by expected years of schooling and mean years of schooling
3. **A decent standard of living** — measured by GNI per capita (PPP)

### Key Principles
- **People are the real wealth of nations** — economic growth is a means, not an end
- **Human development is about choice** — expanding what people can do and be
- **Both building capabilities and using them** — creating capabilities (health, education) and using them (work, participation)
- **Equity and sustainability** — development must be for all people and for future generations`,
      },
      {
        title: "Historical Perspective",
        content: `The concept of human development has deep historical roots but was formally articulated in the late 20th century.

### Early Antecedents
- **Aristotle**: "Wealth is evidently not the good we are seeking; for it is merely useful and for the sake of something else."
- **Adam Smith**: Despite focusing on economic growth, Smith recognized that the purpose of economic activity was to enable human flourishing.
- **Utilitarian philosophy**: Jeremy Bentham and John Stuart Mill focused on maximizing human happiness and welfare.

### Modern Development (20th Century)

**1. Basic Needs Approach (1970s)**
The ILO proposed focusing on meeting basic needs: food, shelter, clothing, education, health. This was a precursor to the human development approach.

**2. Amartya Sen's Capabilities Approach (1980s)**
Sen argued that development should be measured by what people are able to do and be (capabilities), not just by income. His work on famine (showing that famines occur even with adequate food supply due to entitlement failures) revolutionized thinking.

**3. Mahbub ul Haq and the HDR (1990)**
Pakistani economist Mahbub ul Haq created the **Human Development Report** and the **Human Development Index** in 1990, operationalizing Sen's ideas. He argued: "The basic purpose of development is to enlarge people's choices."

**4. Sustainable Development (2000s-present)**
The Millennium Development Goals (MDGs, 2000) and Sustainable Development Goals (SDGs, 2015) expanded the human development framework to include environmental sustainability, peace, and justice.`,
      },
      {
        title: "Measurement of Human Development",
        content: `### Human Development Index (HDI)
The HDI is a composite measure of three dimensions:

**1. Health Dimension**
- Indicator: Life expectancy at birth
- Minimum value: 20 years
- Maximum value: 85 years

**2. Education Dimension**
- Indicator 1: Expected years of schooling (for children of school entering age)
- Indicator 2: Mean years of schooling (for adults 25+)
- Combined into an education index

**3. Living Standard Dimension**
- Indicator: GNI per capita (PPP $)
- Minimum value: $100
- Maximum value: $75,000
- Logarithmic transformation (reflecting diminishing returns to income)

### Calculating HDI
**Step 1**: Calculate dimension indices:
Dimension Index = (Actual value – Minimum value) / (Maximum value – Minimum value)

**Step 2**: HDI = Geometric mean of three dimension indices
**HDI = (Health Index × Education Index × Income Index)^(1/3)**

### HDI Categories
- Very High: ≥ 0.800
- High: 0.700–0.799
- Medium: 0.550–0.699
- Low: < 0.550

### Other Human Development Indices

**Inequality-adjusted HDI (IHDI)**: Adjusts HDI for inequality in each dimension. The greater the inequality, the lower the IHDI relative to HDI.

**Gender Development Index (GDI)**: Ratio of female to male HDI values. Measures gender gaps in human development.

**Gender Inequality Index (GII)**: Measures gender disadvantages in reproductive health, empowerment, and labor market participation.

**Multidimensional Poverty Index (MPI)**: Measures non-income deprivations in health, education, and living standards using 10 indicators.`,
      },
      {
        title: "Policies for Human Development",
        content: `Effective human development policies address multiple dimensions simultaneously:

### 1. Health Policies
- Universal healthcare coverage
- Maternal and child health programs
- Immunization campaigns
- Clean water and sanitation
- Nutrition programs
- Disease prevention (HIV/AIDS, malaria, tuberculosis)
- *Example:* Thailand's Universal Coverage Scheme (2001) dramatically improved health outcomes at modest cost

### 2. Education Policies
- Universal primary education
- Quality improvement in schools
- Teacher training and incentives
- Girls' education initiatives
- Technical and vocational training
- Higher education access
- *Example:* Bangladesh's Female Secondary School Assistance Program significantly increased girls' enrollment

### 3. Income and Employment
- Labor market reforms
- Minimum wage policies
- Social safety nets (cash transfers, food subsidies)
- Microfinance and financial inclusion
- SME development
- *Example:* Brazil's Bolsa Família conditional cash transfer program lifted millions out of poverty

### 4. Gender Equality
- Legal reforms for equal rights
- Women's labor force participation
- Political representation
- Protection from violence
- Reproductive rights
- *Example:* Rwanda achieved 61% women in parliament through constitutional quotas

### 5. Environmental Sustainability
- Clean energy transition
- Natural resource management
- Climate adaptation strategies
- Pollution control`,
      },
      {
        title: "Human Capital Formulation",
        content: `**Human Capital** refers to the stock of knowledge, skills, health, and attributes embodied in individuals that contribute to their productive capacity.

### Components of Human Capital
1. **Education and training** — formal education, vocational training, on-the-job learning
2. **Health** — physical and mental well-being that enables productive work
3. **Skills** — technical, cognitive, and social skills
4. **Experience** — learning by doing and accumulated knowledge

### Human Capital Theory
**Gary Becker** (1964) formalized human capital theory, arguing that:
- Investment in education and training increases productivity and earnings
- Individuals make rational decisions about investing in education based on expected returns
- **Rate of return to education** = additional earnings from education / cost of education

### Investment in Human Capital

**Public Investment:**
- Universal education systems
- Public health infrastructure
- Research institutions
- Training programs

**Private Investment:**
- Individual decisions to pursue education
- Firm-level training programs
- Family investments in children's education and health

### Returns to Human Capital
- **Private returns**: Higher wages and employment probability for educated individuals
- **Social returns**: Higher productivity, lower crime, better health, democratic participation, lower fertility
- Returns are typically highest for primary education in developing countries

### Challenges in Developing Countries
1. **Quality vs. quantity**: Enrollment without quality leads to "schooling without learning"
2. **Brain drain**: Educated individuals emigrate to developed countries
3. **Gender gaps**: Girls often face barriers to education
4. **Health burden**: Disease (malaria, HIV) depletes human capital
5. **Child labor**: Poverty forces children into work instead of school`,
      },
      {
        title: "Human Development Index",
        content: `The **Human Development Index (HDI)** was created by **Mahbub ul Haq** with the collaboration of **Amartya Sen** and first published in the 1990 Human Development Report.

### Purpose
To shift the focus of development from national income accounting to people-centered policies. As Haq said: "The real wealth of a nation is its people."

### Numerical Example
**Calculating HDI for a hypothetical country:**

Given: Life expectancy = 70 years, Mean years of schooling = 8, Expected years of schooling = 12, GNI per capita = $10,000 (PPP)

**Health Index** = (70 – 20) / (85 – 20) = 50/65 = 0.769

**Education Index:**
- Mean years index = (8 – 0) / (15 – 0) = 0.533
- Expected years index = (12 – 0) / (18 – 0) = 0.667
- Education Index = (0.533 + 0.667) / 2 = 0.600

**Income Index** = [ln(10,000) – ln(100)] / [ln(75,000) – ln(100)]
= (9.21 – 4.61) / (11.23 – 4.61) = 4.60 / 6.62 = 0.695

**HDI** = (0.769 × 0.600 × 0.695)^(1/3) = (0.321)^(1/3) = **0.685** (Medium HD)

### Global HDI Rankings (Recent)
- Switzerland, Norway, Iceland consistently rank at the top
- South Sudan, Central African Republic, Niger rank at the bottom
- Bangladesh's HDI has improved significantly (from 0.388 in 1990 to ~0.670 in recent years)

### Strengths of HDI
1. Simple and transparent
2. Shifts focus from GDP to human well-being
3. Enables cross-country comparisons
4. Highlights that income alone is insufficient

### Limitations
1. Only three dimensions — ignores inequality, political freedom, environment
2. National averages hide subnational disparities
3. Equal weighting of dimensions is arbitrary
4. GNI per capita still dominates (due to logarithmic transformation)
5. Quality of education is not captured (only years of schooling)`,
      },
      {
        title: "Human Development Report",
        content: `The **Human Development Report (HDR)** is published annually by the **United Nations Development Programme (UNDP)** since 1990.

### Origin
Created by **Mahbub ul Haq** of Pakistan, the first HDR was published in 1990 with the message: "People are the real wealth of a nation."

### Structure of the HDR
1. **Thematic analysis** — each year focuses on a specific development theme
2. **Statistical tables** — comprehensive data on HDI and related indices for all countries
3. **Policy recommendations** — evidence-based policy suggestions

### Notable HDR Themes
- 1990: Concept and Measurement of Human Development
- 1994: Human Security
- 1995: Gender and Human Development
- 1999: Globalization with a Human Face
- 2003: Millennium Development Goals
- 2010: The Real Wealth of Nations (20th anniversary)
- 2015: Work for Human Development
- 2019: Beyond Income, Beyond Averages, Beyond Today
- 2020: The Next Frontier: Human Development and the Anthropocene

### Impact of the HDR
1. **Shifted development discourse** from GDP to human well-being
2. **Policy influence** — governments use HDI rankings to set priorities
3. **Data availability** — made comparative development data widely accessible
4. **National HDRs** — many countries now produce national human development reports
5. **Academic impact** — spawned extensive research on capabilities and human development

### Bangladesh in the HDR
Bangladesh has been a notable development success story:
- HDI increased from 0.388 (1990) to approximately 0.670
- Life expectancy increased from 56 to 73 years
- Mean years of schooling doubled
- GNI per capita increased significantly
- Gender parity in education achieved
- Remarkable progress despite low income, highlighting that human development is possible without high income`,
      },
    ],
    videos: [
      {
        title: "Human Development Index Explained",
        youtubeId: "okJYMnGPTAU",
        description: "How HDI is calculated and what it tells us about a country's development.",
      },
      {
        title: "Amartya Sen's Capability Approach",
        youtubeId: "vBn4wFNoiCg",
        description: "Understanding Sen's revolutionary approach to development and freedom.",
      },
      {
        title: "Human Capital Theory",
        youtubeId: "JDkA4LAeFtQ",
        description: "Gary Becker's human capital theory and its implications for development.",
      },
    ],
    materials: [
      {
        title: "UNDP Human Development Reports",
        type: "article",
        url: "https://hdr.undp.org/",
        description: "Official UNDP portal with all Human Development Reports and data.",
      },
      {
        title: "Human Development Lecture Notes",
        type: "notes",
        url: "https://www.google.com/search?q=human+development+index+lecture+notes+development+economics+PDF",
        description: "Comprehensive lecture notes on human development concepts and measurement.",
      },
      {
        title: "HDI Calculator and Data",
        type: "article",
        url: "https://hdr.undp.org/data-center/human-development-index",
        description: "Interactive HDI data explorer with country rankings and trends.",
      },
    ],
    questions: [
      {
        marks: 2,
        question: "What are the three dimensions of the Human Development Index?",
        answer: "The three dimensions of HDI are: (1) **Long and healthy life** — measured by life expectancy at birth; (2) **Knowledge/Education** — measured by mean years of schooling (for adults 25+) and expected years of schooling (for children of school-entering age); (3) **A decent standard of living** — measured by Gross National Income (GNI) per capita in PPP dollars. The HDI is calculated as the geometric mean of the three dimension indices.",
      },
      {
        marks: 2,
        question: "Who created the Human Development Index and why?",
        answer: "The HDI was created by Pakistani economist **Mahbub ul Haq** with the collaboration of Nobel laureate **Amartya Sen**, and was first published in the UNDP's inaugural Human Development Report in 1990. It was created to shift the focus of development assessment from mere national income (GDP) to people-centered measures. As Haq stated, 'The real wealth of a nation is its people.' The HDI was designed to capture development beyond income by including health and education dimensions.",
      },
      {
        marks: 5,
        question: "Discuss the concept of human capital and its importance for economic development. What are the challenges in human capital formation in developing countries?",
        answer: "**Human Capital** refers to the stock of knowledge, skills, health, and capabilities embodied in people that contribute to their productive capacity. Gary Becker formalized the theory, arguing that investment in education and health increases productivity and earnings.\n\n**Importance for Development:**\n1. Increases labor productivity — educated, healthy workers produce more\n2. Drives innovation and technological adoption\n3. Generates positive externalities (lower crime, better governance, lower fertility)\n4. Enables structural transformation from agriculture to industry and services\n5. Returns to human capital are typically highest for primary education in developing countries\n\n**Challenges in Developing Countries:**\n1. **Quality crisis:** Many children attend school but learn little ('schooling without learning'). The World Bank's learning poverty indicator shows 53% of 10-year-olds in low/middle-income countries cannot read a simple text.\n2. **Brain drain:** Educated professionals emigrate to developed countries seeking better opportunities (doctors, engineers, IT professionals from South Asia and Africa).\n3. **Gender barriers:** Cultural norms, early marriage, and safety concerns prevent girls from accessing education.\n4. **Health burden:** Diseases like malaria, HIV/AIDS, and malnutrition deplete human capital.\n5. **Child labor:** Poverty forces children into work rather than school.\n6. **Financing constraints:** Governments have limited resources for education and health spending.",
      },
      {
        marks: 10,
        question: "Critically analyze the Human Development Index (HDI) as a measure of development. How does it improve upon GDP per capita? What are its limitations and how have they been addressed?",
        answer: "**Introduction:**\nThe HDI, created by Mahbub ul Haq and Amartya Sen in 1990, is a composite measure of development incorporating health, education, and income dimensions. It represents a paradigm shift from income-centric to people-centered development measurement.\n\n**How HDI Improves Upon GDP Per Capita:**\n\n1. **Multidimensionality:** While GDP captures only economic output, HDI adds health (life expectancy) and education (schooling years). This reflects the understanding that development is more than income.\n\n2. **Diminishing Returns to Income:** HDI uses the logarithm of GNI per capita, reflecting that each additional dollar matters more to a poor person than a rich one. This is more realistic than linear GDP comparisons.\n\n3. **Highlights Discrepancies:** Some countries with high GDP have relatively low HDI (e.g., oil-rich states with poor education/health), while others with modest income achieve high HDI (e.g., Cuba, Costa Rica, Kerala in India). This reveals that income alone doesn't determine well-being.\n\n4. **Policy Relevance:** HDI motivates governments to invest in health and education, not just pursue GDP growth. Bangladesh's remarkable human development progress despite moderate income growth illustrates this.\n\n5. **Cross-Country Comparison:** Provides a simple, transparent ranking that sparks national discussions about development priorities.\n\n**Limitations of HDI:**\n\n1. **Limited Dimensions:** Only three dimensions — ignores inequality, environmental sustainability, political freedom, security, gender, and cultural factors. A country could score well on HDI while being environmentally destructive or politically repressive.\n\n2. **Ignores Inequality:** National averages mask internal disparities. India's average HDI hides enormous differences between states (Kerala vs. Bihar) and social groups (caste, gender).\n\n3. **Quality Not Captured:** Years of schooling measures quantity, not quality. A country with 10 years of poor-quality education may score the same as one with 10 years of excellent education.\n\n4. **Arbitrary Weighting:** Equal weighting of three dimensions is a normative choice. There is no scientific reason why health should weigh equally with education or income.\n\n5. **Income Still Dominates:** Due to logarithmic transformation, income differences at low levels significantly affect HDI, meaning income still plays a dominant role for poor countries.\n\n6. **Static Snapshot:** HDI provides a snapshot at one point in time and may not capture dynamics, vulnerabilities, or sustainability of achievements.\n\n**How Limitations Have Been Addressed:**\n\n1. **Inequality-adjusted HDI (IHDI):** Introduced in 2010, it adjusts each dimension for inequality using the Atkinson index. The 'loss' in HDI due to inequality reveals the true distribution of human development.\n\n2. **Gender Development Index (GDI):** Calculates HDI separately for males and females, revealing gender gaps in human development.\n\n3. **Gender Inequality Index (GII):** Measures gender disadvantage in reproductive health (maternal mortality, adolescent fertility), empowerment (parliamentary seats, secondary education), and labor market participation.\n\n4. **Multidimensional Poverty Index (MPI):** Developed by Alkire and Foster, measures deprivation across 10 indicators in health, education, and living standards. Identifies who is poor, how, and the intensity of poverty.\n\n5. **Dashboard Approach:** The HDR now includes dashboards on quality of human development, life-course gender gap, and environmental sustainability, providing a more comprehensive picture.\n\n6. **Planetary Pressures-adjusted HDI (PHDI):** Introduced in 2020, adjusts HDI for a country's carbon dioxide emissions and material footprint, addressing environmental sustainability concerns.\n\n**Bangladesh Case Study:**\nBangladesh's HDI journey illustrates both the power and limitations of HDI:\n- HDI improved from 0.388 (1990) to ~0.670 (recent)\n- Life expectancy increased dramatically (56 to 73 years)\n- Gender parity in education achieved\n- However, HDI doesn't capture Bangladesh's vulnerability to climate change, governance challenges, or rising inequality\n\n**Conclusion:**\nThe HDI represents a significant conceptual advance over GDP per capita by incorporating health and education alongside income. However, its limitations necessitate complementary measures. The UNDP has progressively addressed these through IHDI, GII, MPI, and PHDI. Development assessment requires a dashboard of indicators rather than reliance on any single measure, no matter how comprehensive.",
      },
    ],
  },
  {
    id: 5,
    section: "B",
    title: "Industrialization",
    clos: "1, 2",
    topics: [
      {
        title: "Meaning and Necessity of Industrialization",
        content: `**Industrialization** is the process by which an economy transitions from primarily agricultural production to manufacturing and industrial production. It involves the development of factory-based production systems, adoption of new technologies, and structural transformation of the economy.

### Why Industrialization is Necessary

1. **Higher Productivity**: Manufacturing typically has higher labor productivity than agriculture, leading to higher wages and output per worker.

2. **Employment Generation**: Industry can absorb surplus labor from agriculture, reducing underemployment.

3. **Structural Transformation**: Moving from agriculture to industry is a hallmark of economic development (Lewis model).

4. **Terms of Trade**: Prebisch-Singer hypothesis suggests that primary commodity exporters face declining terms of trade relative to manufactured goods exporters.

5. **Technology Spillovers**: Industrial activity generates technological learning and innovation that benefit the entire economy.

6. **Urbanization and Modernization**: Industrialization drives urbanization, which can improve access to services and infrastructure.

7. **Export Diversification**: Reduces dependence on volatile primary commodity exports.

8. **Backward and Forward Linkages**: Industrial sectors create demand for inputs (backward) and supply outputs for other sectors (forward), multiplying economic activity.`,
      },
      {
        title: "Import-Substitution Industrialization (ISI)",
        content: `**Import-Substitution Industrialization (ISI)** is a trade and economic policy strategy that seeks to replace imports with domestic production.

### Key Features
1. **Trade barriers**: High tariffs and quotas on imported manufactured goods
2. **Overvalued exchange rates**: Makes imports cheaper for purchasing capital goods
3. **Government subsidies**: For domestic industries
4. **State-owned enterprises**: In key sectors
5. **Infant industry protection**: Temporary protection for new industries until they become competitive

### Theoretical Basis
- **Prebisch-Singer Hypothesis**: Terms of trade for primary commodities decline relative to manufactured goods
- **Infant Industry Argument**: New industries need protection to develop economies of scale
- **Dependency Theory**: Developing countries are exploited through unequal trade relationships

### Implementation
ISI was widely adopted in:
- **Latin America** (1950s-1970s): Brazil, Argentina, Mexico
- **South Asia** (1950s-1980s): India's License Raj
- **Africa** (post-independence 1960s)

### Advantages
1. Reduces dependence on imports
2. Creates industrial base and employment
3. Develops technological capabilities
4. Conserves foreign exchange
5. Strengthens economic sovereignty

### Problems and Failures
1. **Inefficiency**: Protected industries lacked competitive pressure
2. **Anti-export bias**: Overvalued currencies and inward focus discouraged exports
3. **Rent-seeking**: Protection created opportunities for corruption
4. **Capital-intensive**: Many ISI industries were capital-intensive, not labor-absorbing
5. **Limited market**: Small domestic markets limited economies of scale
6. **Foreign exchange crisis**: Still needed imports of capital goods and raw materials
7. **Fiscal burden**: Subsidizing inefficient state enterprises drained budgets`,
      },
      {
        title: "Export Promotion Industrialization",
        content: `**Export Promotion Industrialization (EPI)** is a strategy that emphasizes producing manufactured goods for export markets rather than for import replacement.

### Key Features
1. **Outward-oriented trade policies**: Low trade barriers, export incentives
2. **Competitive exchange rates**: Keeping currency undervalued to make exports cheaper
3. **Export processing zones (EPZs)**: Special zones with tax incentives for export-oriented firms
4. **Investment in human capital**: Education and skills for export industries
5. **Technology transfer**: Attracting FDI and licensing foreign technology

### Success Stories: East Asian Tigers
**South Korea, Taiwan, Hong Kong, Singapore** achieved remarkable growth through EPI:
- South Korea: From one of the poorest countries in 1960 to a high-income economy
- Heavy government involvement in directing investment and supporting exporters
- Emphasis on education and human capital
- Gradual upgrading from labor-intensive to technology-intensive exports

### Bangladesh's Garment Industry
A significant success story of export promotion:
- Ready-Made Garments (RMG) sector grew from virtually nothing in the 1980s to $42+ billion in exports
- Employs 4+ million workers (predominantly women)
- Bangladesh is the 2nd largest garment exporter globally
- Benefits: employment, women's empowerment, foreign exchange earnings

### Advantages
1. Exploits comparative advantage
2. Access to large international markets (overcomes small domestic market)
3. Competitive pressure drives efficiency and innovation
4. Earns foreign exchange
5. Technology transfer through FDI and buyer relationships

### Challenges
1. Vulnerability to global demand fluctuations
2. "Race to the bottom" in labor and environmental standards
3. Dependence on few export products/markets
4. Terms of trade may deteriorate for low-tech manufactures
5. Requires significant infrastructure and institutional capacity`,
      },
      {
        title: "Experience from Newly Industrialized Countries",
        content: `The **Newly Industrialized Countries (NICs)** provide important lessons for developing countries seeking to industrialize.

### East Asian NICs (First Wave)
**South Korea, Taiwan, Hong Kong, Singapore** — the "Four Tigers"

**Common Features:**
1. Strong state involvement in guiding industrial policy
2. Heavy investment in education and human capital
3. Outward-oriented trade strategy (but with selective protection)
4. High savings and investment rates (30-40% of GDP)
5. Land reform that reduced inequality and released labor for industry
6. Stable macroeconomic management
7. Export discipline — firms were rewarded for export performance

**South Korea's Industrial Policy:**
- Government-directed credit to strategic industries (chaebols like Samsung, Hyundai)
- Protection of infant industries with export performance requirements
- Heavy investment in R&D (now 4.5% of GDP)
- Gradual upgrading: textiles → steel → automobiles → electronics → semiconductors

### Second Wave NICs
**China, Vietnam, Thailand, Malaysia, Indonesia**

**China's Approach:**
- Gradual market reforms (since 1978) rather than "big bang"
- Special Economic Zones (Shenzhen, etc.)
- FDI attraction combined with technology transfer requirements
- Massive infrastructure investment
- Export-oriented manufacturing combined with domestic market growth

### Lessons for Developing Countries
1. No single model — each NIC adapted strategies to its context
2. State plays an active role but must be competent and avoid excessive intervention
3. Investment in human capital is non-negotiable
4. Openness to trade and technology is crucial but should be strategic
5. Macroeconomic stability is essential
6. Sequencing and gradual reform may be more effective than shock therapy`,
      },
      {
        title: "Debt, FDI, and Local Economic Development",
        content: `### External Debt in Developing Countries

**Types of Debt:**
- **Bilateral debt**: Owed to individual countries
- **Multilateral debt**: Owed to international organizations (World Bank, IMF)
- **Commercial debt**: Owed to private banks and bondholders

**The Debt Crisis:**
The 1980s debt crisis devastated many developing countries:
- Heavy borrowing in the 1970s (petrodollar recycling)
- Interest rate increases in the early 1980s made debt unsustainable
- Many countries spent more on debt service than on health and education
- Structural Adjustment Programs (SAPs) imposed austerity conditions

**HIPC Initiative**: The Heavily Indebted Poor Countries initiative provided debt relief to qualifying countries, conditional on implementing poverty reduction strategies.

### Foreign Direct Investment (FDI)

**Benefits of FDI:**
1. Capital inflow supplements domestic savings
2. Technology transfer and knowledge spillovers
3. Employment creation
4. Access to international markets
5. Management expertise and best practices

**Risks of FDI:**
1. Profit repatriation reduces net benefits
2. Environmental exploitation
3. Crowding out domestic firms
4. Transfer pricing to minimize tax
5. Political influence by multinational corporations
6. "Footloose" industries may relocate quickly

### Local Economic Development (LED)

LED is a participatory process where local communities work together to create conditions for economic growth and employment.

**Key Elements:**
1. Strengthening local institutions and governance
2. Developing local entrepreneurship and SMEs
3. Investing in local infrastructure
4. Skills development and training
5. Creating business-friendly local environment
6. Community-based natural resource management

**Examples:**
- Grameen Bank's microfinance model in Bangladesh
- Self-Help Groups in India
- Community-based tourism in Nepal and Costa Rica`,
      },
    ],
    videos: [
      {
        title: "Import Substitution vs Export Promotion",
        youtubeId: "m2dYiPKNHew",
        description: "Comparing ISI and EPI strategies with real-world examples.",
      },
      {
        title: "East Asian Miracle - How Tigers Industrialized",
        youtubeId: "u0fEKh2hEAQ",
        description: "The story of how East Asian economies achieved rapid industrialization.",
      },
      {
        title: "FDI and Development",
        youtubeId: "KjABYpflkX0",
        description: "The role of Foreign Direct Investment in economic development.",
      },
    ],
    materials: [
      {
        title: "World Bank Industrialization Reports",
        type: "article",
        url: "https://www.worldbank.org/en/topic/competitiveness",
        description: "World Bank resources on industrialization and competitiveness.",
      },
      {
        title: "UNIDO Industrial Development Reports",
        type: "article",
        url: "https://www.unido.org/resources-publications-flagship-publications",
        description: "United Nations Industrial Development Organization reports.",
      },
      {
        title: "Industrialization Strategies Lecture Notes",
        type: "notes",
        url: "https://www.google.com/search?q=industrialization+import+substitution+export+promotion+lecture+notes+PDF",
        description: "Detailed notes on ISI vs EPI strategies.",
      },
    ],
    questions: [
      {
        marks: 2,
        question: "Differentiate between Import-Substitution Industrialization and Export Promotion Industrialization.",
        answer: "**ISI** aims to replace imported manufactured goods with domestically produced ones through trade barriers (tariffs, quotas), subsidies, and infant industry protection. It is inward-looking. **EPI** focuses on producing manufactured goods for export markets through competitive exchange rates, export incentives, EPZs, and openness to FDI. It is outward-looking. ISI was dominant in Latin America and South Asia (1950s-80s) while EPI was successfully pursued by East Asian Tigers. ISI often led to inefficiency and fiscal burden, while EPI drove rapid growth in export-oriented economies.",
      },
      {
        marks: 5,
        question: "Discuss the experience of East Asian NICs in industrialization. What lessons can Bangladesh draw from their experience?",
        answer: "**East Asian NIC Experience:**\nSouth Korea, Taiwan, Singapore, and Hong Kong achieved rapid industrialization through:\n1. **Strategic state intervention** — governments directed credit, protected infant industries, and set export performance requirements\n2. **Heavy human capital investment** — universal education before industrialization created a skilled workforce\n3. **Outward orientation** — export-led growth with selective protection\n4. **High savings/investment** — 30-40% of GDP, financing rapid capital accumulation\n5. **Land reform** — reduced inequality and released labor for industry\n6. **Gradual industrial upgrading** — from textiles to electronics to technology\n\n**Lessons for Bangladesh:**\n1. **Diversify beyond garments** — Bangladesh's over-reliance on RMG (84% of exports) mirrors early-stage NIC economies; must upgrade to higher-value manufacturing\n2. **Invest massively in education quality** — not just enrollment but learning outcomes, technical skills, and STEM education\n3. **Improve infrastructure** — power supply, ports, logistics are critical bottlenecks\n4. **Strengthen institutions** — reduce corruption, improve governance, enforce contracts and property rights\n5. **Attract strategic FDI** — with technology transfer requirements, not just cheap labor\n6. **Develop domestic entrepreneurship** — support SMEs and innovation ecosystems\n7. **Maintain macroeconomic stability** — fiscal discipline and stable exchange rates",
      },
      {
        marks: 10,
        question: "Critically analyze the role of industrialization in economic development. Compare ISI and EPI strategies with examples and discuss which is more suitable for developing countries like Bangladesh.",
        answer: "**Introduction:**\nIndustrialization — the structural transformation from agriculture to manufacturing — is widely considered essential for sustained economic development. However, the strategy of industrialization matters as much as the decision to industrialize.\n\n**Role of Industrialization in Development:**\n1. **Productivity enhancement:** Manufacturing typically has higher labor productivity than agriculture, enabling higher wages and living standards.\n2. **Employment creation:** Industry can absorb surplus agricultural labor (Lewis model).\n3. **Technology and learning:** Industrial activity generates technological spillovers, skills development, and innovation.\n4. **Terms of trade:** Prebisch-Singer hypothesis suggests primary commodity exporters face declining terms of trade.\n5. **Linkages:** Manufacturing creates backward linkages (demand for inputs) and forward linkages (supply of intermediate goods).\n6. **Export diversification:** Reduces vulnerability to commodity price shocks.\n\n**Import-Substitution Industrialization (ISI):**\n\n*Strategy:* Replace imports with domestic production through tariffs, quotas, subsidies, and infant industry protection.\n\n*Successes:*\n- Built initial industrial base in many developing countries\n- Brazil's industrialization in the 1950s-70s created significant manufacturing capacity\n- India's heavy industry development (steel, machinery) under ISI\n\n*Failures:*\n- **Inefficiency:** Protected industries lacked competitive pressure — India's Ambassador car remained virtually unchanged for decades\n- **Rent-seeking:** Protection created opportunities for corruption (India's 'License Raj')\n- **Anti-export bias:** Overvalued exchange rates and inward focus discouraged exports\n- **Foreign exchange crisis:** Capital goods imports still required foreign exchange\n- **Limited scale:** Small domestic markets prevented economies of scale\n- **Latin America's lost decade (1980s):** ISI contributed to unsustainable debt and economic crisis\n\n**Export Promotion Industrialization (EPI):**\n\n*Strategy:* Produce manufactured goods for export through open trade policies, competitive exchange rates, and FDI attraction.\n\n*Successes:*\n- **East Asian Tigers:** South Korea, Taiwan, Singapore, Hong Kong achieved remarkable growth\n- South Korea: GDP per capita rose from $79 (1960) to $35,000+ through strategic export promotion\n- **China:** World's largest manufacturer through export-oriented strategy combined with domestic market development\n- **Bangladesh:** RMG exports grew from virtually zero to $42+ billion, creating 4+ million jobs\n\n*Challenges:*\n- Vulnerability to global demand fluctuations (2008 financial crisis impact)\n- 'Race to the bottom' in wages and environmental standards\n- Dependence on few products/markets\n- Requires significant infrastructure and institutional capacity\n\n**Comparative Analysis:**\n\n| Dimension | ISI | EPI |\n|-----------|-----|-----|\n| Market | Domestic | International |\n| Competition | Limited | High |\n| Efficiency | Low (protected) | High (competitive) |\n| Scale | Limited by domestic demand | Global market |\n| Employment | Often capital-intensive | Can be labor-intensive |\n| Foreign exchange | Saves (in theory) | Earns |\n| Technology | Limited incentive | Competitive pressure drives adoption |\n| Government role | Heavy regulation | Strategic facilitation |\n\n**Suitability for Bangladesh:**\n\nEPI is more suitable for Bangladesh for several reasons:\n\n1. **Proven success:** Bangladesh's garment sector demonstrates that EPI works in the country's context. The $42+ billion RMG export sector has created millions of jobs and empowered women.\n\n2. **Small domestic market:** Bangladesh's 170 million population, mostly low-income, limits the domestic market for ISI. Global markets are vastly larger.\n\n3. **Comparative advantage:** Bangladesh has abundant, relatively low-cost labor — a key advantage for labor-intensive manufacturing exports.\n\n4. **Global value chains:** Modern production is organized globally; participating in GVCs requires openness to trade and FDI.\n\n5. **However, strategic elements of ISI may be useful:**\n   - Temporary, targeted protection for emerging industries (pharmaceuticals, IT) with sunset clauses\n   - Support for domestic capacity in food security and essential goods\n   - Developing backward linkages for the garment sector (textiles, accessories)\n\n**Policy Recommendations for Bangladesh:**\n1. Diversify exports beyond garments (pharmaceuticals, IT, agro-processing, light engineering)\n2. Invest massively in education, skills, and infrastructure\n3. Attract FDI with technology transfer requirements\n4. Improve governance and reduce regulatory burden\n5. Develop special economic zones with world-class infrastructure\n6. Support SME development and entrepreneurship\n7. Implement selective, time-bound, performance-linked infant industry support\n\n**Conclusion:**\nNeither pure ISI nor pure EPI is optimal. The most successful industrializers (South Korea, China) used a pragmatic combination — open to trade and competition while strategically supporting emerging industries. Bangladesh should pursue an EPI-led strategy with selective industrial policy support, backed by massive investment in human capital and infrastructure.",
      },
    ],
  },
  {
    id: 6,
    section: "B",
    title: "Poverty",
    clos: "2, 3",
    topics: [
      {
        title: "Definition and Types of Poverty",
        content: `**Poverty** is a condition in which individuals or communities lack the financial resources and essentials for a minimum standard of living.

### Types of Poverty

**1. Absolute Poverty**
Living below a defined minimum income level (poverty line). The World Bank's international poverty line is **$2.15 per day** (2017 PPP).
- Represents the inability to meet basic needs: food, clothing, shelter
- Measurable and comparable across countries

**2. Relative Poverty**
Having significantly less income or resources than the average in a society.
- Defined relative to the median income (e.g., below 60% of median income in EU countries)
- Reflects social exclusion and inequality rather than absolute deprivation

**3. Chronic Poverty**
Poverty that persists over a long period (years or generations). People trapped in chronic poverty face structural barriers including lack of assets, discrimination, geographic isolation, and intergenerational transmission.

**4. Transient Poverty**
Temporary poverty due to shocks (natural disasters, illness, economic downturns). People may fall into poverty and recover.

**5. Urban vs. Rural Poverty**
- Rural poverty: Linked to landlessness, agricultural dependence, remoteness
- Urban poverty: Linked to informal employment, slum living, high cost of living

**6. Multidimensional Poverty**
Poverty measured across multiple dimensions beyond income: health, education, living standards, empowerment. Captured by the **Multidimensional Poverty Index (MPI)**.`,
      },
      {
        title: "Poverty Line in Bangladesh",
        content: `Bangladesh uses two main poverty lines:

### 1. Cost of Basic Needs (CBN) Method
The official method used by the **Bangladesh Bureau of Statistics (BBS)**:

**Upper Poverty Line (UPL):** Includes cost of food providing 2,122 kcal per person per day PLUS an allowance for non-food basic needs.

**Lower Poverty Line (LPL):** Includes only the cost of food providing 2,122 kcal per person per day (extreme poverty).

### Poverty Trends in Bangladesh
Bangladesh has made remarkable progress in poverty reduction:
- **2000:** 48.9% below upper poverty line
- **2005:** 40.0%
- **2010:** 31.5%
- **2016:** 24.3%
- **2022:** Estimated 18.7% (though COVID-19 caused temporary increases)

### Factors Behind Poverty Reduction
1. **Ready-Made Garment industry** — created millions of jobs, especially for women
2. **Microfinance** — Grameen Bank and BRAC provided credit to the poor
3. **Remittances** — Overseas workers' remittances boosted household incomes
4. **Agricultural growth** — Green Revolution technologies increased food production
5. **Social safety nets** — Government programs like VGD, VGF, Old Age Allowance
6. **NGO sector** — BRAC, ASA, and other NGOs provided services to the poor
7. **Women's empowerment** — Girls' education, family planning, and economic participation

### Remaining Challenges
1. **Extreme poverty** remains significant in certain regions (Rangpur, Mymensingh)
2. **Urban poverty** is growing with rapid urbanization
3. **Climate vulnerability** threatens progress (floods, cyclones, sea-level rise)
4. **Inequality** is increasing — Gini coefficient rose from 0.33 to 0.48
5. **COVID-19 impact** pushed millions back into poverty temporarily`,
      },
      {
        title: "Measuring Poverty: Head Count Index",
        content: `The **Head Count Index (H)** is the simplest and most widely used poverty measure.

### Formula
**H = q / n**

Where:
- q = number of people living below the poverty line
- n = total population
- H is expressed as a percentage

### Example
If a country has 170 million people and 30 million live below the poverty line:
H = 30/170 = 0.176 = **17.6%**

### Advantages
1. Simple to calculate and understand
2. Widely available and comparable across countries and time
3. Easy to communicate to policymakers and public

### Limitations
1. **Ignores depth of poverty**: Does not distinguish between someone just below the poverty line and someone far below it. A person earning $2.14/day and one earning $0.50/day are both counted equally.

2. **Ignores distribution among the poor**: Does not capture inequality among poor people.

3. **Policy insensitivity**: If a transfer moves someone from just below the poverty line to just above it, H decreases. But if a transfer helps the poorest of the poor without crossing the line, H is unchanged — creating perverse incentives.

4. **Binary classification**: People are classified as either poor or non-poor, ignoring the vulnerability of those just above the poverty line.`,
      },
      {
        title: "Foster-Greer-Thorbecke (FGT) Poverty Index",
        content: `The **FGT Index** (1984) is a family of poverty measures that addresses the limitations of the Head Count Index.

### Formula
**FGT(α) = (1/n) × Σ[(z - yᵢ)/z]^α** for all i where yᵢ < z

Where:
- n = total population
- z = poverty line
- yᵢ = income of person i
- α = poverty aversion parameter
- Sum is over all individuals below the poverty line

### Three Key Measures

**When α = 0: Head Count Index (H)**
- FGT(0) = q/n
- Simply counts the proportion below the poverty line

**When α = 1: Poverty Gap Index (PG)**
- FGT(1) = average distance below the poverty line (as a fraction of the poverty line)
- Measures the **depth** of poverty
- Represents the minimum cost of eliminating poverty through perfectly targeted transfers
- Example: If PG = 0.05, it would cost 5% of the poverty line × total population to eliminate poverty through perfect targeting

**When α = 2: Squared Poverty Gap (SPG)**
- FGT(2) = gives greater weight to those furthest below the poverty line
- Measures the **severity** of poverty
- Sensitive to inequality among the poor
- Squaring the poverty gap means that the poorest individuals contribute disproportionately

### Numerical Example
Poverty line z = $100/month
Three individuals with incomes: $80, $60, $40

**Head Count (α=0):** H = 3/3 = 1.0 (100% are poor)

**Poverty Gap (α=1):**
PG = (1/3) × [(100-80)/100 + (100-60)/100 + (100-40)/100]
= (1/3) × [0.20 + 0.40 + 0.60] = (1/3) × 1.20 = **0.40**

**Squared Poverty Gap (α=2):**
SPG = (1/3) × [(0.20)² + (0.40)² + (0.60)²]
= (1/3) × [0.04 + 0.16 + 0.36] = (1/3) × 0.56 = **0.187**

### Advantages of FGT
1. Captures depth and severity of poverty (not just incidence)
2. Decomposable — can be calculated for subgroups and aggregated
3. Satisfies important axioms: monotonicity, transfer principle (for α ≥ 1)
4. Policy-relevant — helps design targeted anti-poverty programs`,
      },
      {
        title: "Multidimensional Poverty Index (MPI)",
        content: `The **Multidimensional Poverty Index (MPI)** was developed by **Sabina Alkire** and **James Foster** (2010) and is published by UNDP and OPHI.

### Structure
The MPI uses **three dimensions** and **ten indicators**:

**1. Health (1/3 weight)**
- Nutrition (1/6)
- Child mortality (1/6)

**2. Education (1/3 weight)**
- Years of schooling (1/6)
- School attendance (1/6)

**3. Living Standards (1/3 weight)**
- Cooking fuel (1/18)
- Sanitation (1/18)
- Drinking water (1/18)
- Electricity (1/18)
- Housing (1/18)
- Assets (1/18)

### Methodology (Alkire-Foster Method)

**Step 1: Identification**
A person is considered deprived in each indicator based on specific cutoffs (e.g., no household member has completed 6 years of schooling).

**Step 2: Deprivation Score**
Each person receives a weighted deprivation score (0 to 1). A person is MPI-poor if their deprivation score ≥ 1/3 (deprived in at least one-third of weighted indicators).

**Step 3: Aggregation**
- **Incidence (H)**: Proportion of people who are MPI-poor
- **Intensity (A)**: Average deprivation score among the MPI-poor
- **MPI = H × A**

### Advantages
1. Goes beyond income to capture lived experience of poverty
2. Identifies who is poor and how (which deprivations)
3. Can be decomposed by region, group, and indicator
4. Useful for policy targeting — identifies which deprivations to address
5. Complements income poverty measures

### Bangladesh MPI
Bangladesh has made significant progress in reducing multidimensional poverty:
- MPI has declined significantly over the past two decades
- Major improvements in education enrollment and child mortality
- Living standards indicators (electricity, sanitation) have improved
- Remaining challenges: nutrition, cooking fuel, housing quality`,
      },
    ],
    videos: [
      {
        title: "Understanding Poverty - Types and Measurement",
        youtubeId: "D9N7QaIOkG8",
        description: "Comprehensive overview of poverty concepts and measurement methods.",
      },
      {
        title: "FGT Poverty Index Explained",
        youtubeId: "IOAhUz7MHYA",
        description: "Detailed explanation of the Foster-Greer-Thorbecke poverty measures.",
      },
      {
        title: "Multidimensional Poverty Index",
        youtubeId: "1ROslbZyT-M",
        description: "How the MPI captures poverty beyond income.",
      },
    ],
    materials: [
      {
        title: "OPHI - Multidimensional Poverty Index",
        type: "article",
        url: "https://ophi.org.uk/multidimensional-poverty-index/",
        description: "Oxford Poverty and Human Development Initiative's MPI resources.",
      },
      {
        title: "World Bank Poverty Data",
        type: "article",
        url: "https://www.worldbank.org/en/topic/poverty",
        description: "World Bank's comprehensive poverty data and research.",
      },
      {
        title: "Bangladesh Bureau of Statistics - HIES",
        type: "notes",
        url: "https://www.google.com/search?q=Bangladesh+Bureau+Statistics+HIES+poverty+report+PDF",
        description: "Official Bangladesh poverty statistics from household surveys.",
      },
    ],
    questions: [
      {
        marks: 2,
        question: "What is the Head Count Index? What are its limitations?",
        answer: "The Head Count Index (H) is the proportion of the population living below the poverty line: H = q/n, where q is the number of poor and n is total population. **Limitations:** (1) It ignores the **depth** of poverty — doesn't distinguish between someone barely below and far below the poverty line; (2) It ignores the **distribution** among the poor; (3) It is **policy insensitive** — helping the poorest without crossing the line doesn't change H; (4) It creates a binary poor/non-poor classification, ignoring vulnerability.",
      },
      {
        marks: 5,
        question: "Explain the Foster-Greer-Thorbecke (FGT) poverty index with numerical examples. Why is it considered superior to the Head Count Index?",
        answer: "The FGT index is: **FGT(α) = (1/n) Σ[(z-yᵢ)/z]^α** for yᵢ < z.\n\n**Three measures:**\n- **α=0 (Head Count):** Simply counts proportion of poor\n- **α=1 (Poverty Gap):** Measures average depth of poverty below the line\n- **α=2 (Squared Poverty Gap):** Measures severity, giving more weight to the poorest\n\n**Example:** Poverty line = $100. Three people earn $80, $60, $40.\n- H = 3/3 = 1.0 (100% poor)\n- PG = (1/3)[(20/100)+(40/100)+(60/100)] = 0.40\n- SPG = (1/3)[(0.2)²+(0.4)²+(0.6)²] = 0.187\n\n**Superiority over Head Count:**\n1. **Depth (α=1):** PG shows that on average, poor people are 40% below the poverty line — information H doesn't provide\n2. **Severity (α=2):** SPG penalizes deeper poverty more — the person earning $40 contributes more than the one earning $80\n3. **Policy relevance:** PG tells us the minimum cost of poverty elimination; SPG guides resources to the poorest\n4. **Decomposable:** Can be calculated for subgroups (rural/urban, regions) and aggregated\n5. **Satisfies axioms:** Monotonicity (if a poor person becomes poorer, the index increases) and transfer (transfers from poorer to less poor increase the index for α≥2)",
      },
      {
        marks: 10,
        question: "Analyze the poverty situation in Bangladesh. What are the causes of poverty and what policies has Bangladesh adopted for poverty reduction? Critically evaluate their effectiveness.",
        answer: "**Introduction:**\nBangladesh has achieved remarkable poverty reduction — from nearly 49% in 2000 to approximately 18.7% in 2022. However, significant challenges remain.\n\n**Poverty Profile:**\n- Upper poverty line: 18.7% (2022 estimate)\n- Extreme poverty: approximately 5.6%\n- Significant regional variation: Rangpur, Mymensingh, Barisal divisions have higher poverty\n- Urban-rural divide: Rural poverty higher but urban poverty growing\n- MPI shows improvements but nutrition and living standards remain concerning\n\n**Causes of Poverty:**\n\n**Structural Causes:**\n1. **Landlessness:** 50%+ of rural households are functionally landless\n2. **Low agricultural productivity:** Small farm sizes, fragmentation, limited technology\n3. **Population density:** 1,200+ people per sq km strains resources\n4. **Limited industrialization:** Economy still dependent on single sector (garments)\n5. **Weak institutions:** Corruption, poor governance, inefficient bureaucracy\n\n**Individual/Household Causes:**\n6. **Low human capital:** Limited education quality and health services\n7. **Large family size:** High dependency ratios\n8. **Gender discrimination:** Women face barriers to economic participation\n9. **Vulnerability to shocks:** Natural disasters (floods, cyclones), illness\n\n**External Causes:**\n10. **Climate change:** Bangladesh is one of the most climate-vulnerable countries\n11. **Global economic shocks:** COVID-19 pandemic reversed some poverty gains\n12. **Terms of trade:** Dependence on garment exports and raw material imports\n\n**Poverty Reduction Policies:**\n\n**1. Garment Industry Development:**\n- Created 4+ million jobs, predominantly for women\n- Largest source of export earnings ($42+ billion)\n- *Effectiveness:* Highly effective in creating employment and empowering women. However, working conditions, wages, and safety remain concerns (Rana Plaza disaster 2013).\n\n**2. Microfinance:**\n- Grameen Bank, BRAC, ASA provide credit to the poor (mainly women)\n- Over 30 million active borrowers\n- *Effectiveness:* Evidence is mixed. Microfinance helps with consumption smoothing and small enterprise development but rarely transforms poor households into middle class. Over-indebtedness is a growing concern.\n\n**3. Social Safety Nets:**\n- Programs: VGD (Vulnerable Group Development), VGF (Vulnerable Group Feeding), Old Age Allowance, Widow Allowance, Freedom Fighter Allowance\n- Approximately 13% of GDP spent on social protection\n- *Effectiveness:* Coverage is limited (many deserving households excluded), targeting is imperfect (political influence in selection), benefit levels are low, and fragmentation across multiple programs reduces efficiency.\n\n**4. Education Programs:**\n- Female Secondary School Assistance Program (FSSAP) — stipends for girls\n- Primary Education Stipend Program\n- Achieved near-universal primary enrollment and gender parity\n- *Effectiveness:* Enrollment has improved dramatically, but learning outcomes remain poor. Many children complete primary school without basic literacy and numeracy skills.\n\n**5. Agricultural Development:**\n- Subsidized fertilizer and seeds\n- Expansion of irrigation\n- Agricultural research and extension\n- *Effectiveness:* Food production has tripled since independence, achieving near self-sufficiency in rice. However, crop diversification is limited and climate change threatens gains.\n\n**6. Remittance Facilitation:**\n- Over 10 million Bangladeshi workers abroad\n- Remittances exceed $20 billion annually\n- *Effectiveness:* Significant poverty-reducing impact, but dependence on volatile migration policies of host countries. Brain drain concerns.\n\n**7. NGO Sector:**\n- BRAC (world's largest NGO) provides education, health, microfinance, enterprise development\n- Thousands of local and international NGOs operate in Bangladesh\n- *Effectiveness:* NGOs have filled significant gaps in service delivery but raise questions about accountability, sustainability, and donor dependence.\n\n**Critical Evaluation:**\n\n**Successes:**\n- Poverty reduced from 49% to under 20% in two decades\n- Life expectancy increased from 59 to 73 years\n- Under-5 mortality reduced by two-thirds\n- Primary education near-universal\n- Women's empowerment improved significantly\n\n**Remaining Challenges:**\n1. **Rising inequality:** Gini coefficient increased from 0.33 to 0.48 — growth has not been equally shared\n2. **Vulnerable non-poor:** Millions just above the poverty line are vulnerable to falling back\n3. **Climate vulnerability:** Floods, cyclones, and sea-level rise threaten 30+ million people\n4. **Quality of services:** Education and health quality remain poor despite expanded access\n5. **Governance deficit:** Corruption and political instability undermine development gains\n6. **Structural transformation:** Over-reliance on garments; need to diversify economy\n7. **Urban poverty:** Rapid urbanization creating new pockets of urban poverty and slums\n\n**Conclusion:**\nBangladesh's poverty reduction is a remarkable development success story, driven by garment exports, microfinance, remittances, and social programs. However, rising inequality, climate vulnerability, governance challenges, and the need for economic diversification require renewed policy attention. Future strategies must focus on inclusive growth, climate resilience, education quality, and institutional strengthening to sustain and deepen poverty reduction.",
      },
    ],
  },
  {
    id: 7,
    section: "B",
    title: "Inequality",
    clos: "3",
    topics: [
      {
        title: "Meaning of Inequality",
        content: `**Inequality** refers to the unequal distribution of income, wealth, opportunities, or other valued resources among individuals or groups in a society.

### Types of Inequality

**1. Income Inequality**
Unequal distribution of income among individuals or households. Measured by Gini coefficient, income shares, and percentile ratios.

**2. Wealth Inequality**
Unequal distribution of assets (land, property, financial assets). Typically more extreme than income inequality — the top 1% often owns more than the bottom 50%.

**3. Consumption Inequality**
Differences in consumption levels. Often considered a better measure of well-being than income as it reflects actual living standards.

**4. Opportunity Inequality**
Unequal access to education, healthcare, employment, and social mobility based on birth circumstances (family income, gender, ethnicity, location).

**5. Gender Inequality**
Systemic differences in outcomes and opportunities between men and women in education, employment, political participation, and health.

**6. Spatial Inequality**
Differences between regions, urban-rural areas, and neighborhoods within a country.

### Why Inequality Matters for Development
1. **Poverty reduction**: High inequality means growth benefits fewer people
2. **Social cohesion**: Extreme inequality can lead to social unrest and conflict
3. **Economic efficiency**: Inequality can reduce aggregate demand and growth
4. **Political capture**: The wealthy may influence policies in their favor
5. **Intergenerational mobility**: Inequality reduces social mobility
6. **Health outcomes**: More unequal societies have worse health outcomes (Wilkinson & Pickett)`,
      },
      {
        title: "Measuring Inequality: Gini Coefficient",
        content: `The **Gini Coefficient** (developed by Corrado Gini in 1912) is the most widely used measure of inequality.

### Definition
The Gini coefficient measures the extent to which the distribution of income (or consumption) deviates from a perfectly equal distribution.

### Range
- **0 = Perfect equality** (everyone has exactly the same income)
- **1 = Perfect inequality** (one person has all the income)
- In practice, most countries fall between 0.25 and 0.65

### Calculation
The Gini coefficient is calculated from the **Lorenz Curve**:

**Gini = A / (A + B)**

Where:
- A = area between the line of perfect equality and the Lorenz Curve
- B = area below the Lorenz Curve
- A + B = total area under the line of equality (= 0.5)
- So Gini = 2A = 1 – 2B

### Alternative Formula
For discrete data:
**Gini = (2Σᵢ i·yᵢ) / (n·Σᵢ yᵢ) – (n+1)/n**

Where yᵢ are incomes sorted in ascending order.

### Global Gini Values (Approximate)
- **Low inequality**: Denmark (0.28), Sweden (0.29), Norway (0.27)
- **Moderate inequality**: India (0.35), Bangladesh (0.48), USA (0.39)
- **High inequality**: Brazil (0.53), South Africa (0.63), Colombia (0.54)

### Advantages
1. Single summary number for inequality
2. Comparable across countries and over time
3. Scale-independent (not affected by currency units)
4. Widely available and well-understood

### Limitations
1. **Same Gini, different distributions**: Two very different inequality patterns can produce the same Gini
2. **Insensitive to extremes**: Less sensitive to changes at the very top or bottom
3. **No decomposition by source**: Cannot identify what causes inequality
4. **Mean-dependent**: Doesn't account for absolute income levels`,
      },
      {
        title: "Lorenz Curve",
        content: `The **Lorenz Curve** (Max O. Lorenz, 1905) is a graphical representation of income or wealth distribution.

### Construction
- **X-axis**: Cumulative percentage of population (from poorest to richest)
- **Y-axis**: Cumulative percentage of income received
- **Line of perfect equality**: 45° diagonal line where x% of population receives x% of income

### Interpretation
- The further the Lorenz Curve bows below the line of equality, the greater the inequality
- The curve always starts at (0,0) and ends at (100,100)
- A perfectly equal distribution would be the 45° line itself

### Example
| % of Population | % of Income | Cumulative % Pop | Cumulative % Income |
|-----------------|-------------|------------------|---------------------|
| Poorest 20% | 5% | 20% | 5% |
| Next 20% | 10% | 40% | 15% |
| Next 20% | 15% | 60% | 30% |
| Next 20% | 25% | 80% | 55% |
| Richest 20% | 45% | 100% | 100% |

This shows that the poorest 20% receive only 5% of income, while the richest 20% receive 45%.

### Uses
1. Visual comparison of inequality across countries or over time
2. Basis for calculating the Gini coefficient
3. Identifying which segment of the population is most disadvantaged
4. Evaluating the impact of redistribution policies

### Lorenz Dominance
If one Lorenz Curve lies entirely within (closer to equality than) another, the first distribution is unambiguously more equal. When curves cross, the comparison is ambiguous and requires additional measures.`,
      },
      {
        title: "Kuznets's Inverted-U Hypothesis",
        content: `**Simon Kuznets** (1955) proposed that the relationship between economic development and income inequality follows an **inverted-U shape**: inequality first increases with development, then decreases after a turning point.

### The Hypothesis

**Early stages of development**: Inequality increases as:
1. Workers move from low-income agriculture to higher-income industry (structural transformation)
2. Urban-rural income gap widens
3. Returns to capital increase faster than wages
4. Education premium creates wage differentials
5. Regional disparities emerge

**Later stages of development**: Inequality decreases as:
1. More workers shift to the industrial/service sector
2. Education becomes more widespread, reducing skill premium
3. Democratic institutions strengthen and demand redistribution
4. Social safety nets expand
5. Progressive taxation is implemented
6. Urbanization reduces urban-rural gap

### Empirical Evidence

**Supporting evidence:**
- Cross-country data from the 1950s-60s showed the inverted-U pattern
- Countries like South Korea and Taiwan experienced rising then falling inequality
- Historical data from industrialized countries (UK, US) shows the pattern over long periods

**Against the hypothesis:**
- Many developing countries have experienced growth without the expected decline in inequality
- Latin American countries remained highly unequal despite growth
- East Asian Tigers reduced inequality during early growth (contradicting the rising phase)
- The relationship may be historically specific rather than universal
- Inequality in developed countries has been rising since the 1980s (US, UK), contradicting the declining phase

### Policy Implications

**1. Active interpretation:**
Growth will eventually reduce inequality — no policy intervention needed (let the market work).

**2. Critical interpretation:**
The Kuznets curve is not automatic. Active policies (progressive taxation, education, social protection) are needed to ensure inequality declines with growth. Waiting for inequality to "naturally" decline risks social unrest and inefficient resource allocation.

**3. Modern view:**
There is no iron law linking growth and inequality. Policy choices, institutions, and structural factors determine whether growth reduces or increases inequality. Countries like Brazil have reduced inequality through deliberate policy (Bolsa Família, minimum wage increases) even during growth.

### Criticisms
1. **Cross-country vs. time-series**: The pattern observed across countries may not hold for individual countries over time
2. **Omitted variables**: Many factors other than income level affect inequality
3. **Historical specificity**: The pattern reflected specific conditions of early industrialization, not a universal law
4. **Policy matters more**: Inequality trends depend more on policy choices than on development level
5. **Re-rising inequality**: The recent increase in inequality in developed countries challenges the "declining" phase`,
      },
    ],
    videos: [
      {
        title: "Gini Coefficient and Lorenz Curve Explained",
        youtubeId: "y8y-gaNbe4U",
        description: "Visual explanation of how to measure inequality using the Gini coefficient and Lorenz Curve.",
      },
      {
        title: "Kuznets Curve - Income Inequality and Growth",
        youtubeId: "gGEEBMdqaOo",
        description: "Understanding Kuznets's inverted-U hypothesis with examples.",
      },
      {
        title: "Global Inequality Explained",
        youtubeId: "QPKKQnijnsM",
        description: "Overview of global inequality trends and their causes.",
      },
    ],
    materials: [
      {
        title: "World Inequality Report",
        type: "article",
        url: "https://wir2022.wid.world/",
        description: "Comprehensive global report on wealth and income inequality.",
      },
      {
        title: "Inequality Measurement Lecture Notes",
        type: "notes",
        url: "https://www.google.com/search?q=gini+coefficient+lorenz+curve+kuznets+lecture+notes+PDF",
        description: "Detailed notes on inequality measurement tools and theories.",
      },
      {
        title: "World Bank Inequality Data (PovcalNet)",
        type: "article",
        url: "https://pip.worldbank.org/",
        description: "World Bank's Poverty and Inequality Platform with country data.",
      },
    ],
    questions: [
      {
        marks: 2,
        question: "What is the Gini coefficient? What do values of 0 and 1 represent?",
        answer: "The **Gini coefficient** is a statistical measure of income or wealth inequality ranging from 0 to 1. **A value of 0** represents **perfect equality** — everyone in the society has exactly the same income. **A value of 1** represents **perfect inequality** — one person has all the income and everyone else has nothing. In practice, most countries fall between 0.25 (Scandinavian countries) and 0.63 (South Africa). It is calculated from the Lorenz Curve as the ratio of the area between the equality line and the Lorenz Curve to the total area under the equality line.",
      },
      {
        marks: 5,
        question: "Explain the Lorenz Curve and show how the Gini coefficient is derived from it. Use a numerical example.",
        answer: "The **Lorenz Curve** is a graphical representation of income distribution. The X-axis shows cumulative percentage of population (poorest to richest) and the Y-axis shows cumulative percentage of income.\n\n**Construction Example:**\n| Population Quintile | % Income | Cum. Pop | Cum. Income |\n|---|---|---|---|\n| Poorest 20% | 4% | 20% | 4% |\n| 2nd 20% | 8% | 40% | 12% |\n| 3rd 20% | 16% | 60% | 28% |\n| 4th 20% | 22% | 80% | 50% |\n| Richest 20% | 50% | 100% | 100% |\n\nPlotting these points and connecting them gives the Lorenz Curve, which bows below the 45° **line of perfect equality**.\n\n**Deriving Gini:**\n- **Area A** = area between the equality line and the Lorenz Curve\n- **Area B** = area below the Lorenz Curve\n- **Gini = A / (A + B)** where A + B = 0.5 (total area under the 45° line)\n- So Gini = 2A = 1 – 2B\n\nIn this example, using the trapezoidal rule to calculate area B:\nB = 0.5 × 0.2 × [0 + 2(0.04) + 2(0.12) + 2(0.28) + 2(0.50) + 1.00] = approximately 0.281\nGini = 1 – 2(0.281) = **0.438**\n\nThis indicates moderate-to-high inequality.",
      },
      {
        marks: 10,
        question: "Critically evaluate Kuznets's Inverted-U hypothesis. Is it relevant for understanding inequality in developing countries today? Support with evidence.",
        answer: "**Introduction:**\nSimon Kuznets (1955) hypothesized that income inequality follows an inverted-U pattern over the course of economic development — first rising, then falling after a turning point. This influential hypothesis has shaped development policy debates for decades.\n\n**The Hypothesis Explained:**\n\n**Rising Phase:** During early industrialization, inequality increases because:\n1. Structural transformation moves workers from low-income agriculture to higher-income industry, creating a dual economy\n2. Urban-rural income gaps widen\n3. Returns to capital and skilled labor increase\n4. Education creates wage differentials between educated and uneducated\n5. Industrial concentration benefits capital owners disproportionately\n\n**Turning Point and Decline:** As development matures, inequality decreases because:\n1. Agricultural surplus labor is absorbed; rural wages rise\n2. Universal education reduces skill premium\n3. Democratic pressure leads to redistribution policies\n4. Social safety nets expand\n5. Progressive taxation is implemented\n\n**Empirical Evidence:**\n\n**Supporting Evidence:**\n- Kuznets used historical data from the US, UK, and Germany showing inequality rising then falling\n- Cross-country data from the 1960s-70s showed middle-income countries were more unequal than low or high-income ones\n- South Korea and Taiwan experienced rising then declining inequality during rapid growth\n- Historical analysis of industrialization in Western Europe broadly supports the pattern\n\n**Contradicting Evidence:**\n\n1. **Latin American Persistence:** Countries like Brazil and Mexico maintained high inequality for decades despite sustained growth, contradicting the automatic decline. Brazil's Gini remained above 0.55 for 40+ years.\n\n2. **East Asian Exception:** South Korea, Taiwan, and Japan reduced inequality during early industrialization — contradicting the rising phase. Land reform, education investment, and deliberate policy drove equality alongside growth.\n\n3. **Rising Inequality in Developed Countries:** Since the 1980s, inequality has increased in the US (Gini from 0.35 to 0.41), UK, and other developed nations — contradicting the declining phase. Factors include globalization, technological change, weakened unions, and tax policy.\n\n4. **China's Experience:** China's Gini coefficient rose from 0.28 (1981) to 0.49 (2008), with recent modest declines. The pattern doesn't neatly fit the Kuznets curve.\n\n5. **African Countries:** Many African nations have experienced growth without significant inequality reduction.\n\n**Critical Evaluation:**\n\n**Methodological Issues:**\n1. **Cross-section vs. time-series:** Kuznets inferred a dynamic pattern from cross-country snapshot data — an ecological fallacy\n2. **Omitted variables:** Income level is not the only determinant of inequality; institutions, policies, historical legacies, and globalization matter\n3. **Measurement problems:** Inequality data from the 1950s-60s was sparse and unreliable\n\n**Theoretical Issues:**\n4. **No automatic mechanism:** There is no inherent economic law that forces inequality to decline with development\n5. **Policy matters more than income level:** Countries at similar income levels have vastly different inequality (US vs. Denmark)\n6. **Historical specificity:** The conditions of 19th-20th century industrialization (labor movements, world wars, expansion of suffrage) that drove inequality reduction are not automatically replicated\n\n**Relevance for Developing Countries Today:**\n\n**Partially Relevant:**\n- The structural transformation mechanism (agriculture to industry) does create temporary inequality pressures\n- Urbanization and education differentials do initially widen gaps\n- These insights remain useful for understanding inequality dynamics\n\n**Largely Misleading if Taken as Policy Guidance:**\n1. **Waiting for the turning point is dangerous:** High inequality can become entrenched through political capture, institutional rigidity, and intergenerational transmission\n2. **Active policy is essential:** Countries that reduced inequality (Brazil's Bolsa Família, Korea's land reform, Nordic welfare states) did so through deliberate policy, not automatic market forces\n3. **Globalization changes the dynamics:** In today's globalized economy, technological change and global competition can increase inequality at any development stage\n4. **Inequality harms growth:** IMF research shows that high inequality actually reduces the duration of growth spells — undermining the premise that growth will eventually reduce inequality\n\n**Bangladesh Context:**\n- Bangladesh's Gini has risen from 0.33 to 0.48 during its growth period, consistent with the rising phase\n- However, there is no guarantee of an automatic decline\n- Active policies needed: progressive taxation, improved social protection, quality education access, land reform\n\n**Conclusion:**\nThe Kuznets hypothesis provides a useful framework for understanding inequality dynamics during structural transformation but should not be interpreted as a natural law. The empirical evidence is mixed, and modern experiences show that policy choices, institutions, and global factors matter more than income level in determining inequality outcomes. Developing countries should not passively wait for inequality to decline but actively implement redistributive policies while pursuing growth.",
      },
    ],
  },
  {
    id: 8,
    section: "B",
    title: "Institutions",
    clos: "4",
    topics: [
      {
        title: "Evolution of Institutions",
        content: `**Institutions** are the formal and informal rules, norms, and enforcement mechanisms that structure human interaction and economic activity. **Douglass North** (Nobel Prize 1993) defined institutions as "the rules of the game in a society."

### Types of Institutions

**Formal Institutions:**
- Constitutions and laws
- Property rights systems
- Contract enforcement mechanisms
- Regulatory frameworks
- Electoral systems
- Judicial systems

**Informal Institutions:**
- Social norms and customs
- Cultural values and traditions
- Trust and social capital
- Religious practices
- Unwritten codes of conduct

### Historical Evolution

**1. Pre-State Institutions**
- Kinship-based governance
- Customary law and traditional authority
- Community-based resource management
- Religious institutions providing social order

**2. Colonial Institutions**
- European colonizers established extractive institutions in many developing countries
- **Acemoglu, Johnson, Robinson (2001)** showed that colonial institutions persist and determine current economic performance
- **Extractive institutions**: Designed to extract resources (mining, plantation agriculture) — concentrated power, weak property rights
- **Inclusive institutions**: Where settlers established (US, Canada, Australia) — broad property rights, democratic governance

**3. Post-Colonial Institutional Development**
- Many developing countries inherited extractive institutional structures
- State-building challenges: creating effective governance from colonial frameworks
- Institutional quality varies enormously across developing countries

**4. Modern Institutional Reform**
- Good governance agenda (World Bank, 1990s onward)
- Decentralization and local governance
- Anti-corruption initiatives
- Rule of law programs
- Institutional transplantation vs. organic evolution debate`,
      },
      {
        title: "Implications for Development",
        content: `Institutional quality is now widely recognized as a fundamental determinant of economic development.

### Why Institutions Matter

**1. Investment Climate**
- Secure property rights encourage investment — why invest if assets can be confiscated?
- Contract enforcement enables complex economic transactions
- Predictable regulations reduce business uncertainty

**2. Transaction Costs**
- Good institutions reduce the costs of doing business
- Trust and rule of law lower the need for expensive enforcement mechanisms
- Poor institutions increase corruption, red tape, and uncertainty

**3. Innovation and Entrepreneurship**
- Intellectual property protection encourages innovation
- Ease of starting and operating businesses affects entrepreneurial activity
- Access to finance depends on institutional frameworks (banking regulation, credit information)

**4. Public Goods Provision**
- Effective government provides essential public goods: infrastructure, education, health, security
- Tax systems require institutional capacity to collect revenue
- Weak institutions lead to underinvestment in public goods

### Evidence

**Acemoglu & Robinson** ("Why Nations Fail," 2012):
- Countries with **inclusive institutions** (broad participation, secure property rights, pluralistic political systems) prosper
- Countries with **extractive institutions** (narrow elite control, weak property rights, concentrated political power) stagnate
- Example: North Korea vs. South Korea — same geography, culture, history, but vastly different institutions leading to vastly different outcomes

**World Bank Governance Indicators:**
Six dimensions of governance:
1. Voice and Accountability
2. Political Stability
3. Government Effectiveness
4. Regulatory Quality
5. Rule of Law
6. Control of Corruption`,
      },
      {
        title: "Land Ownership Institutions",
        content: `Land ownership institutions are particularly important in developing countries where agriculture remains a major sector and land is the primary asset for many households.

### Types of Land Tenure Systems

**1. Private Ownership (Freehold)**
- Individual ownership with full rights to use, transfer, and mortgage
- Provides strongest incentives for investment and improvement
- Requires effective registration and enforcement systems

**2. Communal/Customary Tenure**
- Land held collectively by community or clan
- Access governed by traditional rules and authorities
- Common in Sub-Saharan Africa and indigenous communities
- May provide security within the community but limits transferability

**3. State Ownership**
- Government owns all land; individuals have use rights
- Common in socialist/post-socialist countries
- Can enable equitable distribution but may reduce incentives

**4. Sharecropping and Tenancy**
- Landless farmers cultivate others' land for a share of the harvest
- Can be exploitative if landlords have excessive bargaining power
- Marshallian inefficiency: sharecroppers invest less than owner-cultivators

### Land Reform
**Redistributive land reform** — transferring land from large landowners to the landless — has been a major development policy:

**Successful Cases:**
- **South Korea and Taiwan (1950s):** Comprehensive land reform created small-owner agriculture, reduced inequality, and freed labor for industry
- **China (1978):** Household Responsibility System gave farmers control over land use, dramatically increasing agricultural productivity

**Less Successful Cases:**
- **Zimbabwe (2000s):** Chaotic land seizures reduced agricultural output
- **Bangladesh:** Land reform legislation exists but implementation has been weak due to political power of landlords`,
      },
      {
        title: "Entrepreneurship and Innovation",
        content: `### Entrepreneurship in Development

**Entrepreneurship** is the process of creating new business ventures, introducing innovations, and taking risks in pursuit of profit. It is increasingly recognized as a key driver of economic development.

### Types of Entrepreneurship in Developing Countries

**1. Necessity Entrepreneurship**
- Driven by lack of other employment options
- Common in the informal sector (street vendors, small traders)
- Low productivity, limited growth potential
- Represents survival rather than opportunity

**2. Opportunity Entrepreneurship**
- Driven by identification of market opportunities
- Higher growth potential and innovation content
- Creates employment for others
- Contributes to structural transformation

### Institutional Barriers to Entrepreneurship
1. **Regulatory burden**: Complex procedures, long processing times
2. **Access to finance**: Weak banking systems, lack of collateral requirements favor the wealthy
3. **Corruption**: Bribes increase costs and create uncertainty
4. **Weak property rights**: Unable to use assets as collateral (de Soto's argument)
5. **Infrastructure gaps**: Unreliable power, poor transport, limited internet
6. **Education quality**: Limited business skills and technical knowledge

### Innovation in Developing Countries
- **Frugal innovation**: Developing affordable solutions for low-income markets (e.g., Tata Nano, M-Pesa)
- **Reverse innovation**: Innovations developed for developing markets adopted globally
- **Technology leapfrogging**: Skipping stages of technology development (mobile phones without landlines, mobile banking without traditional banking)`,
      },
      {
        title: "Transaction Cost, Property Rights, and Types of Societies",
        content: `### Transaction Cost Economics
**Ronald Coase** (1937) and **Oliver Williamson** (Nobel Prize 2009) developed transaction cost economics.

**Transaction costs** are the costs of participating in a market beyond the price of the good:
1. **Search and information costs**: Finding trading partners, assessing quality
2. **Bargaining and negotiation costs**: Reaching agreements
3. **Monitoring and enforcement costs**: Ensuring compliance with agreements

**In developing countries, transaction costs are typically higher due to:**
- Weak legal systems and contract enforcement
- Information asymmetries and limited market transparency
- Poor infrastructure (transport, communication)
- Corruption and rent-seeking
- Low levels of trust

### Property Rights
**Property rights** define the rules governing ownership, use, transfer, and protection of assets.

**Hernando de Soto** ("The Mystery of Capital," 2000) argued that:
- The poor in developing countries hold trillions of dollars in assets (homes, land, businesses) but in "dead capital" form
- Without formal property rights, these assets cannot be used as collateral, traded, or invested
- Formalizing property rights would unlock the economic potential of the poor

**Types of Property Rights:**
1. **Use rights**: Right to use an asset
2. **Transfer rights**: Right to sell, lease, or bequeath
3. **Exclusion rights**: Right to prevent others from using
4. **Rights to returns**: Right to income generated by the asset

### Types of Societies and Institutional Development

**North, Wallis, and Weingast** (2009) distinguish between:

**1. Limited Access Orders (Natural States)**
- Political and economic access is limited to elites
- Rents are used to maintain order and prevent violence
- Most developing countries
- Growth is limited by restricted competition and access

**2. Open Access Orders**
- Political and economic competition is open to all citizens
- Rule of law applies equally
- Creative destruction is allowed
- Most developed democracies
- Sustained economic growth is possible

### Role of Democracy
- **Democratic institutions** can promote development through accountability, transparency, and inclusive policy-making
- However, **democracy alone is insufficient** — institutional quality matters more than democratic form
- Some authoritarian regimes have achieved rapid growth (China, Singapore, South Korea under Park)
- **Amartya Sen**: No famine has ever occurred in a functioning democracy — democracy provides protective function`,
      },
    ],
    videos: [
      {
        title: "Why Nations Fail - Institutions and Development",
        youtubeId: "jsZDlBU36n0",
        description: "Acemoglu and Robinson's theory of how institutions determine economic outcomes.",
      },
      {
        title: "Property Rights and Economic Development",
        youtubeId: "9PnbKL3wuH4",
        description: "How property rights affect investment, entrepreneurship, and growth.",
      },
      {
        title: "Entrepreneurship in Developing Countries",
        youtubeId: "bNpx7gpSqbY",
        description: "The role of entrepreneurship in driving development and reducing poverty.",
      },
    ],
    materials: [
      {
        title: "Why Nations Fail (Acemoglu & Robinson)",
        type: "book",
        url: "https://www.google.com/search?q=why+nations+fail+acemoglu+robinson+summary+PDF",
        description: "Summary and key insights from the influential book on institutions and development.",
      },
      {
        title: "World Bank Doing Business Reports",
        type: "article",
        url: "https://www.worldbank.org/en/programs/business-enabling-environment",
        description: "Data on business regulations and institutional quality across countries.",
      },
      {
        title: "Institutions and Development Lecture Notes",
        type: "notes",
        url: "https://www.google.com/search?q=institutions+economic+development+lecture+notes+PDF",
        description: "Academic notes on institutional economics and development.",
      },
    ],
    questions: [
      {
        marks: 2,
        question: "What are institutions according to Douglass North? Give examples of formal and informal institutions.",
        answer: "According to **Douglass North**, institutions are 'the rules of the game in a society' — the humanly devised constraints that structure political, economic, and social interaction. **Formal institutions** include constitutions, laws, property rights systems, contract enforcement mechanisms, and regulatory frameworks. **Informal institutions** include social norms, cultural values, trust, traditions, customs, religious practices, and unwritten codes of conduct. Both types shape incentives, reduce uncertainty, and determine economic outcomes.",
      },
      {
        marks: 5,
        question: "Explain Acemoglu and Robinson's theory of inclusive vs. extractive institutions. How does it explain development differences?",
        answer: "**Acemoglu and Robinson** (Why Nations Fail, 2012) argue that the quality of institutions — whether inclusive or extractive — is the fundamental cause of development differences.\n\n**Inclusive Institutions:**\n- **Economic:** Secure property rights for broad population, level playing field, freedom to enter markets, contract enforcement, access to education\n- **Political:** Pluralistic, distributed political power, constraints on executives, broad participation, free media\n- *Effect:* Create incentives for investment, innovation, and creative destruction → sustained economic growth\n\n**Extractive Institutions:**\n- **Economic:** Property rights limited to elites, barriers to entry, lack of law and order, restricted economic freedom\n- **Political:** Power concentrated in narrow elite, no checks and balances, limited political rights\n- *Effect:* Elites extract rents from population, discourage investment and innovation → stagnation or decline\n\n**Historical Evidence:**\n- **North vs. South Korea:** Same culture, geography, and history but drastically different institutions post-1945. South Korea's inclusive institutions generated prosperity; North Korea's extractive institutions created poverty.\n- **Colonial origins:** Europeans established extractive institutions in densely populated, disease-prone areas (Africa, Latin America) and inclusive institutions where they settled (US, Australia). These institutional differences persist and explain current income gaps.\n- **Critical junctures:** Events like the Glorious Revolution (1688), which constrained the English crown, set England on a path of inclusive institutions and the Industrial Revolution.\n\n**Criticism:** Oversimplifies complex historical processes; some extractive regimes achieved growth (China); defining 'inclusive' vs. 'extractive' can be circular.",
      },
      {
        marks: 10,
        question: "Discuss the role of institutions in economic development. How do property rights, entrepreneurship, and governance affect development outcomes? Illustrate with examples from developing countries.",
        answer: "**Introduction:**\nInstitutional economics, pioneered by Douglass North, has established that institutions — the formal and informal rules governing human interaction — are fundamental determinants of economic development. Countries with similar resource endowments and geographic conditions achieve vastly different outcomes depending on their institutional quality.\n\n**1. Property Rights and Development:**\n\n**Theoretical Framework:**\n- Secure property rights incentivize investment — people invest when they are confident they will reap the returns\n- Property rights enable the use of assets as collateral, unlocking credit (de Soto's 'mystery of capital')\n- Clear property rights reduce transaction costs and facilitate market exchange\n\n**Evidence from Developing Countries:**\n- **Land titling in Peru:** Following de Soto's recommendations, Peru implemented large-scale land titling. Evidence shows improved investment in housing and reduced conflict, though effects on credit access were modest.\n- **China's Household Responsibility System (1978):** Giving farmers property rights over their land use dramatically increased agricultural productivity — output grew 50% in 6 years without significant new investment.\n- **Bangladesh:** Weak land administration and records lead to extensive land disputes consuming 70% of court cases. Insecure tenure discourages investment and creates conflict.\n- **Botswana vs. DRC:** Both resource-rich African countries, but Botswana's strong property rights and governance enabled effective diamond wealth management, while DRC's weak institutions led to resource plunder and conflict.\n\n**2. Entrepreneurship and Development:**\n\n**Institutional Environment for Entrepreneurship:**\n- **Ease of doing business:** Number of procedures, time, and cost to start a business vary enormously. In Denmark, it takes 3.5 days to start a business; in some developing countries, over 100 days.\n- **Access to finance:** Institutional frameworks determine whether entrepreneurs can access capital. Weak banking regulation, lack of credit information systems, and collateral requirements exclude most entrepreneurs.\n- **Regulatory quality:** Excessive regulation stifles entrepreneurship; too little creates chaos and fraud.\n\n**Examples:**\n- **Kenya's M-Pesa:** Mobile money innovation thrived partly because Kenya's regulatory environment allowed telecom companies to provide financial services — an institutional choice that other countries (like Nigeria initially) did not make.\n- **Bangladesh's garment industry:** Emerged partly due to institutional innovations — bonded warehouse facilities, back-to-back LC systems, and export processing zones that overcame institutional weaknesses in the broader economy.\n- **India's IT sector:** Grew in Bangalore partly because the sector operated outside India's restrictive industrial licensing system ('License Raj'), demonstrating how institutional bypasses can enable entrepreneurship.\n- **Grameen Bank:** Muhammad Yunus's institutional innovation — lending to poor women without collateral — challenged conventional banking institutions and proved that the poor are creditworthy.\n\n**3. Governance and Development:**\n\n**Key Governance Dimensions:**\n\n**a) Government Effectiveness:**\n- Quality of public services, civil service, policy formulation, and implementation\n- *Example:* Rwanda has achieved remarkable development outcomes (GDP growth, poverty reduction, health improvements) through effective governance despite limited resources.\n- *Counter-example:* Haiti's chronic government ineffectiveness has perpetuated underdevelopment despite significant aid.\n\n**b) Rule of Law:**\n- Confidence in and compliance with rules of society, particularly contract enforcement, property rights, police, and courts\n- *Example:* Singapore's strong rule of law attracts massive FDI and enables complex economic transactions.\n- *Counter-example:* In many developing countries, the wealthy can circumvent laws, creating a two-tier system that discourages investment by ordinary citizens.\n\n**c) Control of Corruption:**\n- Corruption increases transaction costs, distorts resource allocation, and reduces public trust\n- *Example:* Transparency International estimates corruption costs developing countries $1.26 trillion per year — enough to lift 1.4 billion people above $1.25/day.\n- *Example:* Indonesia's anti-corruption agency (KPK) has significantly improved governance and investor confidence since its establishment.\n\n**d) Voice and Accountability:**\n- Democratic participation, free media, and government accountability\n- *Example:* Amartya Sen observed that no substantial famine has occurred in a functioning democracy — democratic accountability creates pressure for government response to crises.\n- *Example:* Botswana's democratic institutions have enabled peaceful power transitions and inclusive policy-making.\n\n**4. Institutional Challenges in Developing Countries:**\n\n1. **Colonial legacy:** Many developing countries inherited extractive institutions designed for resource extraction, not citizen welfare.\n2. **Institutional transplantation:** Importing Western institutional models often fails because they don't fit local contexts. Democracy in some post-colonial countries became vehicles for ethnic competition rather than inclusive governance.\n3. **Informal institutions:** Formal institutional changes may conflict with deeply embedded informal norms (patron-client networks, caste systems, ethnic loyalties).\n4. **Capacity constraints:** Implementing good institutions requires trained personnel, technology, and resources that may be scarce.\n5. **Political economy:** Elites who benefit from extractive institutions resist reform.\n\n**5. Transaction Costs and Institutional Quality:**\n- In developing countries, transaction costs are higher due to weak contract enforcement, information asymmetries, corruption, and poor infrastructure\n- These higher costs reduce the volume and complexity of economic transactions, limiting economic growth\n- Institutional reforms that reduce transaction costs (digitization of government services, e-courts, land registries) can significantly boost economic activity\n\n**Conclusion:**\nInstitutions are the foundational determinant of economic development. Property rights, entrepreneurial enabling environments, and good governance create the conditions for sustainable growth. However, institutional reform is inherently political — those who benefit from existing arrangements resist change. Developing countries must pursue context-appropriate institutional reforms that build on local strengths while addressing specific weaknesses. The most successful development stories (South Korea, China, Botswana, Bangladesh in garments) involved institutional innovations tailored to local conditions rather than wholesale adoption of external models.",
      },
    ],
  },
];
