export interface ModelTest {
  id: number;
  title: string;
  description: string;
  duration: number; // minutes
  totalMarks: number;
  sections: ModelTestSection[];
}

export interface ModelTestSection {
  title: string;
  instructions: string;
  questionRefs: string[]; // references to examQuestion ids
}

export const modelTests: ModelTest[] = [
  {
    id: 1,
    title: "Model Test 1: Midterm Examination (Section A)",
    description: "Covers Chapters 1-4: Introducing Development Economics, Measuring Development, Growth Theories, Human Development",
    duration: 120,
    totalMarks: 30,
    sections: [
      {
        title: "Section A — Short Questions (Answer any 2)",
        instructions: "Each question carries 5 marks. Write concise but comprehensive answers.",
        questionRefs: ["ch1-m1", "ch2-m1", "ch3-e1"],
      },
      {
        title: "Section B — Analytical Questions (Answer any 2)",
        instructions: "Each question carries 10 marks. Provide detailed analysis with examples, graphs, and theoretical frameworks.",
        questionRefs: ["ch1-h1", "ch2-h1", "ch1-h2"],
      },
    ],
  },
  {
    id: 2,
    title: "Model Test 2: Final Examination (Section B)",
    description: "Covers Chapters 5-8: Industrialization, Poverty, Inequality, Institutions",
    duration: 120,
    totalMarks: 30,
    sections: [
      {
        title: "Section A — Short Questions (Answer any 2)",
        instructions: "Each question carries 5 marks. Write concise but comprehensive answers.",
        questionRefs: ["ch5-e1", "ch6-e1", "ch3-m1"],
      },
      {
        title: "Section B — Analytical Questions (Answer any 2)",
        instructions: "Each question carries 10 marks. Provide detailed scenario-based analysis.",
        questionRefs: ["ch6-exam1", "ch7-exam1", "ch8-exam1"],
      },
    ],
  },
  {
    id: 3,
    title: "Model Test 3: Comprehensive Final Exam",
    description: "Covers all chapters (1-8). Full exam simulation matching your teacher's question pattern.",
    duration: 180,
    totalMarks: 50,
    sections: [
      {
        title: "Part A — Short Answer (Answer any 3)",
        instructions: "Each carries 2-3 marks. Brief, precise answers required.",
        questionRefs: ["ch1-e1", "ch2-e1", "ch4-e1", "ch1-e2"],
      },
      {
        title: "Part B — Medium Questions (Answer any 2)",
        instructions: "Each carries 5 marks. Detailed answers with examples required.",
        questionRefs: ["ch1-m1", "ch2-m1", "ch3-m1"],
      },
      {
        title: "Part C — Long Analytical Questions (Answer any 2)",
        instructions: "Each carries 10 marks. Scenario-based analysis with multi-part answers. Include theoretical frameworks, examples, and critical evaluation.",
        questionRefs: ["ch1-h1", "ch6-exam1", "ch7-exam1", "ch8-exam1"],
      },
    ],
  },
];
