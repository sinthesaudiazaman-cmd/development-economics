import { chapters } from "@/data/courseData";
import { notFound } from "next/navigation";
import { ChapterContent } from "@/components/ChapterContent";
import Link from "next/link";

export function generateStaticParams() {
  return chapters.map((c) => ({ id: String(c.id) }));
}

export default async function ChapterPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const chapterId = parseInt(id, 10);
  const chapter = chapters.find((c) => c.id === chapterId);

  if (!chapter) {
    notFound();
  }

  const prevChapter = chapters.find((c) => c.id === chapterId - 1);
  const nextChapter = chapters.find((c) => c.id === chapterId + 1);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top bar */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span className="text-sm font-medium">All Chapters</span>
          </Link>
          <div className="flex items-center gap-2">
            {prevChapter && (
              <Link
                href={`/chapter/${prevChapter.id}`}
                className="text-xs bg-gray-100 hover:bg-gray-200 px-3 py-1.5 rounded-lg transition-colors"
              >
                ← Ch {prevChapter.id}
              </Link>
            )}
            {nextChapter && (
              <Link
                href={`/chapter/${nextChapter.id}`}
                className="text-xs bg-blue-100 hover:bg-blue-200 text-blue-700 px-3 py-1.5 rounded-lg transition-colors"
              >
                Ch {nextChapter.id} →
              </Link>
            )}
          </div>
        </div>
      </header>

      {/* Chapter header */}
      <div
        className={`${
          chapter.section === "A"
            ? "bg-gradient-to-r from-blue-800 to-blue-900"
            : "bg-gradient-to-r from-purple-800 to-purple-900"
        } text-white`}
      >
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex items-center gap-3 mb-2">
            <span
              className={`text-xs font-bold px-3 py-1 rounded-full ${
                chapter.section === "A" ? "bg-blue-700/60" : "bg-purple-700/60"
              }`}
            >
              Section {chapter.section} · Chapter {chapter.id}
            </span>
            <span className="text-xs opacity-70">CLO: {chapter.clos}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold mt-2">{chapter.title}</h1>
          <div className="flex flex-wrap gap-3 mt-4">
            <span className="text-sm bg-white/10 px-3 py-1 rounded-lg">📖 {chapter.topics.length} Topics</span>
            <span className="text-sm bg-white/10 px-3 py-1 rounded-lg">🎬 {chapter.videos.length} Videos</span>
            <span className="text-sm bg-white/10 px-3 py-1 rounded-lg">📂 {chapter.materials.length} Materials</span>
            <span className="text-sm bg-white/10 px-3 py-1 rounded-lg">📝 {chapter.questions.length} Questions</span>
          </div>
        </div>
      </div>

      {/* Main content */}
      <ChapterContent chapter={chapter} />

      {/* Navigation footer */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex justify-between items-center">
          {prevChapter ? (
            <Link
              href={`/chapter/${prevChapter.id}`}
              className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-5 py-3 hover:shadow-md transition-all"
            >
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              <div>
                <p className="text-xs text-gray-400">Previous</p>
                <p className="text-sm font-medium text-gray-700">Ch {prevChapter.id}: {prevChapter.title}</p>
              </div>
            </Link>
          ) : (
            <div />
          )}
          {nextChapter ? (
            <Link
              href={`/chapter/${nextChapter.id}`}
              className="flex items-center gap-2 bg-blue-600 text-white rounded-xl px-5 py-3 hover:bg-blue-700 transition-all"
            >
              <div className="text-right">
                <p className="text-xs text-blue-200">Next Chapter</p>
                <p className="text-sm font-medium">Ch {nextChapter.id}: {nextChapter.title}</p>
              </div>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          ) : (
            <Link
              href="/"
              className="flex items-center gap-2 bg-green-600 text-white rounded-xl px-5 py-3 hover:bg-green-700 transition-all"
            >
              <div className="text-right">
                <p className="text-xs text-green-200">Finished!</p>
                <p className="text-sm font-medium">Back to Dashboard</p>
              </div>
              <span className="text-xl">🎉</span>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
