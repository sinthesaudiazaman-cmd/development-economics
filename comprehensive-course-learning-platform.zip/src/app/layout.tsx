import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Development Economics | Study Portal",
  description: "Comprehensive study portal for Development Economics course (0388 21 DS 2201)",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-gray-50 text-slate-900 antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
