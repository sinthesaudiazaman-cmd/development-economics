import { db } from "@/db";
import { modelTestAttempts } from "@/db/schema";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const attempts = await db.select().from(modelTestAttempts);
    return NextResponse.json(attempts);
  } catch {
    return NextResponse.json([], { status: 200 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { testId, score, totalMarks } = body;

    const result = await db.insert(modelTestAttempts).values({
      testId,
      score,
      totalMarks,
      completedAt: new Date(),
    }).returning();

    return NextResponse.json(result[0]);
  } catch (e) {
    console.error("Model test save error:", e);
    return NextResponse.json({ error: "Failed to save" }, { status: 500 });
  }
}
