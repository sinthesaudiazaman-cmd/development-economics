import { db } from "@/db";
import { chapterProgress } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const progress = await db.select().from(chapterProgress);
    return NextResponse.json(progress);
  } catch {
    return NextResponse.json([], { status: 200 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { chapterId, field, value } = body;

    // Check if record exists
    const existing = await db
      .select()
      .from(chapterProgress)
      .where(eq(chapterProgress.chapterId, chapterId));

    if (existing.length === 0) {
      // Create new record
      const insertData: Record<string, unknown> = {
        chapterId,
        [field]: value,
        updatedAt: new Date(),
      };
      await db.insert(chapterProgress).values(insertData as typeof chapterProgress.$inferInsert);
    } else {
      // Update existing record
      const updateData: Record<string, unknown> = {
        [field]: value,
        updatedAt: new Date(),
      };
      await db
        .update(chapterProgress)
        .set(updateData)
        .where(eq(chapterProgress.chapterId, chapterId));
    }

    const updated = await db
      .select()
      .from(chapterProgress)
      .where(eq(chapterProgress.chapterId, chapterId));

    return NextResponse.json(updated[0]);
  } catch (e) {
    console.error("Progress update error:", e);
    return NextResponse.json({ error: "Failed to update progress" }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { chapterId, notes } = body;

    const existing = await db
      .select()
      .from(chapterProgress)
      .where(eq(chapterProgress.chapterId, chapterId));

    if (existing.length === 0) {
      await db.insert(chapterProgress).values({
        chapterId,
        notes,
        updatedAt: new Date(),
      });
    } else {
      await db
        .update(chapterProgress)
        .set({ notes, updatedAt: new Date() })
        .where(eq(chapterProgress.chapterId, chapterId));
    }

    return NextResponse.json({ success: true });
  } catch (e) {
    console.error("Notes update error:", e);
    return NextResponse.json({ error: "Failed to update notes" }, { status: 500 });
  }
}
