import Link from "next/link";
import { modelTests } from "@/data/modelTests";

export default function ModelTestsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-gradient-to-r from-purple-900 via-purple-800 to-indigo-900 text-white">
        <div className="max-w-5xl mx-auto px-4 py-8">
          <Link href="/" className="text-purple-300 hover:text-white text-sm mb-4 inline-flex items-center gap-1 transition-colors">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
            Back to Dashboard
          </Link>
          <h1 className="text-3xl font-bold mt-2">📝 Model Tests</h1>
          <p className="mt-2 text-purple-200">Practice with full exam simulations matching your teacher&apos;s question pattern</p>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8">
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-8">
          <h3 className="font-bold text-amber-800 flex items-center gap-2">💡 How to Use Model Tests</h3>
          <ul className="mt-2 text-sm text-amber-700 space-y-1">
            <li>• Each test simulates your actual exam format with scenario-based questions</li>
            <li>• Try answering questions on paper first, then reveal model answers to compare</li>
            <li>• Time yourself according to the duration specified</li>
            <li>• Focus on understanding the answer structure — introduction, analysis, examples, conclusion</li>
          </ul>
        </div>

        <div className="grid gap-6">
          {modelTests.map((test) => (
            <Link key={test.id} href={`/model-tests/${test.id}`}>
              <div className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg hover:border-purple-300 transition-all cursor-pointer group">
                <div className="flex items-start justify-between mb-3">
                  <span className="text-xs font-bold bg-purple-100 text-purple-700 px-3 py-1 rounded-full">
                    Test {test.id}
                  </span>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>⏱ {test.duration} min</span>
                    <span>📊 {test.totalMarks} marks</span>
                  </div>
                </div>
                <h2 className="text-lg font-bold text-gray-900 group-hover:text-purple-600 transition-colors">
                  {test.title}
                </h2>
                <p className="text-sm text-gray-500 mt-2">{test.description}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {test.sections.map((s, i) => (
                    <span key={i} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                      {s.title}
                    </span>
                  ))}
                </div>
                <div className="mt-4 text-sm font-medium text-purple-600 group-hover:text-purple-700 flex items-center gap-1">
                  Start Test →
                </div>
              </div>
            </Link>
          ))}
        </div>
      </main>
    </div>
  );
}
