import { modelTests } from "@/data/modelTests";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ModelTestRunner } from "@/components/ModelTestRunner";

export function generateStaticParams() {
  return modelTests.map((t) => ({ id: String(t.id) }));
}

export default async function ModelTestPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const testId = parseInt(id, 10);
  const test = modelTests.find((t) => t.id === testId);

  if (!test) notFound();

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-gradient-to-r from-purple-900 via-purple-800 to-indigo-900 text-white sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/model-tests" className="text-purple-300 hover:text-white text-sm inline-flex items-center gap-1 transition-colors">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
            All Tests
          </Link>
          <div className="text-right">
            <p className="text-sm font-medium">{test.title}</p>
            <p className="text-xs text-purple-300">⏱ {test.duration} min · 📊 {test.totalMarks} marks</p>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-6">
        <ModelTestRunner test={test} />
      </main>
    </div>
  );
}
