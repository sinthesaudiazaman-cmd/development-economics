import Link from "next/link";
import { chapters, courseInfo } from "@/data/courseData";
import { modelTests } from "@/data/modelTests";
import { ProgressOverview } from "@/components/ProgressOverview";

export default function HomePage() {
  const sectionA = chapters.filter((c) => c.section === "A");
  const sectionB = chapters.filter((c) => c.section === "B");

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 text-white">
        <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-3xl">📚</span>
            <span className="text-sm font-medium bg-blue-700/50 px-3 py-1 rounded-full">
              {courseInfo.code}
            </span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold mt-2">{courseInfo.title}</h1>
          <p className="mt-2 text-blue-200 text-lg">
            Second Year · Second Term · Credit: {courseInfo.credit} · Status: {courseInfo.status}
          </p>
          <p className="mt-4 text-blue-100 max-w-3xl leading-relaxed text-sm">
            {courseInfo.rationale}
          </p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {/* Progress Overview */}
        <ProgressOverview />

        {/* Course Features */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-10">
          {[
            { icon: "📖", label: "Book-like Content", desc: "Detailed explanations" },
            { icon: "🎬", label: "YouTube Videos", desc: "Curated lectures" },
            { icon: "📝", label: "Exam Questions", desc: "Your teacher's pattern" },
            { icon: "📂", label: "Study Materials", desc: "Notes, PDFs, articles" },
            { icon: "🧪", label: "Model Tests", desc: "Full exam simulation" },
          ].map((f) => (
            <div key={f.label} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 text-center">
              <span className="text-2xl block mb-2">{f.icon}</span>
              <h3 className="font-semibold text-sm text-gray-800">{f.label}</h3>
              <p className="text-xs text-gray-500 mt-1">{f.desc}</p>
            </div>
          ))}
        </div>

        {/* Section A */}
        <section className="mb-10">
          <div className="flex items-center gap-3 mb-6">
            <div className="h-10 w-10 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">
              A
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">Section A</h2>
              <p className="text-sm text-gray-500">Foundations of Development Economics</p>
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {sectionA.map((chapter) => (
              <ChapterCard key={chapter.id} chapter={chapter} />
            ))}
          </div>
        </section>

        {/* Section B */}
        <section className="mb-10">
          <div className="flex items-center gap-3 mb-6">
            <div className="h-10 w-10 bg-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">
              B
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">Section B</h2>
              <p className="text-sm text-gray-500">Applied Development Issues</p>
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {sectionB.map((chapter) => (
              <ChapterCard key={chapter.id} chapter={chapter} />
            ))}
          </div>
        </section>

        {/* Model Tests */}
        <section className="mb-10">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                🧪
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">Model Tests</h2>
                <p className="text-sm text-gray-500">Full exam simulations with timer</p>
              </div>
            </div>
            <Link href="/model-tests" className="text-sm text-purple-600 hover:text-purple-700 font-medium">
              View All →
            </Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-3">
            {modelTests.map((test) => (
              <Link key={test.id} href={`/model-tests/${test.id}`}>
                <div className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-lg hover:border-purple-300 transition-all cursor-pointer group h-full">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold bg-purple-100 text-purple-700 px-2.5 py-1 rounded-full">
                      Test {test.id}
                    </span>
                    <span className="text-xs text-gray-400">⏱ {test.duration}min</span>
                  </div>
                  <h3 className="font-bold text-sm text-gray-900 group-hover:text-purple-600 transition-colors mb-2">
                    {test.title}
                  </h3>
                  <p className="text-xs text-gray-500">{test.description}</p>
                  <div className="mt-3 flex items-center gap-2 text-xs text-gray-400">
                    <span>📊 {test.totalMarks} marks</span>
                    <span>·</span>
                    <span>{test.sections.length} sections</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-8 mt-10">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-sm">Development Economics Study Portal · Course Code: {courseInfo.code}</p>
          <p className="text-xs mt-2">Second Year, Second Term · Prerequisite: None</p>
        </div>
      </footer>
    </div>
  );
}

function ChapterCard({ chapter }: { chapter: (typeof chapters)[0] }) {
  const colorClass = chapter.section === "A" ? "blue" : "purple";
  return (
    <Link href={`/chapter/${chapter.id}`}>
      <div className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-lg hover:border-blue-300 transition-all duration-200 cursor-pointer group h-full">
        <div className="flex items-start justify-between mb-3">
          <span
            className={`text-xs font-bold px-2.5 py-1 rounded-full ${
              colorClass === "blue"
                ? "bg-blue-100 text-blue-700"
                : "bg-purple-100 text-purple-700"
            }`}
          >
            Chapter {chapter.id}
          </span>
          <span className="text-xs text-gray-400">CLO: {chapter.clos}</span>
        </div>
        <h3 className="font-bold text-gray-900 group-hover:text-blue-600 transition-colors mb-3">
          {chapter.title}
        </h3>
        <div className="flex flex-wrap gap-2 mb-3">
          {chapter.topics.slice(0, 3).map((t) => (
            <span key={t.title} className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">
              {t.title.length > 30 ? t.title.slice(0, 30) + "…" : t.title}
            </span>
          ))}
          {chapter.topics.length > 3 && (
            <span className="text-xs text-gray-400">+{chapter.topics.length - 3} more</span>
          )}
        </div>
        <div className="flex items-center gap-4 text-xs text-gray-500 pt-3 border-t border-gray-100">
          <span>📖 {chapter.topics.length} Topics</span>
          <span>🎬 {chapter.videos.length} Videos</span>
          <span>📝 {chapter.questions.length} Q&apos;s</span>
          <span>📂 {chapter.materials.length} Materials</span>
        </div>
      </div>
    </Link>
  );
}
