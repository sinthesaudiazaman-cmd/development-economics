import { pgTable, serial, integer, boolean, timestamp, text } from "drizzle-orm/pg-core";

export const chapterProgress = pgTable("chapter_progress", {
  id: serial("id").primaryKey(),
  chapterId: integer("chapter_id").notNull().unique(),
  contentRead: boolean("content_read").default(false).notNull(),
  materialsReviewed: boolean("materials_reviewed").default(false).notNull(),
  videosWatched: boolean("videos_watched").default(false).notNull(),
  questionsCompleted: boolean("questions_completed").default(false).notNull(),
  notes: text("notes").default(""),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const modelTestAttempts = pgTable("model_test_attempts", {
  id: serial("id").primaryKey(),
  testId: integer("test_id").notNull(),
  score: integer("score").default(0).notNull(),
  totalMarks: integer("total_marks").notNull(),
  completedAt: timestamp("completed_at").defaultNow().notNull(),
});
