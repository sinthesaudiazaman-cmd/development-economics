"use client";

import type { Chapter } from "@/data/courseData";

export function VideosTab({ chapter }: { chapter: Chapter }) {
  return (
    <div>
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-900 mb-2">🎬 Video Lectures</h2>
        <p className="text-sm text-gray-500">
          Curated YouTube videos related to Chapter {chapter.id}: {chapter.title}
        </p>
      </div>

      <div className="grid gap-6">
        {chapter.videos.map((video, index) => (
          <div key={index} className="bg-white border border-gray-200 rounded-xl overflow-hidden">
            <div className="aspect-video bg-gray-900">
              <iframe
                src={`https://www.youtube.com/embed/${video.youtubeId}`}
                title={video.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="w-full h-full"
              ></iframe>
            </div>
            <div className="p-4">
              <h3 className="font-semibold text-gray-900">{video.title}</h3>
              <p className="text-sm text-gray-500 mt-1">{video.description}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Search for more videos */}
      <div className="mt-8 bg-gradient-to-r from-red-50 to-pink-50 border border-red-200 rounded-xl p-5">
        <h3 className="font-bold text-red-800 mb-3">🔍 Find More Videos</h3>
        <div className="grid sm:grid-cols-2 gap-3">
          <a
            href={`https://www.youtube.com/results?search_query=${encodeURIComponent(
              chapter.title + " development economics"
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm bg-white rounded-lg p-3 border border-red-200 hover:shadow-sm transition-all text-red-800"
          >
            ▶️ Search YouTube for &ldquo;{chapter.title}&rdquo;
          </a>
          <a
            href={`https://www.youtube.com/results?search_query=${encodeURIComponent(
              chapter.title + " lecture bangla"
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm bg-white rounded-lg p-3 border border-red-200 hover:shadow-sm transition-all text-red-800"
          >
            ▶️ Search Bengali Lectures
          </a>
          {chapter.topics.map((topic, i) => (
            <a
              key={i}
              href={`https://www.youtube.com/results?search_query=${encodeURIComponent(
                topic.title + " explained economics"
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm bg-white rounded-lg p-3 border border-red-200 hover:shadow-sm transition-all text-red-800"
            >
              ▶️ {topic.title.length > 40 ? topic.title.slice(0, 40) + "…" : topic.title}
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
