"use client";

import type { Chapter } from "@/data/courseData";

function renderContent(content: string) {
  // Simple markdown-like rendering
  const lines = content.split("\n");
  const elements: React.ReactNode[] = [];
  let inTable = false;
  let tableRows: string[][] = [];
  let tableHeaders: string[] = [];
  let listItems: string[] = [];
  let inList = false;
  let listType: "ul" | "ol" = "ul";

  const processInlineFormatting = (text: string): React.ReactNode => {
    const parts: React.ReactNode[] = [];
    let remaining = text;
    let keyIndex = 0;

    while (remaining.length > 0) {
      const boldMatch = remaining.match(/\*\*(.+?)\*\*/);
      if (boldMatch && boldMatch.index !== undefined) {
        if (boldMatch.index > 0) {
          parts.push(remaining.slice(0, boldMatch.index));
        }
        parts.push(
          <strong key={keyIndex++} className="font-bold text-gray-900">
            {boldMatch[1]}
          </strong>
        );
        remaining = remaining.slice(boldMatch.index + boldMatch[0].length);
      } else {
        parts.push(remaining);
        break;
      }
    }
    return parts.length === 1 ? parts[0] : <>{parts}</>;
  };

  const flushList = () => {
    if (listItems.length > 0) {
      const Tag = listType;
      elements.push(
        <Tag key={`list-${elements.length}`} className={`${listType === 'ol' ? 'list-decimal' : 'list-disc'} ml-6 mb-4 space-y-1`}>
          {listItems.map((item, i) => (
            <li key={i} className="text-gray-700 leading-relaxed">
              {processInlineFormatting(item)}
            </li>
          ))}
        </Tag>
      );
      listItems = [];
      inList = false;
    }
  };

  const flushTable = () => {
    if (tableRows.length > 0) {
      elements.push(
        <div key={`table-${elements.length}`} className="overflow-x-auto mb-4">
          <table className="w-full border-collapse text-sm">
            {tableHeaders.length > 0 && (
              <thead>
                <tr>
                  {tableHeaders.map((h, i) => (
                    <th key={i} className="border border-gray-300 bg-gray-100 px-3 py-2 text-left font-semibold">
                      {processInlineFormatting(h.trim())}
                    </th>
                  ))}
                </tr>
              </thead>
            )}
            <tbody>
              {tableRows.map((row, ri) => (
                <tr key={ri} className={ri % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                  {row.map((cell, ci) => (
                    <td key={ci} className="border border-gray-300 px-3 py-2">
                      {processInlineFormatting(cell.trim())}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
      tableRows = [];
      tableHeaders = [];
      inTable = false;
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();

    // Table rows
    if (trimmed.startsWith("|") && trimmed.endsWith("|")) {
      const cells = trimmed.split("|").filter((c) => c.trim() !== "");
      if (cells.every((c) => c.trim().match(/^[-:]+$/))) {
        continue; // separator row
      }
      if (!inTable) {
        inTable = true;
        tableHeaders = cells;
      } else {
        tableRows.push(cells);
      }
      continue;
    } else if (inTable) {
      flushTable();
    }

    // Headings
    if (trimmed.startsWith("### ")) {
      flushList();
      elements.push(
        <h3 key={`h3-${i}`} className="text-lg font-bold text-gray-800 mt-6 mb-3 flex items-center gap-2">
          <span className="w-1.5 h-5 bg-blue-500 rounded-full inline-block"></span>
          {processInlineFormatting(trimmed.replace("### ", ""))}
        </h3>
      );
      continue;
    }

    if (trimmed.startsWith("## ")) {
      flushList();
      elements.push(
        <h2 key={`h2-${i}`} className="text-xl font-bold text-gray-900 mt-8 mb-4">
          {processInlineFormatting(trimmed.replace("## ", ""))}
        </h2>
      );
      continue;
    }

    // Numbered list
    const numberedMatch = trimmed.match(/^(\d+)\.\s+(.+)/);
    if (numberedMatch) {
      if (!inList || listType !== "ol") {
        flushList();
        inList = true;
        listType = "ol";
      }
      listItems.push(numberedMatch[2]);
      continue;
    }

    // Bullet list
    if (trimmed.startsWith("- ")) {
      if (!inList || listType !== "ul") {
        flushList();
        inList = true;
        listType = "ul";
      }
      listItems.push(trimmed.replace("- ", ""));
      continue;
    }

    // Empty line
    if (trimmed === "") {
      flushList();
      continue;
    }

    // Regular paragraph
    flushList();
    elements.push(
      <p key={`p-${i}`} className="text-gray-700 leading-relaxed mb-3">
        {processInlineFormatting(trimmed)}
      </p>
    );
  }

  flushList();
  flushTable();

  return elements;
}

export function ContentTab({ chapter }: { chapter: Chapter }) {
  return (
    <div>
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-900 mb-2">
          Chapter {chapter.id}: {chapter.title}
        </h2>
        <p className="text-sm text-gray-500">
          Comprehensive study material covering all topics · Section {chapter.section} · CLO: {chapter.clos}
        </p>
      </div>

      {chapter.topics.map((topic, index) => (
        <div
          key={index}
          id={`topic-${index}`}
          className="mb-8 scroll-mt-24"
        >
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border-l-4 border-blue-500 rounded-r-lg p-4 mb-4">
            <h2 className="text-lg font-bold text-blue-900">
              {index + 1}. {topic.title}
            </h2>
          </div>
          <div className="prose max-w-none px-1">
            {renderContent(topic.content)}
          </div>
          {index < chapter.topics.length - 1 && (
            <hr className="my-8 border-gray-200" />
          )}
        </div>
      ))}
    </div>
  );
}
