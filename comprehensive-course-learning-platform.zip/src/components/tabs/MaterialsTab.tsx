"use client";

import type { Chapter } from "@/data/courseData";

const typeIcons: Record<string, string> = {
  pdf: "📄",
  article: "🌐",
  notes: "📝",
  book: "📚",
  slides: "📊",
};

const typeColors: Record<string, string> = {
  pdf: "bg-red-100 text-red-700",
  article: "bg-blue-100 text-blue-700",
  notes: "bg-yellow-100 text-yellow-700",
  book: "bg-green-100 text-green-700",
  slides: "bg-purple-100 text-purple-700",
};

export function MaterialsTab({ chapter }: { chapter: Chapter }) {
  return (
    <div>
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-900 mb-2">📂 Study Materials</h2>
        <p className="text-sm text-gray-500">
          Curated resources including textbooks, lecture notes, articles, and handnotes for Chapter {chapter.id}
        </p>
      </div>

      <div className="grid gap-4">
        {chapter.materials.map((material, index) => (
          <a
            key={index}
            href={material.url}
            target="_blank"
            rel="noopener noreferrer"
            className="block bg-white border border-gray-200 rounded-xl p-5 hover:shadow-md hover:border-blue-300 transition-all group"
          >
            <div className="flex items-start gap-4">
              <span className="text-2xl">{typeIcons[material.type] || "📄"}</span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                    {material.title}
                  </h3>
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      typeColors[material.type] || "bg-gray-100 text-gray-600"
                    }`}
                  >
                    {material.type.toUpperCase()}
                  </span>
                </div>
                <p className="text-sm text-gray-500">{material.description}</p>
              </div>
              <svg
                className="w-5 h-5 text-gray-300 group-hover:text-blue-500 transition-colors shrink-0 mt-1"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                />
              </svg>
            </div>
          </a>
        ))}
      </div>

      {/* Additional Resources Section */}
      <div className="mt-8 bg-gradient-to-r from-amber-50 to-yellow-50 border border-amber-200 rounded-xl p-5">
        <h3 className="font-bold text-amber-800 mb-3 flex items-center gap-2">
          💡 Additional Resources
        </h3>
        <div className="grid sm:grid-cols-2 gap-3">
          <a
            href={`https://www.google.com/search?q=${encodeURIComponent(
              chapter.title + " development economics lecture notes handnotes PDF"
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm bg-white rounded-lg p-3 border border-amber-200 hover:shadow-sm transition-all text-amber-800 hover:text-amber-900"
          >
            📝 Search Handwritten Notes
          </a>
          <a
            href={`https://www.google.com/search?q=${encodeURIComponent(
              chapter.title + " development economics slides presentation"
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm bg-white rounded-lg p-3 border border-amber-200 hover:shadow-sm transition-all text-amber-800 hover:text-amber-900"
          >
            📊 Search Presentation Slides
          </a>
          <a
            href={`https://www.coursera.org/search?query=${encodeURIComponent(chapter.title)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm bg-white rounded-lg p-3 border border-amber-200 hover:shadow-sm transition-all text-amber-800 hover:text-amber-900"
          >
            🎓 Coursera Courses
          </a>
          <a
            href={`https://www.khanacademy.org/search?referer=%2F&page_search_query=${encodeURIComponent(
              chapter.title
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm bg-white rounded-lg p-3 border border-amber-200 hover:shadow-sm transition-all text-amber-800 hover:text-amber-900"
          >
            🏫 Khan Academy
          </a>
        </div>
      </div>
    </div>
  );
}
