"use client";

import { useState } from "react";
import type { Chapter } from "@/data/courseData";
import { examQuestions, type ExamQuestion } from "@/data/examQuestions";

function renderAnswer(text: string): React.ReactNode {
  const lines = text.split("\n");
  const elements: React.ReactNode[] = [];
  let listItems: string[] = [];
  let listType: "ul" | "ol" = "ul";
  let inTable = false;
  let tableHeaders: string[] = [];
  let tableRows: string[][] = [];

  const processInline = (str: string): React.ReactNode => {
    const parts: React.ReactNode[] = [];
    let remaining = str;
    let keyIndex = 0;
    while (remaining.length > 0) {
      const boldMatch = remaining.match(/\*\*(.+?)\*\*/);
      if (boldMatch && boldMatch.index !== undefined) {
        if (boldMatch.index > 0) parts.push(remaining.slice(0, boldMatch.index));
        parts.push(<strong key={keyIndex++} className="font-semibold text-gray-900">{boldMatch[1]}</strong>);
        remaining = remaining.slice(boldMatch.index + boldMatch[0].length);
      } else {
        parts.push(remaining);
        break;
      }
    }
    return parts.length === 1 ? parts[0] : <>{parts}</>;
  };

  const flushList = () => {
    if (listItems.length > 0) {
      const Tag = listType;
      elements.push(
        <Tag key={`list-${elements.length}`} className={`${listType === "ol" ? "list-decimal" : "list-disc"} ml-6 mb-3 space-y-1`}>
          {listItems.map((item, i) => (
            <li key={i} className="text-sm text-gray-700 leading-relaxed">
              {processInline(item)}
            </li>
          ))}
        </Tag>
      );
      listItems = [];
    }
  };

  const flushTable = () => {
    if (tableRows.length > 0 || tableHeaders.length > 0) {
      elements.push(
        <div key={`table-${elements.length}`} className="overflow-x-auto mb-4">
          <table className="w-full border-collapse text-xs">
            {tableHeaders.length > 0 && (
              <thead><tr>{tableHeaders.map((h, i) => (
                <th key={i} className="border border-gray-300 bg-gray-100 px-2 py-1.5 text-left font-semibold">{processInline(h.trim())}</th>
              ))}</tr></thead>
            )}
            <tbody>{tableRows.map((row, ri) => (
              <tr key={ri} className={ri % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                {row.map((cell, ci) => (
                  <td key={ci} className="border border-gray-300 px-2 py-1.5">{processInline(cell.trim())}</td>
                ))}
              </tr>
            ))}</tbody>
          </table>
        </div>
      );
      tableHeaders = [];
      tableRows = [];
      inTable = false;
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const trimmed = lines[i].trim();

    // Table rows
    if (trimmed.startsWith("|") && trimmed.endsWith("|")) {
      const cells = trimmed.split("|").filter((c) => c.trim() !== "");
      if (cells.every((c) => c.trim().match(/^[-:]+$/))) continue;
      if (!inTable) { inTable = true; tableHeaders = cells; } else { tableRows.push(cells); }
      continue;
    } else if (inTable) { flushTable(); }

    if (trimmed === "") { flushList(); continue; }
    if (trimmed === "---") { flushList(); elements.push(<hr key={`hr-${i}`} className="my-4 border-gray-200" />); continue; }

    // Headings
    if (trimmed.startsWith("### ")) {
      flushList();
      elements.push(<h4 key={`h4-${i}`} className="text-sm font-bold text-gray-800 mt-4 mb-2 flex items-center gap-1.5"><span className="w-1 h-4 bg-blue-400 rounded-full inline-block"></span>{processInline(trimmed.replace("### ", ""))}</h4>);
      continue;
    }
    if (trimmed.startsWith("## ")) {
      flushList();
      elements.push(<h3 key={`h3-${i}`} className="text-base font-bold text-gray-900 mt-5 mb-2">{processInline(trimmed.replace("## ", ""))}</h3>);
      continue;
    }

    // Numbered list
    const numMatch = trimmed.match(/^(\d+)\.\s+(.+)/);
    if (numMatch) {
      if (listType !== "ol" && listItems.length > 0) flushList();
      listType = "ol";
      listItems.push(numMatch[2]);
      continue;
    }
    // Bullet
    if (trimmed.startsWith("- ")) {
      if (listType !== "ul" && listItems.length > 0) flushList();
      listType = "ul";
      listItems.push(trimmed.slice(2));
      continue;
    }

    flushList();
    elements.push(
      <p key={`p-${i}`} className="text-sm text-gray-700 leading-relaxed mb-2">
        {processInline(trimmed)}
      </p>
    );
  }
  flushList();
  flushTable();
  return elements;
}

const difficultyConfig = {
  easy: { label: "Easy", color: "bg-green-100 text-green-700 border-green-300", icon: "🟢" },
  medium: { label: "Medium", color: "bg-yellow-100 text-yellow-700 border-yellow-300", icon: "🟡" },
  hard: { label: "Hard", color: "bg-red-100 text-red-700 border-red-300", icon: "🔴" },
};

const markColors: Record<number, string> = {
  2: "bg-green-100 text-green-700 border-green-300",
  3: "bg-emerald-100 text-emerald-700 border-emerald-300",
  5: "bg-yellow-100 text-yellow-700 border-yellow-300",
  10: "bg-red-100 text-red-700 border-red-300",
};

export function QuestionsTab({ chapter }: { chapter: Chapter }) {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  const [expandedSub, setExpandedSub] = useState<string | null>(null);
  const [filterDiff, setFilterDiff] = useState<string | null>(null);

  // Get exam-pattern questions for this chapter
  const chapterQuestions = examQuestions.filter((q) => q.chapterId === chapter.id);

  // Sort: easy → medium → hard
  const sortOrder = { easy: 0, medium: 1, hard: 2 };
  const sortedQuestions = [...chapterQuestions].sort((a, b) => sortOrder[a.difficulty] - sortOrder[b.difficulty]);

  const filteredQuestions = filterDiff ? sortedQuestions.filter((q) => q.difficulty === filterDiff) : sortedQuestions;

  // Also include legacy questions from courseData (if any match)
  const legacyQuestions = chapter.questions || [];

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-900 mb-2">📝 Exam-Pattern Practice Questions</h2>
        <p className="text-sm text-gray-500">
          Scenario-based analytical questions matching your teacher&apos;s exam pattern · Easy → Medium → Hard · With detailed high-scoring model answers
        </p>
        <div className="mt-3 bg-blue-50 border border-blue-200 rounded-lg p-3">
          <p className="text-xs text-blue-700">
            💡 <strong>Answer Length Guide:</strong> 2-3 marks ≈ 1 A4 page · 5 marks ≈ 2-3 A4 pages · 10 marks ≈ 4-5 A4 pages with graphs & calculations
          </p>
        </div>
      </div>

      {/* Filter by difficulty */}
      <div className="flex flex-wrap gap-2 mb-6">
        <button
          onClick={() => setFilterDiff(null)}
          className={`text-sm px-4 py-2 rounded-lg border font-medium transition-all ${filterDiff === null ? "bg-blue-100 text-blue-700 border-blue-300" : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"}`}
        >
          All ({chapterQuestions.length + legacyQuestions.length})
        </button>
        {(["easy", "medium", "hard"] as const).map((diff) => {
          const count = chapterQuestions.filter((q) => q.difficulty === diff).length;
          if (count === 0) return null;
          const cfg = difficultyConfig[diff];
          return (
            <button
              key={diff}
              onClick={() => setFilterDiff(filterDiff === diff ? null : diff)}
              className={`text-sm px-4 py-2 rounded-lg border font-medium transition-all ${filterDiff === diff ? cfg.color : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"}`}
            >
              {cfg.icon} {cfg.label} ({count})
            </button>
          );
        })}
      </div>

      {/* Exam-pattern questions */}
      <div className="space-y-4">
        {filteredQuestions.map((q, index) => (
          <ExamQuestionCard
            key={q.id}
            q={q}
            index={index}
            isExpanded={expandedIndex === index}
            onToggle={() => setExpandedIndex(expandedIndex === index ? null : index)}
            expandedSub={expandedSub}
            onToggleSub={(id) => setExpandedSub(expandedSub === id ? null : id)}
          />
        ))}
      </div>

      {/* Legacy questions (from original courseData) */}
      {!filterDiff && legacyQuestions.length > 0 && (
        <div className="mt-8">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            📚 Additional Practice Questions
          </h3>
          <div className="space-y-3">
            {legacyQuestions.map((q, idx) => {
              const legacyIdx = 1000 + idx;
              const isExp = expandedIndex === legacyIdx;
              return (
                <div key={idx} className={`border rounded-xl overflow-hidden transition-all ${isExp ? "border-blue-300 shadow-md" : "border-gray-200"}`}>
                  <button onClick={() => setExpandedIndex(isExp ? null : legacyIdx)} className="w-full text-left p-4 bg-white hover:bg-gray-50 transition-colors">
                    <div className="flex items-start gap-3">
                      <span className={`text-xs font-bold px-2.5 py-1 rounded-full border shrink-0 ${markColors[q.marks] || "bg-gray-100 text-gray-600 border-gray-300"}`}>{q.marks}M</span>
                      <p className="font-medium text-gray-900 leading-relaxed text-sm flex-1">{q.question}</p>
                      <svg className={`w-4 h-4 text-gray-400 shrink-0 transition-transform ${isExp ? "rotate-180" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                    </div>
                  </button>
                  {isExp && (
                    <div className="border-t border-gray-200 bg-gradient-to-b from-blue-50/50 to-white p-5">
                      <div className="bg-white border border-gray-100 rounded-lg p-4">{renderAnswer(q.answer)}</div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function ExamQuestionCard({
  q, index, isExpanded, onToggle, expandedSub, onToggleSub,
}: {
  q: ExamQuestion;
  index: number;
  isExpanded: boolean;
  onToggle: () => void;
  expandedSub: string | null;
  onToggleSub: (id: string) => void;
}) {
  const cfg = difficultyConfig[q.difficulty];
  const hasSubQuestions = q.subQuestions && q.subQuestions.length > 0;

  return (
    <div className={`border rounded-xl overflow-hidden transition-all ${isExpanded ? "border-blue-300 shadow-lg" : "border-gray-200"}`}>
      <button onClick={onToggle} className="w-full text-left p-5 bg-white hover:bg-gray-50 transition-colors">
        <div className="flex items-start gap-3">
          <div className="flex flex-col gap-1 shrink-0">
            <span className={`text-xs font-bold px-2.5 py-1 rounded-full border ${markColors[q.totalMarks] || "bg-gray-100 text-gray-600 border-gray-300"}`}>
              {q.totalMarks}M
            </span>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${cfg.color}`}>
              {cfg.icon} {cfg.label}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            {q.scenario && (
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-3 text-sm text-amber-900 leading-relaxed">
                <span className="font-bold text-amber-700">📋 Scenario: </span>
                <span style={{ whiteSpace: "pre-line" }}>{q.scenario}</span>
              </div>
            )}
            <p className="font-medium text-gray-900 leading-relaxed">
              Q{index + 1}. {q.question}
            </p>
            {hasSubQuestions && (
              <div className="mt-2 flex flex-wrap gap-1">
                {q.subQuestions!.map((sub) => (
                  <span key={sub.part} className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded">
                    ({sub.part}) {sub.marks}M
                  </span>
                ))}
              </div>
            )}
          </div>
          <svg className={`w-5 h-5 text-gray-400 shrink-0 transition-transform ${isExpanded ? "rotate-180" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </button>

      {isExpanded && (
        <div className="border-t border-gray-200">
          {hasSubQuestions ? (
            <div className="divide-y divide-gray-100">
              {q.subQuestions!.map((sub) => {
                const subId = `${q.id}-${sub.part}`;
                const isSubExpanded = expandedSub === subId;
                return (
                  <div key={sub.part}>
                    <button onClick={() => onToggleSub(subId)} className="w-full text-left p-4 bg-gray-50 hover:bg-gray-100 transition-colors">
                      <div className="flex items-start gap-3">
                        <span className="text-xs font-bold bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full border border-blue-200 shrink-0">
                          ({sub.part}) {sub.marks}M
                        </span>
                        <p className="text-sm text-gray-800 leading-relaxed flex-1">{sub.question}</p>
                        <svg className={`w-4 h-4 text-gray-400 shrink-0 transition-transform ${isSubExpanded ? "rotate-180" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                      </div>
                    </button>
                    {isSubExpanded && (
                      <div className="bg-gradient-to-b from-blue-50/50 to-white p-5">
                        <div className="flex items-center gap-2 mb-3">
                          <span className="text-xs font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded">✨ Model Answer — Part ({sub.part})</span>
                          <span className="text-xs text-gray-400">{sub.marks}-mark answer</span>
                        </div>
                        <div className="bg-white border border-gray-100 rounded-lg p-4 shadow-sm">
                          {renderAnswer(sub.answer)}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="bg-gradient-to-b from-blue-50/50 to-white p-5">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xs font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded">✨ Model Answer</span>
                <span className="text-xs text-gray-400">High-scoring {q.totalMarks}-mark answer ({q.difficulty})</span>
              </div>
              <div className="bg-white border border-gray-100 rounded-lg p-4 shadow-sm max-h-[80vh] overflow-y-auto">
                {q.answer && renderAnswer(q.answer)}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
