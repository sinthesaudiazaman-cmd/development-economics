"use client";

import { useEffect, useState } from "react";

interface ProgressData {
  id: number;
  chapterId: number;
  contentRead: boolean;
  materialsReviewed: boolean;
  videosWatched: boolean;
  questionsCompleted: boolean;
}

export function ProgressOverview() {
  const [progress, setProgress] = useState<ProgressData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/progress")
      .then((r) => r.json())
      .then((data: ProgressData[]) => {
        setProgress(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const totalChapters = 8;
  const totalTasks = totalChapters * 4; // 4 tasks per chapter

  const completedTasks = progress.reduce((sum, p) => {
    return (
      sum +
      (p.contentRead ? 1 : 0) +
      (p.materialsReviewed ? 1 : 0) +
      (p.videosWatched ? 1 : 0) +
      (p.questionsCompleted ? 1 : 0)
    );
  }, 0);

  const completedChapters = progress.filter(
    (p) => p.contentRead && p.materialsReviewed && p.videosWatched && p.questionsCompleted
  ).length;

  const percentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  if (loading) {
    return (
      <div className="bg-white rounded-xl border border-gray-200 p-6 mb-8 animate-pulse">
        <div className="h-6 bg-gray-200 rounded w-48 mb-4"></div>
        <div className="h-4 bg-gray-200 rounded w-full"></div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200 p-6 mb-8">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
            📊 Your Progress
          </h2>
          <p className="text-sm text-gray-500 mt-1">
            {completedChapters} of {totalChapters} chapters completed · {completedTasks} of {totalTasks} tasks done
          </p>
        </div>
        <div className="text-right">
          <span className="text-3xl font-bold text-blue-700">{percentage}%</span>
          <p className="text-xs text-gray-500">Overall</p>
        </div>
      </div>

      {/* Progress bar */}
      <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
        <div
          className="bg-gradient-to-r from-blue-500 to-indigo-500 h-3 rounded-full transition-all duration-500"
          style={{ width: `${percentage}%` }}
        ></div>
      </div>

      {/* Chapter progress indicators */}
      <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
        {Array.from({ length: totalChapters }, (_, i) => i + 1).map((chId) => {
          const p = progress.find((pr) => pr.chapterId === chId);
          const chCompleted = p
            ? (p.contentRead ? 1 : 0) + (p.materialsReviewed ? 1 : 0) + (p.videosWatched ? 1 : 0) + (p.questionsCompleted ? 1 : 0)
            : 0;
          const isComplete = chCompleted === 4;
          const isPartial = chCompleted > 0 && chCompleted < 4;

          return (
            <div
              key={chId}
              className={`rounded-lg p-2 text-center text-xs font-medium border ${
                isComplete
                  ? "bg-green-100 border-green-300 text-green-700"
                  : isPartial
                  ? "bg-yellow-50 border-yellow-300 text-yellow-700"
                  : "bg-white border-gray-200 text-gray-400"
              }`}
            >
              <div className="font-bold">Ch {chId}</div>
              <div>{chCompleted}/4</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
