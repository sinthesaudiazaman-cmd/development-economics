"use client";

import { useState, useEffect, useCallback } from "react";
import type { ModelTest } from "@/data/modelTests";
import { examQuestions } from "@/data/examQuestions";

function renderAnswer(text: string): React.ReactNode {
  const lines = text.split("\n");
  const elements: React.ReactNode[] = [];
  let listItems: string[] = [];

  const processInline = (str: string): React.ReactNode => {
    const parts: React.ReactNode[] = [];
    let remaining = str;
    let keyIndex = 0;
    while (remaining.length > 0) {
      const boldMatch = remaining.match(/\*\*(.+?)\*\*/);
      if (boldMatch && boldMatch.index !== undefined) {
        if (boldMatch.index > 0) parts.push(remaining.slice(0, boldMatch.index));
        parts.push(<strong key={keyIndex++} className="font-semibold text-gray-900">{boldMatch[1]}</strong>);
        remaining = remaining.slice(boldMatch.index + boldMatch[0].length);
      } else {
        parts.push(remaining);
        break;
      }
    }
    return parts.length === 1 ? parts[0] : <>{parts}</>;
  };

  const flushList = () => {
    if (listItems.length > 0) {
      elements.push(
        <ul key={`list-${elements.length}`} className="list-disc ml-5 mb-2 space-y-0.5">
          {listItems.map((item, i) => <li key={i} className="text-sm text-gray-700 leading-relaxed">{processInline(item)}</li>)}
        </ul>
      );
      listItems = [];
    }
  };

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed === "") { flushList(); continue; }
    const numMatch = trimmed.match(/^(\d+)\.\s+(.+)/);
    if (numMatch) { listItems.push(numMatch[2]); continue; }
    if (trimmed.startsWith("- ")) { listItems.push(trimmed.slice(2)); continue; }
    flushList();
    if (trimmed.startsWith("### ")) {
      elements.push(<h4 key={`h-${elements.length}`} className="text-sm font-bold text-gray-800 mt-3 mb-1">{processInline(trimmed.slice(4))}</h4>);
    } else {
      elements.push(<p key={`p-${elements.length}`} className="text-sm text-gray-700 leading-relaxed mb-1.5">{processInline(trimmed)}</p>);
    }
  }
  flushList();
  return elements;
}

export function ModelTestRunner({ test }: { test: ModelTest }) {
  const [started, setStarted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(test.duration * 60);
  const [revealedAnswers, setRevealedAnswers] = useState<Set<string>>(new Set());
  const [finished, setFinished] = useState(false);

  useEffect(() => {
    if (!started || finished) return;
    if (timeLeft <= 0) { setFinished(true); return; }
    const timer = setInterval(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearInterval(timer);
  }, [started, finished, timeLeft]);

  const toggleReveal = useCallback((id: string) => {
    setRevealedAnswers((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }, []);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
  };

  if (!started) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-xl border border-gray-200 p-8 text-center">
          <span className="text-5xl block mb-4">📝</span>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">{test.title}</h2>
          <p className="text-gray-500 mb-6">{test.description}</p>
          <div className="flex justify-center gap-6 mb-8 text-sm">
            <div className="bg-gray-50 rounded-lg px-4 py-3">
              <p className="text-gray-400 text-xs">Duration</p>
              <p className="font-bold text-gray-800">{test.duration} minutes</p>
            </div>
            <div className="bg-gray-50 rounded-lg px-4 py-3">
              <p className="text-gray-400 text-xs">Total Marks</p>
              <p className="font-bold text-gray-800">{test.totalMarks}</p>
            </div>
            <div className="bg-gray-50 rounded-lg px-4 py-3">
              <p className="text-gray-400 text-xs">Sections</p>
              <p className="font-bold text-gray-800">{test.sections.length}</p>
            </div>
          </div>
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6 text-left">
            <p className="text-sm text-amber-800 font-medium mb-2">📋 Instructions:</p>
            <ul className="text-sm text-amber-700 space-y-1">
              <li>• Write your answers on paper first before revealing model answers</li>
              <li>• Time yourself — the timer will count down from {test.duration} minutes</li>
              <li>• Click &quot;Reveal Answer&quot; to see model answers after attempting each question</li>
              <li>• Compare your answer structure and content with the model answer</li>
            </ul>
          </div>
          <button
            onClick={() => setStarted(true)}
            className="bg-purple-600 text-white px-8 py-3 rounded-xl font-medium hover:bg-purple-700 transition-colors text-lg"
          >
            Start Test ⏱
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* Timer bar */}
      <div className={`sticky top-14 z-40 rounded-xl p-3 mb-6 flex items-center justify-between ${finished ? "bg-green-100 border border-green-300" : timeLeft < 300 ? "bg-red-100 border border-red-300" : "bg-white border border-gray-200"} shadow-sm`}>
        <div className="flex items-center gap-3">
          <span className={`text-2xl font-mono font-bold ${finished ? "text-green-700" : timeLeft < 300 ? "text-red-600" : "text-gray-800"}`}>
            {finished ? "✅ Finished" : `⏱ ${formatTime(timeLeft)}`}
          </span>
          {!finished && timeLeft < 300 && <span className="text-xs text-red-600 font-medium animate-pulse">Less than 5 minutes!</span>}
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-gray-500">{revealedAnswers.size} answers revealed</span>
          {!finished && (
            <button onClick={() => setFinished(true)} className="text-sm bg-gray-100 hover:bg-gray-200 px-3 py-1.5 rounded-lg transition-colors">
              End Test
            </button>
          )}
        </div>
      </div>

      {/* Test sections */}
      {test.sections.map((section, si) => (
        <div key={si} className="mb-8">
          <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-xl p-4 mb-4">
            <h3 className="font-bold text-purple-900">{section.title}</h3>
            <p className="text-sm text-purple-700 mt-1">{section.instructions}</p>
          </div>

          <div className="space-y-4">
            {section.questionRefs.map((ref, qi) => {
              const q = examQuestions.find((eq) => eq.id === ref);
              if (!q) return null;
              const hasSubQuestions = q.subQuestions && q.subQuestions.length > 0;

              return (
                <div key={ref} className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                  <div className="p-5">
                    <div className="flex items-start gap-3 mb-3">
                      <span className="text-xs font-bold bg-purple-100 text-purple-700 px-2.5 py-1 rounded-full border border-purple-200">
                        {q.totalMarks}M
                      </span>
                      <span className="text-xs text-gray-400">Question {qi + 1}</span>
                    </div>
                    {q.scenario && (
                      <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-3 text-sm text-amber-900 leading-relaxed">
                        <span className="font-bold text-amber-700">📋 Scenario: </span>
                        <span style={{ whiteSpace: "pre-line" }}>{q.scenario}</span>
                      </div>
                    )}
                    <p className="font-medium text-gray-900 leading-relaxed">{q.question}</p>

                    {hasSubQuestions && (
                      <div className="mt-3 space-y-3">
                        {q.subQuestions!.map((sub) => {
                          const subKey = `${ref}-${sub.part}`;
                          const isRevealed = revealedAnswers.has(subKey);
                          return (
                            <div key={sub.part} className="border border-gray-100 rounded-lg overflow-hidden">
                              <div className="p-3 bg-gray-50">
                                <div className="flex items-start gap-2">
                                  <span className="text-xs font-bold bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full shrink-0">({sub.part}) {sub.marks}M</span>
                                  <p className="text-sm text-gray-800">{sub.question}</p>
                                </div>
                              </div>
                              <div className="p-3 border-t border-gray-100">
                                {isRevealed ? (
                                  <div>
                                    <button onClick={() => toggleReveal(subKey)} className="text-xs text-gray-400 hover:text-gray-600 mb-2">Hide Answer ↑</button>
                                    <div className="bg-blue-50/50 rounded-lg p-3">{renderAnswer(sub.answer)}</div>
                                  </div>
                                ) : (
                                  <button onClick={() => toggleReveal(subKey)} className="text-sm text-purple-600 hover:text-purple-700 font-medium flex items-center gap-1">
                                    👁 Reveal Model Answer
                                  </button>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {!hasSubQuestions && q.answer && (
                      <div className="mt-4">
                        {revealedAnswers.has(ref) ? (
                          <div>
                            <button onClick={() => toggleReveal(ref)} className="text-xs text-gray-400 hover:text-gray-600 mb-2">Hide Answer ↑</button>
                            <div className="bg-blue-50/50 rounded-lg p-4 max-h-96 overflow-y-auto">{renderAnswer(q.answer)}</div>
                          </div>
                        ) : (
                          <button onClick={() => toggleReveal(ref)} className="text-sm text-purple-600 hover:text-purple-700 font-medium flex items-center gap-1">
                            👁 Reveal Model Answer
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}

      {finished && (
        <div className="bg-green-50 border border-green-200 rounded-xl p-6 text-center mt-8">
          <span className="text-4xl block mb-3">🎉</span>
          <h3 className="text-xl font-bold text-green-800">Test Complete!</h3>
          <p className="text-sm text-green-600 mt-2">Review the model answers and compare with your responses. Focus on answer structure and key points.</p>
        </div>
      )}
    </div>
  );
}
