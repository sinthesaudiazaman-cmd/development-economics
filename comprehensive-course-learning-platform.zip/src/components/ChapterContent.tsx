"use client";

import { useState, useEffect, useCallback } from "react";
import type { Chapter } from "@/data/courseData";
import { ContentTab } from "./tabs/ContentTab";
import { MaterialsTab } from "./tabs/MaterialsTab";
import { VideosTab } from "./tabs/VideosTab";
import { QuestionsTab } from "./tabs/QuestionsTab";
import { ChapterProgressTracker } from "./ChapterProgressTracker";

const tabs = [
  { id: "content", label: "📖 Content", field: "contentRead" },
  { id: "materials", label: "📂 Materials", field: "materialsReviewed" },
  { id: "videos", label: "🎬 Videos", field: "videosWatched" },
  { id: "questions", label: "📝 Questions", field: "questionsCompleted" },
] as const;

type TabId = (typeof tabs)[number]["id"];

interface ProgressData {
  chapterId: number;
  contentRead: boolean;
  materialsReviewed: boolean;
  videosWatched: boolean;
  questionsCompleted: boolean;
  notes?: string;
}

export function ChapterContent({ chapter }: { chapter: Chapter }) {
  const [activeTab, setActiveTab] = useState<TabId>("content");
  const [progress, setProgress] = useState<ProgressData>({
    chapterId: chapter.id,
    contentRead: false,
    materialsReviewed: false,
    videosWatched: false,
    questionsCompleted: false,
    notes: "",
  });

  useEffect(() => {
    fetch("/api/progress")
      .then((r) => r.json())
      .then((data: ProgressData[]) => {
        const cp = data.find((p: ProgressData) => p.chapterId === chapter.id);
        if (cp) setProgress(cp);
      })
      .catch(() => {});
  }, [chapter.id]);

  const toggleProgress = useCallback(
    (field: string) => {
      const currentValue = progress[field as keyof ProgressData] as boolean;
      const newValue = !currentValue;

      setProgress((prev) => ({ ...prev, [field]: newValue }));

      fetch("/api/progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chapterId: chapter.id, field, value: newValue }),
      }).catch(() => {});
    },
    [chapter.id, progress]
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Main content area */}
        <div className="flex-1 min-w-0">
          {/* Tab navigation */}
          <div className="bg-white rounded-xl border border-gray-200 mb-6 overflow-hidden">
            <div className="flex border-b border-gray-200 overflow-x-auto">
              {tabs.map((tab) => {
                const isCompleted = progress[tab.field as keyof ProgressData] as boolean;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-1.5 px-5 py-3.5 text-sm font-medium whitespace-nowrap transition-all border-b-2 ${
                      activeTab === tab.id
                        ? "border-blue-500 text-blue-700 bg-blue-50/50"
                        : "border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50"
                    }`}
                  >
                    {tab.label}
                    {isCompleted && (
                      <span className="text-green-500 text-xs">✓</span>
                    )}
                  </button>
                );
              })}
            </div>

            <div className="p-6 content-section">
              {activeTab === "content" && <ContentTab chapter={chapter} />}
              {activeTab === "materials" && <MaterialsTab chapter={chapter} />}
              {activeTab === "videos" && <VideosTab chapter={chapter} />}
              {activeTab === "questions" && <QuestionsTab chapter={chapter} />}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="lg:w-80 shrink-0">
          <ChapterProgressTracker
            chapter={chapter}
            progress={progress}
            onToggle={toggleProgress}
          />

          {/* Table of Contents */}
          <div className="bg-white rounded-xl border border-gray-200 p-5 mt-4">
            <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
              📑 Topics in this Chapter
            </h3>
            <ul className="space-y-2">
              {chapter.topics.map((topic, i) => (
                <li key={i}>
                  <button
                    onClick={() => {
                      setActiveTab("content");
                      setTimeout(() => {
                        const el = document.getElementById(`topic-${i}`);
                        if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
                      }, 100);
                    }}
                    className="text-sm text-gray-600 hover:text-blue-600 transition-colors text-left leading-snug"
                  >
                    {i + 1}. {topic.title}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
