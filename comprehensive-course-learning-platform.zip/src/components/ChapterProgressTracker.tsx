"use client";

import type { Chapter } from "@/data/courseData";

interface ProgressData {
  chapterId: number;
  contentRead: boolean;
  materialsReviewed: boolean;
  videosWatched: boolean;
  questionsCompleted: boolean;
  notes?: string;
}

const progressItems = [
  { field: "contentRead", label: "Read Content", icon: "📖", color: "blue" },
  { field: "materialsReviewed", label: "Review Materials", icon: "📂", color: "amber" },
  { field: "videosWatched", label: "Watch Videos", icon: "🎬", color: "red" },
  { field: "questionsCompleted", label: "Complete Questions", icon: "📝", color: "green" },
] as const;

export function ChapterProgressTracker({
  chapter,
  progress,
  onToggle,
}: {
  chapter: Chapter;
  progress: ProgressData;
  onToggle: (field: string) => void;
}) {
  const completedCount = progressItems.filter(
    (item) => progress[item.field as keyof ProgressData] as boolean
  ).length;

  const percentage = Math.round((completedCount / 4) * 100);
  const isComplete = completedCount === 4;

  return (
    <div
      className={`rounded-xl border p-5 sticky top-16 ${
        isComplete
          ? "bg-gradient-to-br from-green-50 to-emerald-50 border-green-200"
          : "bg-white border-gray-200"
      }`}
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-gray-800 flex items-center gap-2">
          {isComplete ? "🎉" : "📊"} Progress
        </h3>
        <span
          className={`text-lg font-bold ${
            isComplete ? "text-green-600" : percentage > 0 ? "text-blue-600" : "text-gray-400"
          }`}
        >
          {percentage}%
        </span>
      </div>

      {/* Progress circle */}
      <div className="flex justify-center mb-4">
        <div className="relative w-24 h-24">
          <svg className="w-24 h-24" viewBox="0 0 36 36">
            <path
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              fill="none"
              stroke="#e5e7eb"
              strokeWidth="3"
            />
            <path
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              fill="none"
              stroke={isComplete ? "#16a34a" : "#3b82f6"}
              strokeWidth="3"
              strokeDasharray={`${percentage}, 100`}
              strokeLinecap="round"
              className="progress-ring"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-lg font-bold text-gray-800">{completedCount}/4</span>
            <span className="text-[10px] text-gray-400">tasks</span>
          </div>
        </div>
      </div>

      {/* Checklist */}
      <div className="space-y-2">
        {progressItems.map((item) => {
          const checked = progress[item.field as keyof ProgressData] as boolean;
          return (
            <label
              key={item.field}
              className={`flex items-center gap-3 p-2.5 rounded-lg cursor-pointer transition-all ${
                checked
                  ? "bg-green-50 border border-green-200"
                  : "hover:bg-gray-50 border border-transparent"
              }`}
            >
              <input
                type="checkbox"
                checked={checked}
                onChange={() => onToggle(item.field)}
                className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm">{item.icon}</span>
              <span
                className={`text-sm ${
                  checked ? "text-green-700 font-medium line-through" : "text-gray-700"
                }`}
              >
                {item.label}
              </span>
            </label>
          );
        })}
      </div>

      {isComplete && (
        <div className="mt-4 p-3 bg-green-100 rounded-lg text-center">
          <p className="text-sm font-medium text-green-800">
            ✅ Chapter {chapter.id} Complete!
          </p>
        </div>
      )}
    </div>
  );
}
